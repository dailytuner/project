--
-- PostgreSQL database dump
--

\restrict lseLd6p8pwlobbp3GCO1s9kIIHJnsXfBsSif3DNjWC2QbgU8XsTPsr0ClVMWqmf

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: activity_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.activity_type AS ENUM (
    'physical',
    'spiritual',
    'learning',
    'psychological',
    'career',
    'self_realization',
    'finances'
);


ALTER TYPE public.activity_type OWNER TO postgres;

--
-- Name: aspect_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.aspect_type AS ENUM (
    'conjunction',
    'sextile',
    'square',
    'trine',
    'opposition',
    'quincunx',
    'semi_sextile',
    'semi_square'
);


ALTER TYPE public.aspect_type OWNER TO postgres;

--
-- Name: energy_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.energy_level AS ENUM (
    'very_low',
    'low',
    'medium',
    'high',
    'very_high'
);


ALTER TYPE public.energy_level OWNER TO postgres;

--
-- Name: phase_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.phase_type AS ENUM (
    'positive',
    'negative',
    'critical',
    'neutral'
);


ALTER TYPE public.phase_type OWNER TO postgres;

--
-- Name: test_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.test_type AS ENUM (
    'mbti',
    'big5',
    'values',
    'maslow'
);


ALTER TYPE public.test_type OWNER TO postgres;

--
-- Name: trend_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.trend_type AS ENUM (
    'rising',
    'falling',
    'stable'
);


ALTER TYPE public.trend_type OWNER TO postgres;

--
-- Name: cleanup_old_data(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_data() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Удаляем старые метрики (90 дней)
    DELETE FROM system_metrics
    WHERE collected_at < NOW() - INTERVAL '90 days';

    -- Удаляем старые ML метрики (30 дней)
    DELETE FROM ml_model_metrics
    WHERE timestamp < NOW() - INTERVAL '30 days';

    -- Инвалидируем старый кэш (7 дней)
    UPDATE calculation_cache
    SET is_valid = FALSE
    WHERE expires_at < NOW() - INTERVAL '7 days';

    -- Архивируем старые аудит логи (1 год)
    DELETE FROM system_audit_log
    WHERE created_at < NOW() - INTERVAL '1 year';

    RAISE NOTICE 'Database cleanup completed at %', NOW();
END;
$$;


ALTER FUNCTION public.cleanup_old_data() OWNER TO postgres;

--
-- Name: cleanup_old_forecasts(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_forecasts() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM daily_forecast_cache
    WHERE expires_at < NOW();

    RAISE NOTICE 'Cleaned % expired forecasts at %',
        FOUND, NOW();
END;
$$;


ALTER FUNCTION public.cleanup_old_forecasts() OWNER TO postgres;

--
-- Name: update_magic_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_magic_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_magic_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: update_user_activity(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_user_activity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Используем CTE для обновления без рекурсивного триггера
    WITH activity_update AS (
        UPDATE users 
        SET last_activity_at = NOW()
        WHERE id = NEW.user_id
        AND last_activity_at < NOW() - INTERVAL '5 minutes'
        RETURNING 1
    )
    SELECT 1 FROM activity_update;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_activity() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: astro_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.astro_events (
    id bigint NOT NULL,
    event_date date NOT NULL,
    event_time timestamp with time zone,
    event_type character varying(50) NOT NULL,
    event_name character varying(100) NOT NULL,
    description text,
    significance_level character varying(20),
    zodiac_sign character varying(20),
    degree numeric(5,2),
    planetary_aspects jsonb DEFAULT '{}'::jsonb,
    general_recommendations text[] DEFAULT '{}'::text[],
    caution_areas text[] DEFAULT '{}'::text[],
    source character varying(50) DEFAULT 'calculated'::character varying,
    confidence real DEFAULT 1.0,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT astro_events_confidence_check CHECK (((confidence >= (0)::double precision) AND (confidence <= (1)::double precision))),
    CONSTRAINT astro_events_event_type_check CHECK (((event_type)::text = ANY (ARRAY[('new_moon'::character varying)::text, ('full_moon'::character varying)::text, ('first_quarter'::character varying)::text, ('last_quarter'::character varying)::text, ('mercury_retrograde'::character varying)::text, ('venus_retrograde'::character varying)::text, ('mars_retrograde'::character varying)::text, ('jupiter_retrograde'::character varying)::text, ('saturn_retrograde'::character varying)::text, ('uranus_retrograde'::character varying)::text, ('neptune_retrograde'::character varying)::text, ('pluto_retrograde'::character varying)::text, ('eclipse_solar'::character varying)::text, ('eclipse_lunar'::character varying)::text, ('planetary_transit'::character varying)::text]))),
    CONSTRAINT astro_events_significance_level_check CHECK (((significance_level)::text = ANY (ARRAY[('low'::character varying)::text, ('medium'::character varying)::text, ('high'::character varying)::text, ('critical'::character varying)::text])))
);


ALTER TABLE public.astro_events OWNER TO postgres;

--
-- Name: TABLE astro_events; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.astro_events IS 'Астрологические события и лунные фазы';


--
-- Name: astro_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.astro_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.astro_events_id_seq OWNER TO postgres;

--
-- Name: astro_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.astro_events_id_seq OWNED BY public.astro_events.id;


--
-- Name: biorhythms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.biorhythms (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date NOT NULL,
    profile_version character varying(10) DEFAULT '1.0'::character varying NOT NULL,
    profile_calculated_at date,
    days_analyzed integer,
    birth_physical double precision,
    birth_emotional double precision,
    birth_intellectual double precision,
    birth_intuitive double precision,
    system_stability double precision,
    predictability double precision,
    profile_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT biorhythms_birth_emotional_check CHECK (((birth_emotional >= ('-1.0'::numeric)::double precision) AND (birth_emotional <= (1.0)::double precision))),
    CONSTRAINT biorhythms_birth_intellectual_check CHECK (((birth_intellectual >= ('-1.0'::numeric)::double precision) AND (birth_intellectual <= (1.0)::double precision))),
    CONSTRAINT biorhythms_birth_intuitive_check CHECK (((birth_intuitive >= ('-1.0'::numeric)::double precision) AND (birth_intuitive <= (1.0)::double precision))),
    CONSTRAINT biorhythms_birth_physical_check CHECK (((birth_physical >= ('-1.0'::numeric)::double precision) AND (birth_physical <= (1.0)::double precision))),
    CONSTRAINT biorhythms_days_analyzed_check CHECK ((days_analyzed > 0)),
    CONSTRAINT biorhythms_predictability_check CHECK (((predictability >= (0)::double precision) AND (predictability <= (1)::double precision))),
    CONSTRAINT biorhythms_system_stability_check CHECK (((system_stability >= (0)::double precision) AND (system_stability <= (1)::double precision)))
);


ALTER TABLE public.biorhythms OWNER TO postgres;

--
-- Name: TABLE biorhythms; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.biorhythms IS 'Расчёты биоритмов пользователей';


--
-- Name: COLUMN biorhythms.profile_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.profile_version IS 'Версия алгоритма расчета профиля';


--
-- Name: COLUMN biorhythms.profile_calculated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.profile_calculated_at IS 'Дата расчета профиля';


--
-- Name: COLUMN biorhythms.days_analyzed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.days_analyzed IS 'Количество дней для анализа (обычно 1825 = 5 лет)';


--
-- Name: COLUMN biorhythms.birth_physical; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.birth_physical IS 'Фаза физического цикла при рождении (-1..1)';


--
-- Name: COLUMN biorhythms.system_stability; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.system_stability IS 'Стабильность системы (0-1)';


--
-- Name: COLUMN biorhythms.profile_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.profile_data IS 'Полные данные профиля для Mistral';


--
-- Name: biorhythms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.biorhythms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.biorhythms_id_seq OWNER TO postgres;

--
-- Name: biorhythms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.biorhythms_id_seq OWNED BY public.biorhythms.id;


--
-- Name: calculation_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calculation_cache (
    id bigint NOT NULL,
    cache_key character varying(255) NOT NULL,
    cache_group character varying(100) NOT NULL,
    data jsonb NOT NULL,
    data_hash character varying(64) NOT NULL,
    calculation_type character varying(50) NOT NULL,
    user_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    last_accessed_at timestamp with time zone DEFAULT now() NOT NULL,
    access_count integer DEFAULT 0,
    is_valid boolean DEFAULT true
);


ALTER TABLE public.calculation_cache OWNER TO postgres;

--
-- Name: TABLE calculation_cache; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.calculation_cache IS 'Кэш результатов расчётов для оптимизации';


--
-- Name: calculation_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calculation_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calculation_cache_id_seq OWNER TO postgres;

--
-- Name: calculation_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calculation_cache_id_seq OWNED BY public.calculation_cache.id;


--
-- Name: daily_forecast_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_forecast_cache (
    id integer NOT NULL,
    user_id integer NOT NULL,
    forecast_date date NOT NULL,
    axes_deltas jsonb NOT NULL,
    daily_axes jsonb NOT NULL,
    recommendations jsonb,
    background_risks jsonb,
    subtle_signals jsonb,
    signal_categories jsonb,
    rules_version character varying(20) DEFAULT 'v1.0'::character varying,
    invalidated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.daily_forecast_cache OWNER TO postgres;

--
-- Name: COLUMN daily_forecast_cache.background_risks; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.daily_forecast_cache.background_risks IS 'Список фоновых рисков от слабых сигналов';


--
-- Name: COLUMN daily_forecast_cache.subtle_signals; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.daily_forecast_cache.subtle_signals IS 'Детали слабых сигналов по осям';


--
-- Name: COLUMN daily_forecast_cache.signal_categories; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.daily_forecast_cache.signal_categories IS 'Категоризация всех сигналов (critical/strong/medium/weak)';


--
-- Name: daily_forecast_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.daily_forecast_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_forecast_cache_id_seq OWNER TO postgres;

--
-- Name: daily_forecast_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.daily_forecast_cache_id_seq OWNED BY public.daily_forecast_cache.id;


--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommendations (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    summary text,
    category character varying(50) NOT NULL,
    priority smallint DEFAULT 3 NOT NULL,
    relevance_score real DEFAULT 0.5 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT recommendations_priority_check CHECK (((priority >= 1) AND (priority <= 5))),
    CONSTRAINT recommendations_relevance_score_check CHECK (((relevance_score >= (0)::double precision) AND (relevance_score <= (1)::double precision)))
);


ALTER TABLE public.recommendations OWNER TO postgres;

--
-- Name: TABLE recommendations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.recommendations IS 'Итоговые персонализированные рекомендации';


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    telegram_id bigint,
    max_id character varying(255),
    udemy_id character varying(255),
    google_id character varying(255),
    apple_id character varying(255),
    yandex_id character varying(255),
    phone_hash character varying(128),
    email_hash character varying(128),
    password_hash character varying(255),
    yandex_refresh_token text,
    yandex_access_token text,
    yandex_token_expires_at timestamp with time zone,
    yandex_email character varying(255),
    yandex_login character varying(255),
    primary_auth_method character varying(20) DEFAULT 'telegram'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    is_verified boolean DEFAULT false,
    is_premium boolean DEFAULT false,
    privacy_level character varying(20) DEFAULT 'standard'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    premium_until timestamp with time zone,
    CONSTRAINT users_primary_auth_method_check CHECK (((primary_auth_method)::text = ANY (ARRAY[('telegram'::character varying)::text, ('max'::character varying)::text, ('udemy'::character varying)::text, ('phone'::character varying)::text, ('email'::character varying)::text, ('google'::character varying)::text, ('apple'::character varying)::text, ('yandex'::character varying)::text]))),
    CONSTRAINT users_privacy_level_check CHECK (((privacy_level)::text = ANY (ARRAY[('minimal'::character varying)::text, ('standard'::character varying)::text, ('maximum'::character varying)::text]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text, ('suspended'::character varying)::text, ('deleted'::character varying)::text])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.users IS 'Основная таблица пользователей системы';


--
-- Name: COLUMN users.telegram_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.telegram_id IS 'ID пользователя в Telegram (уникальный, если указан)';


--
-- Name: COLUMN users.max_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.max_id IS 'ID пользователя в MAX платформе';


--
-- Name: COLUMN users.udemy_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.udemy_id IS 'ID пользователя в Udemy';


--
-- Name: COLUMN users.google_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.google_id IS 'ID пользователя в Google';


--
-- Name: COLUMN users.apple_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.apple_id IS 'ID пользователя в Apple';


--
-- Name: COLUMN users.phone_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.phone_hash IS 'Хеш телефона для анонимизации';


--
-- Name: COLUMN users.email_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.email_hash IS 'Хеш email для анонимизации';


--
-- Name: COLUMN users.primary_auth_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.primary_auth_method IS 'Основной метод авторизации пользователя';


--
-- Name: COLUMN users.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.status IS 'Статус аккаунта: active, inactive, suspended, deleted';


--
-- Name: COLUMN users.is_verified; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_verified IS 'Подтвержден ли аккаунт';


--
-- Name: COLUMN users.is_premium; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_premium IS 'Есть ли премиум-доступ';


--
-- Name: COLUMN users.privacy_level; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.privacy_level IS 'Уровень конфиденциальности: minimal, standard, maximum';


--
-- Name: COLUMN users.premium_until; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.premium_until IS 'Дата окончания премиум-доступа';


--
-- Name: daily_user_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.daily_user_summary AS
 SELECT date(users.created_at) AS date,
    count(*) AS new_users,
    count(*) FILTER (WHERE (users.is_premium = true)) AS new_premium_users,
    count(DISTINCT users.telegram_id) AS active_users,
    ( SELECT count(*) AS count
           FROM public.recommendations
          WHERE (recommendations.calculation_date = CURRENT_DATE)) AS daily_recommendations,
    ( SELECT count(*) AS count
           FROM public.biorhythms
          WHERE (biorhythms.calculation_date = CURRENT_DATE)) AS daily_biorhythms,
    round((((count(*) FILTER (WHERE (users.last_activity_at >= (now() - '7 days'::interval))))::numeric * 100.0) / (NULLIF(count(*), 0))::numeric), 2) AS weekly_retention_rate
   FROM public.users
  WHERE (users.created_at >= (CURRENT_DATE - '30 days'::interval))
  GROUP BY (date(users.created_at))
  ORDER BY (date(users.created_at)) DESC;


ALTER TABLE public.daily_user_summary OWNER TO postgres;

--
-- Name: forecast_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forecast_feedback (
    id integer NOT NULL,
    user_id integer,
    forecast_date date,
    axis_name character varying(50),
    predicted_score real,
    user_rating real,
    delta real,
    comment text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forecast_feedback OWNER TO postgres;

--
-- Name: forecast_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.forecast_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forecast_feedback_id_seq OWNER TO postgres;

--
-- Name: forecast_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.forecast_feedback_id_seq OWNED BY public.forecast_feedback.id;


--
-- Name: magic_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.magic_profiles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    axes jsonb DEFAULT '{}'::jsonb NOT NULL,
    axis_count integer DEFAULT 9 NOT NULL,
    data_sources text[] DEFAULT ARRAY[]::text[],
    psychological_blueprint jsonb DEFAULT '{}'::jsonb NOT NULL,
    ml_features jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_vector real[] DEFAULT ARRAY[]::real[] NOT NULL,
    cluster_id integer,
    anomaly_score real DEFAULT 0.0,
    profile_version character varying(20) DEFAULT '2.0'::character varying,
    confidence_score real DEFAULT 0.85,
    calculation_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_valid boolean DEFAULT true,
    validation_errors text[] DEFAULT ARRAY[]::text[],
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT magic_profiles_anomaly_score_check CHECK (((anomaly_score >= (0)::double precision) AND (anomaly_score <= (1)::double precision))),
    CONSTRAINT magic_profiles_confidence_score_check CHECK (((confidence_score >= (0)::double precision) AND (confidence_score <= (1)::double precision)))
);


ALTER TABLE public.magic_profiles OWNER TO postgres;

--
-- Name: TABLE magic_profiles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.magic_profiles IS 'Интегрированные психологические и эзотерические профили';


--
-- Name: COLUMN magic_profiles.axes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.axes IS '9 осей личности с полной структурой: energy_will, health_physical, intellect_logic, emotions_intuition, work_discipline, luck_talent, social_relations, karma_cycles, destiny_mission';


--
-- Name: COLUMN magic_profiles.psychological_blueprint; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.psychological_blueprint IS 'Интегрированный психологический портрет: core_personality, emotional_architecture, cognitive_style, social_dynamics, life_purpose_indicators';


--
-- Name: COLUMN magic_profiles.ml_features; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.ml_features IS 'ML-признаки: raw_features (18+ метрик), big_five, special_indicators (has_spica, has_yod, destiny_intensity)';


--
-- Name: COLUMN magic_profiles.feature_vector; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.feature_vector IS 'Фиксированный вектор для ML моделей (27 признаков: 18 raw + 5 big5 + 3 special)';


--
-- Name: COLUMN magic_profiles.calculation_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.calculation_metadata IS 'Метаданные расчета: axis_count (9), feature_count (26), calculation_time_ms, data_sources';


--
-- Name: magic_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.magic_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.magic_profiles_id_seq OWNER TO postgres;

--
-- Name: magic_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.magic_profiles_id_seq OWNED BY public.magic_profiles.id;


--
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ml_model_metrics (
    id bigint NOT NULL,
    model_name character varying(100) NOT NULL,
    model_version character varying(20) NOT NULL,
    inference_time_ms integer NOT NULL,
    memory_usage_mb integer NOT NULL,
    success_rate real NOT NULL,
    input_size_bytes integer,
    output_size_bytes integer,
    user_id bigint,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ml_model_metrics_success_rate_check CHECK (((success_rate >= (0)::double precision) AND (success_rate <= (1)::double precision)))
);


ALTER TABLE public.ml_model_metrics OWNER TO postgres;

--
-- Name: TABLE ml_model_metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ml_model_metrics IS 'Метрики производительности ML моделей';


--
-- Name: ml_model_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ml_model_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ml_model_metrics_id_seq OWNER TO postgres;

--
-- Name: ml_model_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ml_model_metrics_id_seq OWNED BY public.ml_model_metrics.id;


--
-- Name: ml_models_performance; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.ml_models_performance AS
 SELECT ml_model_metrics.model_name,
    ml_model_metrics.model_version,
    count(*) AS total_inferences,
    avg(ml_model_metrics.inference_time_ms) AS avg_inference_time,
    (avg(ml_model_metrics.success_rate) * (100)::double precision) AS avg_success_rate,
    avg(ml_model_metrics.memory_usage_mb) AS avg_memory_mb,
    min(ml_model_metrics."timestamp") AS first_used,
    max(ml_model_metrics."timestamp") AS last_used
   FROM public.ml_model_metrics
  WHERE (ml_model_metrics."timestamp" >= (now() - '7 days'::interval))
  GROUP BY ml_model_metrics.model_name, ml_model_metrics.model_version
  ORDER BY (count(*)) DESC;


ALTER TABLE public.ml_models_performance OWNER TO postgres;

--
-- Name: natal_charts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.natal_charts (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date DEFAULT CURRENT_DATE NOT NULL,
    calculation_timestamp timestamp with time zone DEFAULT now() NOT NULL,
    calculation_time_ms integer,
    city_name character varying(100) NOT NULL,
    birth_region character varying(100),
    geocoder_query character varying(200),
    geocoder_full_name character varying(255),
    birth_lat numeric(9,6) NOT NULL,
    birth_lng numeric(9,6) NOT NULL,
    birth_timezone character varying(50) NOT NULL,
    birth_country_code character varying(2),
    system_language character varying(10) DEFAULT 'ru'::character varying,
    geocoder_cache_key character varying(64),
    geocoder_source character varying(20) DEFAULT 'manual'::character varying,
    birth_datetime_local timestamp with time zone,
    birth_datetime_utc timestamp with time zone,
    julian_day numeric(15,6),
    planets jsonb DEFAULT '{}'::jsonb NOT NULL,
    houses jsonb DEFAULT '{}'::jsonb NOT NULL,
    aspects jsonb DEFAULT '[]'::jsonb NOT NULL,
    panchanga jsonb DEFAULT '{}'::jsonb NOT NULL,
    dasha jsonb DEFAULT '{}'::jsonb NOT NULL,
    arabic_parts jsonb DEFAULT '{}'::jsonb NOT NULL,
    fixed_stars jsonb DEFAULT '[]'::jsonb NOT NULL,
    planetary_hour jsonb DEFAULT '{}'::jsonb NOT NULL,
    ayanamsa numeric(10,6),
    sidereal_time numeric(8,4),
    void_of_course_moon boolean DEFAULT false,
    moon_phase_degrees numeric(6,2),
    moon_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    solar_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    lunar_returns jsonb DEFAULT '[]'::jsonb NOT NULL,
    solar_returns jsonb DEFAULT '[]'::jsonb NOT NULL,
    critical_degrees jsonb DEFAULT '[]'::jsonb NOT NULL,
    midpoints jsonb DEFAULT '{}'::jsonb NOT NULL,
    aspect_qualities jsonb DEFAULT '[]'::jsonb NOT NULL,
    patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    star_interpretations jsonb DEFAULT '[]'::jsonb NOT NULL,
    arabic_connections jsonb DEFAULT '{}'::jsonb NOT NULL,
    calculation_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    weekday character varying(20) DEFAULT 'Monday'::character varying,
    weekday_ruler character varying(20),
    ml_features jsonb DEFAULT '{}'::jsonb NOT NULL,
    house_system character varying(20) DEFAULT 'Placidus'::character varying,
    calculation_status character varying(20) DEFAULT 'success'::character varying,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT natal_charts_calculation_status_check CHECK (((calculation_status)::text = ANY (ARRAY[('pending'::character varying)::text, ('success'::character varying)::text, ('failed'::character varying)::text, ('partial'::character varying)::text]))),
    CONSTRAINT natal_charts_geocoder_source_check CHECK (((geocoder_source)::text = ANY (ARRAY[('manual'::character varying)::text, ('memory_cache'::character varying)::text, ('db_cache'::character varying)::text, ('api'::character varying)::text, ('nominatim'::character varying)::text, ('google'::character varying)::text, ('yandex'::character varying)::text])))
);


ALTER TABLE public.natal_charts OWNER TO postgres;

--
-- Name: TABLE natal_charts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.natal_charts IS 'Натальные астрологические карты';


--
-- Name: natal_charts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.natal_charts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.natal_charts_id_seq OWNER TO postgres;

--
-- Name: natal_charts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.natal_charts_id_seq OWNED BY public.natal_charts.id;


--
-- Name: optimal_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optimal_activities (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date NOT NULL,
    activity_indices smallint[] DEFAULT '{}'::smallint[] NOT NULL,
    activity_types public.activity_type[] DEFAULT '{}'::public.activity_type[] NOT NULL,
    activity_scores real[] DEFAULT '{}'::real[] NOT NULL,
    confidence_scores real[] DEFAULT '{}'::real[] NOT NULL,
    recommendations text[] DEFAULT '{}'::text[] NOT NULL,
    time_slots jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority_order smallint[] DEFAULT '{}'::smallint[] NOT NULL,
    energy_level real NOT NULL,
    energy_trend character varying(10),
    focus_areas text[] DEFAULT '{}'::text[],
    ml_features jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_vector real[] DEFAULT '{}'::real[] NOT NULL,
    model_version character varying(20) DEFAULT '1.0'::character varying,
    is_generated boolean DEFAULT true,
    is_approved boolean DEFAULT false,
    user_feedback smallint,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT optimal_activities_energy_level_check CHECK (((energy_level >= (0)::double precision) AND (energy_level <= (1)::double precision))),
    CONSTRAINT optimal_activities_energy_trend_check CHECK (((energy_trend)::text = ANY (ARRAY[('rising'::character varying)::text, ('falling'::character varying)::text, ('stable'::character varying)::text]))),
    CONSTRAINT optimal_activities_user_feedback_check CHECK (((user_feedback >= 1) AND (user_feedback <= 5)))
);


ALTER TABLE public.optimal_activities OWNER TO postgres;

--
-- Name: TABLE optimal_activities; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.optimal_activities IS 'Рекомендации оптимальных активностей';


--
-- Name: optimal_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optimal_activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optimal_activities_id_seq OWNER TO postgres;

--
-- Name: optimal_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optimal_activities_id_seq OWNED BY public.optimal_activities.id;


--
-- Name: profile_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profile_snapshots (
    id integer NOT NULL,
    user_id integer NOT NULL,
    snapshot_date date NOT NULL,
    axes jsonb NOT NULL,
    ml_features jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.profile_snapshots OWNER TO postgres;

--
-- Name: profile_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.profile_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_snapshots_id_seq OWNER TO postgres;

--
-- Name: profile_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.profile_snapshots_id_seq OWNED BY public.profile_snapshots.id;


--
-- Name: psychological_tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychological_tests (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    test_type public.test_type NOT NULL,
    test_version character varying(20) NOT NULL,
    test_name character varying(100) NOT NULL,
    questions jsonb DEFAULT '[]'::jsonb NOT NULL,
    answers jsonb DEFAULT '{}'::jsonb NOT NULL,
    raw_responses jsonb DEFAULT '{}'::jsonb NOT NULL,
    scores jsonb DEFAULT '{}'::jsonb NOT NULL,
    profile_type character varying(50),
    interpretation text,
    insights jsonb DEFAULT '{}'::jsonb NOT NULL,
    completion_percentage smallint DEFAULT 100 NOT NULL,
    time_spent_seconds integer,
    device_info jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'completed'::character varying,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT psychological_tests_completion_percentage_check CHECK (((completion_percentage >= 0) AND (completion_percentage <= 100))),
    CONSTRAINT psychological_tests_status_check CHECK (((status)::text = ANY (ARRAY[('started'::character varying)::text, ('in_progress'::character varying)::text, ('completed'::character varying)::text, ('abandoned'::character varying)::text])))
);


ALTER TABLE public.psychological_tests OWNER TO postgres;

--
-- Name: TABLE psychological_tests; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.psychological_tests IS 'Результаты психологических тестов пользователей';


--
-- Name: psychological_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.psychological_tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.psychological_tests_id_seq OWNER TO postgres;

--
-- Name: psychological_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.psychological_tests_id_seq OWNED BY public.psychological_tests.id;


--
-- Name: psyho_matrices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psyho_matrices (
    user_id bigint NOT NULL,
    first_number integer NOT NULL,
    second_number integer NOT NULL,
    third_number integer NOT NULL,
    fourth_number integer NOT NULL,
    matrix_digits jsonb DEFAULT '{}'::jsonb NOT NULL,
    matrix_3x3 jsonb DEFAULT '[[0, 0, 0], [0, 0, 0], [0, 0, 0]]'::jsonb NOT NULL,
    characteristics jsonb DEFAULT '{}'::jsonb NOT NULL,
    talent_codes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    strength_codes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    energy_level public.energy_level DEFAULT 'medium'::public.energy_level NOT NULL,
    life_purpose text,
    compatibility_hints jsonb DEFAULT '{}'::jsonb NOT NULL,
    additional jsonb DEFAULT '{}'::jsonb NOT NULL,
    karmic_analysis jsonb DEFAULT '{}'::jsonb NOT NULL,
    forecasting jsonb DEFAULT '{}'::jsonb NOT NULL,
    calculation_version character varying(20) DEFAULT '3.1'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT psyho_matrices_calculation_version_check CHECK (((calculation_version)::text = ANY (ARRAY[('1.0'::character varying)::text, ('2.0'::character varying)::text, ('3.0'::character varying)::text, ('3.1'::character varying)::text]))),
    CONSTRAINT psyho_matrices_first_number_check CHECK (((first_number >= 1) AND (first_number <= 99))),
    CONSTRAINT psyho_matrices_fourth_number_check CHECK ((((fourth_number >= 1) AND (fourth_number <= 9)) OR (fourth_number = ANY (ARRAY[11, 22, 33])))),
    CONSTRAINT psyho_matrices_second_number_check CHECK ((((second_number >= 1) AND (second_number <= 99)) OR (second_number = ANY (ARRAY[11, 22, 33])))),
    CONSTRAINT psyho_matrices_third_number_check CHECK (((third_number >= 1) AND (third_number <= 99)))
);


ALTER TABLE public.psyho_matrices OWNER TO postgres;

--
-- Name: TABLE psyho_matrices; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.psyho_matrices IS 'Нумерологические психоматрицы по методу Пифагора';


--
-- Name: COLUMN psyho_matrices.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.user_id IS 'ID пользователя (внешний ключ)';


--
-- Name: COLUMN psyho_matrices.first_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.first_number IS 'Первое число - сумма всех цифр даты рождения (1-99)';


--
-- Name: COLUMN psyho_matrices.second_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.second_number IS 'Второе число - редукция первого (1-9 или 11,22,33)';


--
-- Name: COLUMN psyho_matrices.third_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.third_number IS 'Третье число - первое минус удвоенный день (1-99)';


--
-- Name: COLUMN psyho_matrices.fourth_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.fourth_number IS 'Четвертое число - редукция третьего (1-9 или 11,22,33)';


--
-- Name: COLUMN psyho_matrices.matrix_digits; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.matrix_digits IS 'JSON объект с количеством каждой цифры 1-9';


--
-- Name: COLUMN psyho_matrices.matrix_3x3; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.matrix_3x3 IS 'Матрица 3x3 для позиционного анализа';


--
-- Name: COLUMN psyho_matrices.characteristics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.characteristics IS 'Детальный анализ всех характеристик';


--
-- Name: COLUMN psyho_matrices.talent_codes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.talent_codes IS 'Массив кодов талантов';


--
-- Name: COLUMN psyho_matrices.strength_codes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.strength_codes IS 'Массив кодов сильных сторон';


--
-- Name: COLUMN psyho_matrices.energy_level; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.energy_level IS 'Уровень энергии (very_low, low, medium, high, very_high)';


--
-- Name: COLUMN psyho_matrices.life_purpose; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.life_purpose IS 'Описание жизненного предназначения';


--
-- Name: COLUMN psyho_matrices.compatibility_hints; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.compatibility_hints IS 'Данные для анализа совместимости';


--
-- Name: COLUMN psyho_matrices.additional; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.additional IS 'Дополнительные нумерологические расчеты';


--
-- Name: COLUMN psyho_matrices.karmic_analysis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.karmic_analysis IS 'Кармический анализ (долги, задачи, прошлые жизни)';


--
-- Name: COLUMN psyho_matrices.forecasting; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.forecasting IS 'Прогностические данные (годы, периоды, рекомендации)';


--
-- Name: COLUMN psyho_matrices.calculation_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.calculation_version IS 'Версия алгоритма расчета';


--
-- Name: COLUMN psyho_matrices.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.created_at IS 'Время создания записи';


--
-- Name: COLUMN psyho_matrices.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.updated_at IS 'Время последнего обновления';


--
-- Name: recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recommendations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recommendations_id_seq OWNER TO postgres;

--
-- Name: recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recommendations_id_seq OWNED BY public.recommendations.id;


--
-- Name: system_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_audit_log (
    id bigint NOT NULL,
    action_type character varying(50) NOT NULL,
    action_name character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(100),
    user_id bigint,
    user_ip inet,
    user_agent text,
    session_id uuid,
    request_data jsonb,
    response_data jsonb,
    error_details text,
    stack_trace text,
    status_code integer,
    success boolean DEFAULT true,
    error_code character varying(50),
    duration_ms integer,
    memory_usage_kb integer,
    service_name character varying(50) NOT NULL,
    endpoint character varying(255),
    http_method character varying(10),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_audit_log_action_type_check CHECK (((action_type)::text = ANY (ARRAY[('create'::character varying)::text, ('read'::character varying)::text, ('update'::character varying)::text, ('delete'::character varying)::text, ('login'::character varying)::text, ('logout'::character varying)::text, ('error'::character varying)::text]))),
    CONSTRAINT system_audit_log_duration_ms_check CHECK ((duration_ms >= 0))
);


ALTER TABLE public.system_audit_log OWNER TO postgres;

--
-- Name: TABLE system_audit_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_audit_log IS 'Логирование действий в системе';


--
-- Name: system_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_audit_log_id_seq OWNER TO postgres;

--
-- Name: system_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_audit_log_id_seq OWNED BY public.system_audit_log.id;


--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_metrics (
    id bigint NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type character varying(50) NOT NULL,
    metric_value double precision NOT NULL,
    metric_labels jsonb DEFAULT '{}'::jsonb,
    service_name character varying(50) NOT NULL,
    hostname character varying(100),
    collected_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK (((metric_type)::text = ANY (ARRAY[('counter'::character varying)::text, ('gauge'::character varying)::text, ('histogram'::character varying)::text, ('summary'::character varying)::text])))
);


ALTER TABLE public.system_metrics OWNER TO postgres;

--
-- Name: TABLE system_metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_metrics IS 'Метрики производительности системы';


--
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_metrics_id_seq OWNER TO postgres;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_profiles (
    user_id bigint NOT NULL,
    full_name character varying(255),
    username character varying(100),
    language_code character varying(10) DEFAULT 'ru'::character varying,
    timezone character varying(50) DEFAULT 'Europe/Moscow'::character varying,
    birth_country_code character varying(2) DEFAULT 'RU'::character varying,
    system_language character varying(10) DEFAULT 'ru'::character varying,
    birth_timezone character varying(50) DEFAULT 'Europe/Moscow'::character varying,
    birth_date date NOT NULL,
    birth_time time without time zone NOT NULL,
    birth_region character varying(100),
    birth_city character varying(100) NOT NULL,
    birth_country character varying(100) DEFAULT 'Russia'::character varying,
    birth_lat numeric(9,6),
    birth_lng numeric(9,6),
    profession character varying(100),
    job_position character varying(100),
    geocoder_query character varying(200),
    geocoder_full_name character varying(255),
    geocoder_source character varying(20),
    current_city character varying(100),
    current_lat numeric(9,6),
    current_lng numeric(9,6),
    notification_enabled boolean DEFAULT true,
    daily_recommendations_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_profiles_birth_country_code_check CHECK (((birth_country_code)::text ~ '^[A-Z]{2}$'::text)),
    CONSTRAINT user_profiles_system_language_check CHECK (((system_language)::text = ANY (ARRAY[('ru'::character varying)::text, ('en'::character varying)::text, ('de'::character varying)::text, ('fr'::character varying)::text, ('es'::character varying)::text]))),
    CONSTRAINT valid_birth_date CHECK (((birth_date >= '1900-01-01'::date) AND (birth_date <= CURRENT_DATE))),
    CONSTRAINT valid_birth_time CHECK (((birth_time >= '00:00:00'::time without time zone) AND (birth_time < '24:00:00'::time without time zone)))
);


ALTER TABLE public.user_profiles OWNER TO postgres;

--
-- Name: TABLE user_profiles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_profiles IS 'Дополнительная информация о пользователях для расчётов';


--
-- Name: user_complete_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_complete_info AS
 SELECT u.id,
    u.telegram_id,
    u.status,
    COALESCE(u.is_premium, false) AS is_premium,
    u.created_at AS user_created,
    u.last_activity_at,
    up.full_name,
    up.username,
    up.language_code,
    up.birth_date,
    up.birth_city,
    up.profession,
    up.current_city,
    COALESCE(( SELECT count(*) AS count
           FROM public.natal_charts nc
          WHERE (nc.user_id = u.id)), (0)::bigint) AS natal_charts_count,
    COALESCE(( SELECT count(*) AS count
           FROM public.biorhythms b
          WHERE (b.user_id = u.id)), (0)::bigint) AS biorhythms_count,
    COALESCE(( SELECT count(*) AS count
           FROM public.recommendations r
          WHERE (r.user_id = u.id)), (0)::bigint) AS recommendations_count,
    COALESCE(( SELECT count(*) AS count
           FROM public.psychological_tests pt
          WHERE (pt.user_id = u.id)), (0)::bigint) AS tests_count
   FROM (public.users u
     LEFT JOIN public.user_profiles up ON ((u.id = up.user_id)));


ALTER TABLE public.user_complete_info OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: astro_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.astro_events ALTER COLUMN id SET DEFAULT nextval('public.astro_events_id_seq'::regclass);


--
-- Name: biorhythms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms ALTER COLUMN id SET DEFAULT nextval('public.biorhythms_id_seq'::regclass);


--
-- Name: calculation_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache ALTER COLUMN id SET DEFAULT nextval('public.calculation_cache_id_seq'::regclass);


--
-- Name: daily_forecast_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache ALTER COLUMN id SET DEFAULT nextval('public.daily_forecast_cache_id_seq'::regclass);


--
-- Name: forecast_feedback id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forecast_feedback ALTER COLUMN id SET DEFAULT nextval('public.forecast_feedback_id_seq'::regclass);


--
-- Name: magic_profiles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles ALTER COLUMN id SET DEFAULT nextval('public.magic_profiles_id_seq'::regclass);


--
-- Name: ml_model_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ml_model_metrics ALTER COLUMN id SET DEFAULT nextval('public.ml_model_metrics_id_seq'::regclass);


--
-- Name: natal_charts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.natal_charts ALTER COLUMN id SET DEFAULT nextval('public.natal_charts_id_seq'::regclass);


--
-- Name: optimal_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities ALTER COLUMN id SET DEFAULT nextval('public.optimal_activities_id_seq'::regclass);


--
-- Name: profile_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_snapshots ALTER COLUMN id SET DEFAULT nextval('public.profile_snapshots_id_seq'::regclass);


--
-- Name: psychological_tests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests ALTER COLUMN id SET DEFAULT nextval('public.psychological_tests_id_seq'::regclass);


--
-- Name: recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations ALTER COLUMN id SET DEFAULT nextval('public.recommendations_id_seq'::regclass);


--
-- Name: system_audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_audit_log ALTER COLUMN id SET DEFAULT nextval('public.system_audit_log_id_seq'::regclass);


--
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: astro_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.astro_events (id, event_date, event_time, event_type, event_name, description, significance_level, zodiac_sign, degree, planetary_aspects, general_recommendations, caution_areas, source, confidence, calculated_at, updated_at) FROM stdin;
\.


--
-- Data for Name: biorhythms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.biorhythms (id, user_id, calculation_date, profile_version, profile_calculated_at, days_analyzed, birth_physical, birth_emotional, birth_intellectual, birth_intuitive, system_stability, predictability, profile_data, calculated_at) FROM stdin;
1	1	2026-07-20	1.0	2026-07-20	1826	0	0	0	0	0.7416999936103821	0.9868999719619751	{"birth_phase": {"luck": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "social": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "creative": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "physical": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "emotional": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "intuitive": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "nine_year": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "spiritual": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "seven_year": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "eleven_year": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "intellectual": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}}, "base_periods": {"luck": 37, "social": 43, "creative": 45, "physical": 23, "emotional": 28, "intuitive": 38, "nine_year": 3285, "spiritual": 53, "seven_year": 2555, "eleven_year": 4015, "intellectual": 33}, "ml_indicators": {"luck_entropy": 0.8113, "luck_autocorr": 0.9797, "predictability": 0.9869, "social_entropy": 0.8129, "social_autocorr": 0.9765, "creative_entropy": 0.8205, "physical_entropy": 0.7872, "system_stability": 0.7417, "creative_autocorr": 0.9753, "emotional_entropy": 0.6582, "intuitive_entropy": 0.7496, "nine_year_entropy": 0.7263, "physical_autocorr": 0.9874, "spiritual_entropy": 0.8095, "emotional_autocorr": 0.9847, "intuitive_autocorr": 0.9792, "seven_year_entropy": 0.751, "spiritual_autocorr": 0.971, "eleven_year_entropy": 0.6417, "intellectual_entropy": 0.8072, "intellectual_autocorr": 0.982}, "cycle_statistics": {"luck": {"max": 0.999099, "min": -0.999099, "mean": 0.001921, "range": 1.998198, "median": 0.0, "std_dev": 0.706581, "peak_frequency": 78.96, "critical_frequency": 98.35}, "social": {"max": 0.999333, "min": -0.999333, "mean": -0.007215, "range": 1.998666, "median": 0.0, "std_dev": 0.707516, "peak_frequency": 75.56, "critical_frequency": 101.94}, "creative": {"max": 0.999391, "min": -0.999391, "mean": -0.006003, "range": 1.998782, "median": 0.0, "std_dev": 0.707117, "peak_frequency": 71.96, "critical_frequency": 97.15}, "physical": {"max": 0.997669, "min": -0.997669, "mean": 0.002392, "range": 1.995338, "median": 0.0, "std_dev": 0.707204, "peak_frequency": 79.76, "critical_frequency": 95.35}, "emotional": {"max": 1.0, "min": -1.0, "mean": 0.002879, "range": 2.0, "median": 0.0, "std_dev": 0.707958, "peak_frequency": 65.76, "critical_frequency": 130.73}, "intuitive": {"max": 0.996584, "min": -0.996584, "mean": -0.000861, "range": 1.993168, "median": 0.0, "std_dev": 0.707394, "peak_frequency": 76.76, "critical_frequency": 115.14}, "nine_year": {"max": 0.630249, "min": -1.0, "mean": -0.492826, "range": 1.630249, "median": -0.642421, "std_dev": 0.480901, "peak_frequency": 0.0, "critical_frequency": 94.35}, "spiritual": {"max": 0.999561, "min": -0.999561, "mean": 0.005108, "range": 1.999122, "median": 0.0, "std_dev": 0.707102, "peak_frequency": 76.56, "critical_frequency": 110.34}, "seven_year": {"max": 1.0, "min": -1.0, "mean": 0.007271, "range": 2.0, "median": 0.020901, "std_dev": 0.780258, "peak_frequency": 104.54, "critical_frequency": 146.72}, "eleven_year": {"max": 0.29447, "min": -1.0, "mean": -0.626356, "range": 1.29447, "median": -0.755494, "std_dev": 0.372648, "peak_frequency": 0.0, "critical_frequency": 115.14}, "intellectual": {"max": 0.998867, "min": -0.998867, "mean": 0.004715, "range": 1.997734, "median": 0.0, "std_dev": 0.707981, "peak_frequency": 78.36, "critical_frequency": 110.94}}, "cycle_correlations": {"social_luck": 0.0089, "creative_luck": -0.0082, "physical_luck": 0.001, "emotional_luck": 0.0017, "intuitive_luck": -0.1656, "luck_nine_year": 0.0076, "spiritual_luck": 0.0061, "creative_social": -0.036, "luck_seven_year": -0.004, "physical_social": -0.0001, "emotional_social": 0.0058, "intuitive_social": -0.0482, "luck_eleven_year": -0.0007, "social_nine_year": -0.014, "spiritual_social": -0.0012, "intellectual_luck": 0.0016, "physical_creative": 0.0044, "social_seven_year": 0.0006, "creative_nine_year": -0.013, "emotional_creative": 0.0102, "intuitive_creative": -0.0071, "physical_emotional": 0.0108, "physical_intuitive": -0.0026, "physical_nine_year": 0.0031, "physical_spiritual": -0.0018, "social_eleven_year": -0.0133, "spiritual_creative": -0.0189, "creative_seven_year": 0.0018, "emotional_intuitive": -0.0069, "emotional_nine_year": 0.0038, "emotional_spiritual": -0.005, "intellectual_social": 0.0064, "intuitive_nine_year": -0.0074, "intuitive_spiritual": -0.0052, "physical_seven_year": 0.0014, "spiritual_nine_year": 0.0081, "creative_eleven_year": -0.0094, "emotional_seven_year": 0.0017, "intuitive_seven_year": 0.0057, "physical_eleven_year": 0.0062, "seven_year_nine_year": -0.7522, "spiritual_seven_year": 0.0016, "emotional_eleven_year": 0.0076, "intellectual_creative": 0.0137, "intuitive_eleven_year": 0.0047, "nine_year_eleven_year": -0.154, "physical_intellectual": 0.0026, "spiritual_eleven_year": 0.0115, "emotional_intellectual": -0.0097, "intellectual_intuitive": -0.0211, "intellectual_nine_year": 0.0077, "intellectual_spiritual": -0.0039, "seven_year_eleven_year": 0.7491, "intellectual_seven_year": 0.0012, "intellectual_eleven_year": 0.0105}, "calculation_metadata": {"cycles_count": 11, "days_analyzed": 1826, "years_analyzed": 5.0, "use_extended_cycles": true}}	2026-07-20 12:49:40.161782+00
\.


--
-- Data for Name: calculation_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calculation_cache (id, cache_key, cache_group, data, data_hash, calculation_type, user_id, created_at, expires_at, last_accessed_at, access_count, is_valid) FROM stdin;
\.


--
-- Data for Name: daily_forecast_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_forecast_cache (id, user_id, forecast_date, axes_deltas, daily_axes, recommendations, background_risks, subtle_signals, signal_categories, rules_version, invalidated_at, created_at, expires_at) FROM stdin;
1	1	2026-07-20	{}	{"energy_will": {"daily": 0.0732, "delta": 0.024, "trend": "rising", "advice": "Отдыхай, избегай конфликтов, не начинай новое", "static": 0.0492}, "luck_talent": {"daily": 0.8707, "delta": 0.018, "trend": "stable", "advice": "Рискуй, пробуй новое, проявляй таланты", "static": 0.8527}, "karma_cycles": {"daily": 0.4968, "delta": -0.0032, "trend": "stable", "advice": "Кармический период нейтрален", "static": 0.5}, "destiny_mission": {"daily": 0.5519000000000001, "delta": 0.0519, "trend": "rising", "advice": "Нейтральный период для миссии", "static": 0.5}, "health_physical": {"daily": 0.7427, "delta": 0.0072, "trend": "stable", "advice": "Отличное здоровье, занимайся спортом, закаляйся", "static": 0.7355}, "intellect_logic": {"daily": 0.924, "delta": 0.0, "trend": "stable", "advice": "Учись, решай сложные задачи, планируй стратегию", "static": 0.924}, "work_discipline": {"daily": 0.7708, "delta": 0.0028, "trend": "stable", "advice": "Отличное время для рутинной работы, закрывай долги", "static": 0.768}, "social_relations": {"daily": 0.0657, "delta": 0.0108, "trend": "stable", "advice": "Побудь один, не начинай конфликтов, избегай новых знакомств", "static": 0.0549}, "emotions_intuition": {"daily": 0.8851, "delta": 0.0115, "trend": "stable", "advice": "Доверяй интуиции, занимайся творчеством, общайся", "static": 0.8736}}	{"summary": "✨ Повышены: миссия", "best_time": null, "moon_info": {"sign": null, "phase": "unknown", "nakshatra": "Свати", "void_of_course": false}, "dasha_info": {"mahadasha": "Sun", "antardasha": "Moon", "pratyaradasha": "Jupiter", "mahadasha_progress": 0.08261068005476951, "antardasha_progress": 0.3956043956043956, "pratyaradasha_progress": 0.7916666666666666}, "top_advice": "✅ миссия: Действуй по предназначению", "caution_advice": "✅ Особых предостережений нет", "planetary_hour": {"is_day": true, "planet": "Mercury", "hour_number": 7}, "financial_advice": {"emoji": "📊", "index": 57.4, "level": "medium", "advice": "Нейтральный фон — можно заниматься рутинными финансами, но избегай крупных рисков", "best_time": "Планетарный час Mercury (день) — благоприятен для финансов", "avoid_actions": ["Спонтанные крупные траты", "Сомнительные инвестиции"], "risk_warnings": [], "investment_hint": null, "planet_influence": {"Mars": -1.0, "Pluto": 1.0, "Venus": 0.5, "Saturn": 0.5, "Jupiter": 1.0, "Mercury": 1.0}, "favorable_actions": ["Планирование бюджета", "Рутинные платежи", "Анализ инвестиций"]}}	[]	{"weak_positive_axes": {"energy_will": 0.024}}	{"weak_negative": [], "weak_positive": [["energy_will", 0.024]], "medium_negative": [], "medium_positive": [["destiny_mission", 0.0519]], "strong_negative": [], "strong_positive": [], "critical_negative": [], "critical_positive": []}	v2.0	\N	2026-07-20 12:49:44.208447+00	2026-08-20 12:49:44.354522+00
2	1	2026-07-21	{}	{"energy_will": {"daily": 0.0732, "delta": 0.024, "trend": "rising", "advice": "Отдыхай, избегай конфликтов, не начинай новое", "static": 0.0492}, "luck_talent": {"daily": 0.8307, "delta": -0.022, "trend": "falling", "advice": "Рискуй, пробуй новое, проявляй таланты", "static": 0.8527}, "karma_cycles": {"daily": 0.4968, "delta": -0.0032, "trend": "stable", "advice": "Кармический период нейтрален", "static": 0.5}, "destiny_mission": {"daily": 0.5519000000000001, "delta": 0.0519, "trend": "rising", "advice": "Нейтральный период для миссии", "static": 0.5}, "health_physical": {"daily": 0.7427, "delta": 0.0072, "trend": "stable", "advice": "Отличное здоровье, занимайся спортом, закаляйся", "static": 0.7355}, "intellect_logic": {"daily": 0.8640000000000001, "delta": -0.06, "trend": "falling", "advice": "Учись, решай сложные задачи, планируй стратегию", "static": 0.924}, "work_discipline": {"daily": 0.6908, "delta": -0.0772, "trend": "falling", "advice": "Работоспособность в норме", "static": 0.768}, "social_relations": {"daily": 0.05, "delta": -0.038, "trend": "stable", "advice": "Побудь один, не начинай конфликтов, избегай новых знакомств", "static": 0.0549}, "emotions_intuition": {"daily": 0.8241, "delta": -0.0495, "trend": "falling", "advice": "Доверяй интуиции, занимайся творчеством, общайся", "static": 0.8736}}	{"summary": "📉 Снижены: дисциплина, интеллект, эмоции (фоновый спад ещё на 2 осях)", "best_time": null, "moon_info": {"sign": null, "phase": "unknown", "nakshatra": "Вишакха", "void_of_course": true}, "dasha_info": {"mahadasha": "Sun", "antardasha": "Moon", "pratyaradasha": "Jupiter", "mahadasha_progress": 0.08306709265175719, "antardasha_progress": 0.4010989010989011, "pratyaradasha_progress": 0.8333333333333334}, "top_advice": "✅ миссия: Действуй по предназначению", "caution_advice": "📉 дисциплина: Не планируй много, отдыхай\\n\\n📌 ОБЩЕЕ: снижена активность в большинстве сфер - отдохни сегодня", "planetary_hour": {"is_day": true, "planet": "Jupiter", "hour_number": 7}, "financial_advice": {"emoji": "📊", "index": 55.8, "level": "medium", "advice": "Нейтральный фон — можно заниматься рутинными финансами, но избегай крупных рисков", "best_time": "Планетарный час Jupiter (день) — благоприятен для финансов", "avoid_actions": ["Спонтанные крупные траты", "Сомнительные инвестиции"], "risk_warnings": ["🌑 Луна без курса — не начинай крупные финансовые проекты"], "investment_hint": null, "planet_influence": {"Mars": -1.0, "Pluto": 1.0, "Venus": 0.5, "Saturn": 0.5, "Jupiter": 1.0, "Mercury": 1.0}, "favorable_actions": ["Планирование бюджета", "Рутинные платежи", "Анализ инвестиций"]}}	["📉 Легкий спад: luck_talent, social_relations", "🎯 Нет критических сигналов, но следи за деталями"]	{"weak_negative_axes": {"luck_talent": -0.022, "social_relations": -0.038}, "weak_positive_axes": {"energy_will": 0.024}}	{"weak_negative": [["social_relations", -0.038], ["luck_talent", -0.022]], "weak_positive": [["energy_will", 0.024]], "medium_negative": [["work_discipline", -0.0772], ["intellect_logic", -0.06], ["emotions_intuition", -0.0495]], "medium_positive": [["destiny_mission", 0.0519]], "strong_negative": [], "strong_positive": [], "critical_negative": [], "critical_positive": []}	v2.0	\N	2026-07-20 12:49:47.873142+00	2026-08-20 12:49:47.932265+00
\.


--
-- Data for Name: forecast_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forecast_feedback (id, user_id, forecast_date, axis_name, predicted_score, user_rating, delta, comment, created_at) FROM stdin;
\.


--
-- Data for Name: magic_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.magic_profiles (id, user_id, axes, axis_count, data_sources, psychological_blueprint, ml_features, feature_vector, cluster_id, anomaly_score, profile_version, confidence_score, calculation_metadata, is_valid, validation_errors, calculated_at, updated_at) FROM stdin;
1	1	{"energy_will": {"static_potential": {"willpower_base": 0.0492, "leadership_quality": 0.0279, "initiative_tendency": 0.0652}, "calculated_metrics": {"stamina_level": 0.0721, "drive_intensity": 0.0279, "courage_quotient": 0.086}, "dynamic_modulators": {"entropy": 0.7872, "retrograde_penalty": 1.0}}, "luck_talent": {"special_gifts": {"fortune_sign": "Taurus", "fortune_house": 0, "spica_planets": [], "has_spica_conjunction": false}, "static_potential": {"luck_base": 0.8527, "creative_flow": 0.696, "talent_magnitude": 0.6505}, "calculated_metrics": {"opportunity_recognition": 0.738, "synchronicity_frequency": 0.8247}}, "karma_cycles": {"karmic_task": {"node_sign": "Cancer", "node_house": 4, "past_life_sign": "Cancer", "past_life_house": 4, "task_description": "Ваша кармическая задача — научиться заботиться, не растворяясь в других через работу с родом и домом"}, "long_cycles": {"nine_year_phase": "negative", "seven_year_phase": "positive", "eleven_year_phase": "negative", "nine_year_intensity": 0.4928, "seven_year_intensity": 0.0073, "eleven_year_intensity": 0.6264}, "transformative_potential": {"crisis_frequency": 0.776, "rebirth_capacity": 0.8101}}, "destiny_mission": {"fate_markers": {"has_yod": null, "yod_apex": null, "has_spica": [], "yod_planets": [], "spica_planets": [], "destiny_number": 1}, "life_purpose": {"has_stellium": true, "stellium_sign": "Libra", "stellium_planets": 3}, "mission_indicators": {"mission_clarity": 0.9334, "destiny_intensity": 0.9918}}, "health_physical": {"static_potential": {"recovery_speed": 0.7355, "constitution_strength": 0.8273}, "calculated_metrics": {"vitality_index": 0.8972, "immune_strength": 0.7859}, "vulnerability_areas": {"chronic_risk": 0.7481, "stress_susceptibility": 0.2926}}, "intellect_logic": {"thinking_styles": {"practical_focus": 0.4972, "analytical_depth": 0.8948, "creative_divergence": 0.4972}, "static_potential": {"iq_base": 0.924, "learning_speed": 0.6422, "abstract_thinking": 0.8563}, "calculated_metrics": {"curiosity_level": 0.7658, "skepticism_tendency": 0.9522}}, "work_discipline": {"work_styles": {"deadline_respect": 0.916, "overtime_willingness": 0.1447, "structured_preference": 0.9721}, "static_potential": {"work_ethic": 0.768, "discipline_base": 0.9158, "persistence_capacity": 0.9849}, "calculated_metrics": {"follow_through_ability": 0.916, "procrastination_tendency": 0.4971}}, "social_relations": {"static_potential": {"social_charm": 0.0549, "friendship_depth": 0.3566, "partnership_orientation": 0.4555}, "calculated_metrics": {"empathy_capacity": 0.258, "extroversion_level": 0.4555}, "relationship_patterns": {"conflict_approach": "passive", "commitment_readiness": 0.5913, "trust_building_speed": 0.2681}}, "emotions_intuition": {"static_potential": {"emotional_depth": 0.8736, "empathy_capacity": 0.9522, "intuitive_strength": 0.81}, "calculated_metrics": {"mood_variability": 0.6582, "emotional_stability": 0.5374, "intuition_reliability": 0.9544}, "dynamic_modulators": {"emotional_entropy": 0.6582, "intuition_luck_correlation": -0.1656}}}	9	{natal_chart,psyho_matrix,biorhythms_static,user_profile}	{"cognitive_style": {"creative": 0.4972, "practical": 0.4972, "analytical": 0.8948}, "social_dynamics": {"diplomacy": 0.0549, "leadership": 0.0279, "extroversion": 0.4555}, "core_personality": {"integrity_index": 0.4826, "openness_balance": 0.7879, "authenticity_level": 0.318, "dependability_score": 0.842}, "emotional_architecture": {"empathy": 0.258, "stability": 0.5374, "resilience": 0.3513}, "life_purpose_indicators": {"luck_factor": 0.8527, "destiny_intensity": 0.9918, "transformative_potential": 0.8101}}	{"big_five": {"openness": 0.78725, "neuroticism": 0.4626, "extraversion": 0.4555, "agreeableness": 0.25495, "conscientiousness": 0.8420000000000001}, "metadata": {"version": "2.0", "calculated_at": "2026-07-20T12:49:41.641564", "feature_count": 19}, "raw_features": {"empathy": 0.258, "iq_base": 0.924, "stamina": 0.0721, "vitality": 0.8972, "luck_base": 0.8527, "work_ethic": 0.768, "chronic_risk": 0.7481, "extroversion": 0.4555, "follow_through": 0.916, "learning_speed": 0.6422, "predictability": 0.9869, "drive_intensity": 0.0279, "system_stability": 0.7417, "talent_magnitude": 0.6505, "destiny_intensity": 0.9918, "emotional_stability": 0.5374, "intuition_luck_corr": -0.1656, "intuition_reliability": 0.9544, "transformative_potential": 0.8101}, "special_indicators": {"has_yod": null, "has_spica": [], "destiny_intensity": 0.9918}}	{0.7481,0.9918,0.0279,0.5374,0.258,0.4555,0.916,-0.1656,0.9544,0.924,0.6422,0.8527,0.9869,0.0721,0.7417,0.6505,0.8101,0.8972,0.768,0.78725,0.842,0.4555,0.25495,0.4626,0,0,0.9918}	\N	0	1.0	0.9	{"axis_count": 9, "data_sources": ["natal_chart", "psyho_matrix", "biorhythms_static", "user_profile"], "calculated_at": "2026-07-20T12:49:41.641779", "feature_count": 27, "confidence_score": 0.9, "calculation_time_ms": 2500}	t	{}	2026-07-20 12:49:41.641862+00	2026-07-20 12:49:41.641862+00
\.


--
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ml_model_metrics (id, model_name, model_version, inference_time_ms, memory_usage_mb, success_rate, input_size_bytes, output_size_bytes, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: natal_charts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.natal_charts (id, user_id, calculation_date, calculation_timestamp, calculation_time_ms, city_name, birth_region, geocoder_query, geocoder_full_name, birth_lat, birth_lng, birth_timezone, birth_country_code, system_language, geocoder_cache_key, geocoder_source, birth_datetime_local, birth_datetime_utc, julian_day, planets, houses, aspects, panchanga, dasha, arabic_parts, fixed_stars, planetary_hour, ayanamsa, sidereal_time, void_of_course_moon, moon_phase_degrees, moon_data, solar_data, lunar_returns, solar_returns, critical_degrees, midpoints, aspect_qualities, patterns, star_interpretations, arabic_connections, calculation_metadata, weekday, weekday_ruler, ml_features, house_system, calculation_status, error_message, created_at, updated_at) FROM stdin;
1	1	2026-07-20	2026-07-20 12:49:40.183919+00	160	Kaliningrad	Kaliningrad	Kaliningrad	Kaliningrad	54.710400	20.507000	Europe/Kaliningrad	RU	ru	\N	nominatim	1982-01-21 09:00:00+00	1982-01-21 09:00:00+00	2444990.875000	{"Sun": {"sign": "Aquarius", "house": 11, "dignity": {"face": "Face of Venus", "term": "Term of Mercury", "detriment": "Detriment"}, "distance": 0.984157827408657, "latitude": 0.000052773005306399096, "strength": 0.1, "longitude": 300.99605873455386, "retrograde": false, "speed_long": 1.0178261183441344, "dignity_score": -5, "sign_longitude": 0.9960587345538556}, "Mars": {"sign": "Libra", "house": 6, "dignity": {"face": "Face of Saturn", "term": "Term of Jupiter", "detriment": "Detriment"}, "distance": 1.090540196763626, "latitude": 2.6487333229605996, "strength": 0.1, "longitude": 194.29905813753223, "retrograde": false, "speed_long": 0.2935296962416013, "dignity_score": -5, "sign_longitude": 14.299058137532228}, "Moon": {"sign": "Sagittarius", "house": 8, "dignity": {"face": "Face (10-20°)", "term": "Term of Mercury"}, "distance": 0.002707973773506486, "latitude": 2.9479745099798444, "strength": 0.6, "longitude": 258.70281713477516, "retrograde": false, "speed_long": 11.833059712157997, "dignity_score": 1, "sign_longitude": 18.70281713477516}, "Pluto": {"sign": "Libra", "house": 7, "dignity": {}, "distance": 29.911330021664444, "latitude": 17.12498386398236, "strength": 0.6, "longitude": 206.9119407732214, "retrograde": false, "speed_long": 0.004883828256404934, "dignity_score": 0.0, "sign_longitude": 26.911940773221403}, "Venus": {"sign": "Aquarius", "house": 11, "dignity": {"face": "Face (0-10°)", "term": "Term of Mercury"}, "distance": 0.2679292758409045, "latitude": 6.3911631994687825, "strength": 0.45, "longitude": 301.07096264143536, "retrograde": true, "speed_long": -0.6156975593344438, "dignity_score": 1, "sign_longitude": 1.070962641435358}, "Chiron": {"sign": "Taurus", "house": 1, "dignity": {}, "distance": 15.88992298497471, "latitude": -2.668355909127477, "strength": 0.45, "longitude": 47.914058593768864, "retrograde": true, "speed_long": -0.00603205095328049, "dignity_score": 0.0, "sign_longitude": 17.914058593768864}, "Lilith": {"sign": "Capricorn", "house": 10, "dignity": {}, "distance": 0.00256955528979999, "latitude": 0.0, "strength": 0.45, "longitude": 292.10604318325306, "retrograde": true, "speed_long": -0.05293254388452924, "dignity_score": 0.0, "sign_longitude": 22.106043183253064}, "Saturn": {"sign": "Libra", "house": 7, "dignity": {"face": "Face of Jupiter", "term": "Term of Venus", "exaltation": "Exalted", "triplicity": "Triplicity Ruler (Night)"}, "distance": 9.444863537931932, "latitude": 2.518775844013067, "strength": 0.9, "longitude": 202.1617445252824, "retrograde": false, "speed_long": 0.0175389841532931, "dignity_score": 6, "sign_longitude": 22.161744525282387}, "Uranus": {"sign": "Sagittarius", "house": 8, "dignity": {}, "distance": 19.37010918157043, "latitude": 0.167438689513203, "strength": 0.6, "longitude": 243.6377153887525, "retrograde": false, "speed_long": 0.04007368479343309, "dignity_score": 0.0, "sign_longitude": 3.637715388752497}, "Jupiter": {"sign": "Scorpio", "house": 7, "dignity": {"face": "Face of Mars", "term": "Term of Venus"}, "distance": 5.48797681378907, "latitude": 1.2323947906361299, "strength": 0.6, "longitude": 218.58858005873557, "retrograde": false, "speed_long": 0.09937846580170845, "dignity_score": 0, "sign_longitude": 8.588580058735573}, "Mercury": {"sign": "Aquarius", "house": 12, "dignity": {"face": "Face (10-20°)", "term": "Term of Jupiter", "exaltation": "Near Exalted", "triplicity": "Triplicity Ruler (Day)"}, "distance": 0.8441014041526606, "latitude": 0.8055836473965764, "strength": 0.9, "longitude": 318.31743462204133, "retrograde": false, "speed_long": 0.342149885418775, "dignity_score": 6, "sign_longitude": 18.317434622041333}, "Neptune": {"sign": "Sagittarius", "house": 9, "dignity": {}, "distance": 31.073228417963804, "latitude": 1.2581486750653252, "strength": 0.6, "longitude": 265.8582223763413, "retrograde": false, "speed_long": 0.03234151762585904, "dignity_score": 0.0, "sign_longitude": 25.858222376341303}, "Mean_Node": {"sign": "Cancer", "house": 4, "dignity": {}, "distance": 0.00256955528979999, "latitude": 0.0, "strength": 0.45, "longitude": 112.10604318325306, "retrograde": true, "speed_long": -0.05293254388452924, "dignity_score": 0.0, "sign_longitude": 22.106043183253064}, "True_Node": {"sign": "Cancer", "house": 4, "dignity": {}, "distance": 0.0024586922779748807, "latitude": 0.0, "strength": 0.6, "longitude": 112.47265075593317, "retrograde": false, "speed_long": 0.01589947616811543, "dignity_score": 0.0, "sign_longitude": 22.472650755933174}}	{"1": {"cusp": 16.36302392904512, "sign": "Aries", "strength": 0.45, "position_in_sign": 16.36302392904512}, "2": {"cusp": 58.58440515069365, "sign": "Taurus", "strength": 0.3, "position_in_sign": 28.584405150693648}, "3": {"cusp": 79.1395332703196, "sign": "Gemini", "strength": 0.3, "position_in_sign": 19.139533270319603}, "4": {"cusp": 95.42328121602173, "sign": "Cancer", "strength": 0.525, "position_in_sign": 5.423281216021735}, "5": {"cusp": 112.81114248572146, "sign": "Cancer", "strength": 0.3, "position_in_sign": 22.81114248572146}, "6": {"cusp": 138.24379269638712, "sign": "Leo", "strength": 0.1, "position_in_sign": 18.243792696387118}, "7": {"cusp": 196.3630239290451, "sign": "Libra", "strength": 0.7, "position_in_sign": 16.363023929045113}, "8": {"cusp": 238.58440515069364, "sign": "Scorpio", "strength": 0.6, "position_in_sign": 28.58440515069364}, "9": {"cusp": 259.1395332703196, "sign": "Sagittarius", "strength": 0.6, "position_in_sign": 19.13953327031959}, "10": {"cusp": 275.42328121602173, "sign": "Capricorn", "strength": 0.45, "position_in_sign": 5.423281216021735}, "11": {"cusp": 292.81114248572146, "sign": "Capricorn", "strength": 0.275, "position_in_sign": 22.81114248572146}, "12": {"cusp": 318.2437926963871, "sign": "Aquarius", "strength": 0.9, "position_in_sign": 18.243792696387118}}	[{"orb": 0.07490390688150228, "angle": 0.07490390688150228, "aspect": "conjunction", "planet1": "Sun", "planet2": "Venus", "applying": true, "strength": 0.9906}, {"orb": 2.6416566541986413, "angle": 57.35834334580136, "aspect": "sextile", "planet1": "Sun", "planet2": "Uranus", "applying": true, "strength": 0.3396}, {"orb": 4.084117961332453, "angle": 94.08411796133245, "aspect": "square", "planet1": "Sun", "planet2": "Pluto", "applying": true, "strength": 0.3193}, {"orb": 8.523407978620696, "angle": 171.4765920213793, "aspect": "opposition", "planet1": "Sun", "planet2": "True_Node", "applying": true, "strength": 0}, {"orb": 8.890015551300792, "angle": 171.1099844486992, "aspect": "opposition", "planet1": "Sun", "planet2": "Mean_Node", "applying": true, "strength": 0}, {"orb": 8.890015551300792, "angle": 8.890015551300792, "aspect": "conjunction", "planet1": "Sun", "planet2": "Lilith", "applying": true, "strength": 0}, {"orb": 0.38538251273382684, "angle": 59.61461748726617, "aspect": "sextile", "planet1": "Moon", "planet2": "Mercury", "applying": true, "strength": 0.9037}, {"orb": 3.4589273905072275, "angle": 56.54107260949277, "aspect": "sextile", "planet1": "Moon", "planet2": "Saturn", "applying": true, "strength": 0.1353}, {"orb": 7.155405241566143, "angle": 7.155405241566143, "aspect": "conjunction", "planet1": "Moon", "planet2": "Neptune", "applying": true, "strength": 0.1056}, {"orb": 0.7887585410063025, "angle": 149.2112414589937, "aspect": "quincunx", "planet1": "Moon", "planet2": "Chiron", "applying": true, "strength": 0.7371}, {"orb": 4.018376484509105, "angle": 124.0183764845091, "aspect": "trine", "planet1": "Mercury", "planet2": "Mars", "applying": true, "strength": 0.3303}, {"orb": 3.8443099032410544, "angle": 116.15569009675895, "aspect": "trine", "planet1": "Mercury", "planet2": "Saturn", "applying": true, "strength": 0.3593}, {"orb": 0.40337602827247565, "angle": 89.59662397172752, "aspect": "square", "planet1": "Mercury", "planet2": "Chiron", "applying": true, "strength": 0.9328}, {"orb": 2.566752747317139, "angle": 57.43324725268286, "aspect": "sextile", "planet1": "Venus", "planet2": "Uranus", "applying": false, "strength": 0.3583}, {"orb": 4.159021868213955, "angle": 94.15902186821396, "aspect": "square", "planet1": "Venus", "planet2": "Pluto", "applying": false, "strength": 0.3068}, {"orb": 7.862686387750159, "angle": 7.862686387750159, "aspect": "conjunction", "planet1": "Mars", "planet2": "Saturn", "applying": true, "strength": 0.0172}, {"orb": 3.6964778510589156, "angle": 63.696477851058916, "aspect": "sextile", "planet1": "Saturn", "planet2": "Neptune", "applying": false, "strength": 0.0759}, {"orb": 4.750196247939016, "angle": 4.750196247939016, "aspect": "conjunction", "planet1": "Saturn", "planet2": "Pluto", "applying": true, "strength": 0.4062}, {"orb": 0.3109062306507866, "angle": 89.68909376934921, "aspect": "square", "planet1": "Saturn", "planet2": "True_Node", "applying": true, "strength": 0.9482}, {"orb": 0.05570134202932309, "angle": 90.05570134202932, "aspect": "square", "planet1": "Saturn", "planet2": "Mean_Node", "applying": true, "strength": 0.9907}, {"orb": 0.05570134202932309, "angle": 89.94429865797068, "aspect": "square", "planet1": "Saturn", "planet2": "Lilith", "applying": true, "strength": 0.9907}, {"orb": 1.0537183968801003, "angle": 58.9462816031199, "aspect": "sextile", "planet1": "Neptune", "planet2": "Pluto", "applying": true, "strength": 0.7366}, {"orb": 4.439290017288229, "angle": 94.43929001728823, "aspect": "square", "planet1": "Pluto", "planet2": "True_Node", "applying": false, "strength": 0.2601}, {"orb": 4.805897589968339, "angle": 94.80589758996834, "aspect": "square", "planet1": "Pluto", "planet2": "Mean_Node", "applying": true, "strength": 0.199}, {"orb": 4.805897589968339, "angle": 85.19410241003166, "aspect": "square", "planet1": "Pluto", "planet2": "Lilith", "applying": true, "strength": 0.199}, {"orb": 0.3666075726801097, "angle": 0.3666075726801097, "aspect": "conjunction", "planet1": "True_Node", "planet2": "Mean_Node", "applying": true, "strength": 0.9542}, {"orb": 0.3666075726800955, "angle": 179.6333924273199, "aspect": "opposition", "planet1": "True_Node", "planet2": "Lilith", "applying": true, "strength": 0.9542}, {"orb": 0.0, "angle": 180.0, "aspect": "opposition", "planet1": "Mean_Node", "planet2": "Lilith", "applying": false, "strength": 1}, {"orb": 4.191984589484207, "angle": 115.8080154105158, "aspect": "trine", "planet1": "Chiron", "planet2": "Lilith", "applying": true, "strength": 0.3013}]	{"yoga": 12, "tithi": 27, "karana": 9, "nakshatra": 18, "yoga_name": "Dhruva", "tithi_name": "Dwadashi", "karana_name": "Shakuni", "nakshatra_name": "Jyeshtha", "nakshatra_pada": 3}	{"years": 7.378210987928636, "planet": "Mercury", "end_date": "1989-06-08T06:23:51.072657+00:00", "start_date": "1982-01-21T09:00:00+00:00", "sub_periods": [{"years": 0.4303956409625037, "planet": "Ketu", "end_date": "1982-06-27T13:50:53.479238+00:00", "start_date": "1982-01-21T09:00:00+00:00", "sub_periods": [{"years": 0.02510641238947938, "planet": "Ketu", "end_date": "1982-01-30T13:04:58.119622+00:00", "start_date": "1982-01-21T09:00:00+00:00", "sub_periods": []}, {"years": 0.07173260682708396, "planet": "Venus", "end_date": "1982-02-25T17:53:27.032828+00:00", "start_date": "1982-01-30T13:04:58.119622+00:00", "sub_periods": []}, {"years": 0.021519782048125182, "planet": "Sun", "end_date": "1982-03-05T14:31:59.706790+00:00", "start_date": "1982-02-25T17:53:27.032828+00:00", "sub_periods": []}, {"years": 0.03586630341354198, "planet": "Moon", "end_date": "1982-03-18T16:56:14.163393+00:00", "start_date": "1982-03-05T14:31:59.706790+00:00", "sub_periods": []}, {"years": 0.02510641238947938, "planet": "Mars", "end_date": "1982-03-27T21:01:12.283015+00:00", "start_date": "1982-03-18T16:56:14.163393+00:00", "sub_periods": []}, {"years": 0.06455934614437556, "planet": "Rahu", "end_date": "1982-04-20T10:56:50.304901+00:00", "start_date": "1982-03-27T21:01:12.283015+00:00", "sub_periods": []}, {"years": 0.05738608546166716, "planet": "Jupiter", "end_date": "1982-05-11T09:59:37.435466+00:00", "start_date": "1982-04-20T10:56:50.304901+00:00", "sub_periods": []}, {"years": 0.06814597648572976, "planet": "Saturn", "end_date": "1982-06-05T07:21:40.903012+00:00", "start_date": "1982-05-11T09:59:37.435466+00:00", "sub_periods": []}, {"years": 0.060972715803021355, "planet": "Mercury", "end_date": "1982-06-27T13:50:53.479237+00:00", "start_date": "1982-06-05T07:21:40.903012+00:00", "sub_periods": []}]}, {"years": 1.2297018313214394, "planet": "Venus", "end_date": "1983-09-19T17:24:51.991347+00:00", "start_date": "1982-06-27T13:50:53.479238+00:00", "sub_periods": [{"years": 0.07173260682708398, "planet": "Ketu", "end_date": "1982-07-23T18:39:22.392444+00:00", "start_date": "1982-06-27T13:50:53.479238+00:00", "sub_periods": []}, {"years": 0.2049503052202399, "planet": "Venus", "end_date": "1982-10-06T15:15:02.144462+00:00", "start_date": "1982-07-23T18:39:22.392444+00:00", "sub_periods": []}, {"years": 0.061485091566071966, "planet": "Sun", "end_date": "1982-10-29T02:13:44.070067+00:00", "start_date": "1982-10-06T15:15:02.144462+00:00", "sub_periods": []}, {"years": 0.10247515261011995, "planet": "Moon", "end_date": "1982-12-05T12:31:33.946076+00:00", "start_date": "1982-10-29T02:13:44.070067+00:00", "sub_periods": []}, {"years": 0.07173260682708398, "planet": "Mars", "end_date": "1982-12-31T17:20:02.859282+00:00", "start_date": "1982-12-05T12:31:33.946076+00:00", "sub_periods": []}, {"years": 0.1844552746982159, "planet": "Rahu", "end_date": "1983-03-09T02:16:08.636098+00:00", "start_date": "1982-12-31T17:20:02.859282+00:00", "sub_periods": []}, {"years": 0.16396024417619193, "planet": "Jupiter", "end_date": "1983-05-07T23:32:40.437713+00:00", "start_date": "1983-03-09T02:16:08.636098+00:00", "sub_periods": []}, {"years": 0.1947027899592279, "planet": "Saturn", "end_date": "1983-07-18T02:18:33.202130+00:00", "start_date": "1983-05-07T23:32:40.437713+00:00", "sub_periods": []}, {"years": 0.1742077594372039, "planet": "Mercury", "end_date": "1983-09-19T17:24:51.991346+00:00", "start_date": "1983-07-18T02:18:33.202130+00:00", "sub_periods": []}]}, {"years": 0.3689105493964318, "planet": "Sun", "end_date": "1984-02-01T11:17:03.544980+00:00", "start_date": "1983-09-19T17:24:51.991347+00:00", "sub_periods": [{"years": 0.02151978204812519, "planet": "Ketu", "end_date": "1983-09-27T14:03:24.665309+00:00", "start_date": "1983-09-19T17:24:51.991347+00:00", "sub_periods": []}, {"years": 0.061485091566071966, "planet": "Venus", "end_date": "1983-10-20T01:02:06.590914+00:00", "start_date": "1983-09-27T14:03:24.665309+00:00", "sub_periods": []}, {"years": 0.01844552746982159, "planet": "Sun", "end_date": "1983-10-26T18:43:43.168596+00:00", "start_date": "1983-10-20T01:02:06.590914+00:00", "sub_periods": []}, {"years": 0.030742545783035983, "planet": "Moon", "end_date": "1983-11-07T00:13:04.131399+00:00", "start_date": "1983-10-26T18:43:43.168596+00:00", "sub_periods": []}, {"years": 0.02151978204812519, "planet": "Mars", "end_date": "1983-11-14T20:51:36.805361+00:00", "start_date": "1983-11-07T00:13:04.131399+00:00", "sub_periods": []}, {"years": 0.05533658240946478, "planet": "Rahu", "end_date": "1983-12-05T01:56:26.538406+00:00", "start_date": "1983-11-14T20:51:36.805361+00:00", "sub_periods": []}, {"years": 0.049188073252857574, "planet": "Jupiter", "end_date": "1983-12-23T01:07:24.078890+00:00", "start_date": "1983-12-05T01:56:26.538406+00:00", "sub_periods": []}, {"years": 0.05841083698776837, "planet": "Saturn", "end_date": "1984-01-13T09:09:09.908215+00:00", "start_date": "1983-12-23T01:07:24.078890+00:00", "sub_periods": []}, {"years": 0.05226232783116117, "planet": "Mercury", "end_date": "1984-02-01T11:17:03.544980+00:00", "start_date": "1984-01-13T09:09:09.908215+00:00", "sub_periods": []}]}, {"years": 0.6148509156607197, "planet": "Moon", "end_date": "1984-09-13T01:04:02.801035+00:00", "start_date": "1984-02-01T11:17:03.544980+00:00", "sub_periods": [{"years": 0.03586630341354199, "planet": "Ketu", "end_date": "1984-02-14T13:41:18.001583+00:00", "start_date": "1984-02-01T11:17:03.544980+00:00", "sub_periods": []}, {"years": 0.10247515261011995, "planet": "Venus", "end_date": "1984-03-22T23:59:07.877592+00:00", "start_date": "1984-02-14T13:41:18.001583+00:00", "sub_periods": []}, {"years": 0.030742545783035983, "planet": "Sun", "end_date": "1984-04-03T05:28:28.840395+00:00", "start_date": "1984-03-22T23:59:07.877592+00:00", "sub_periods": []}, {"years": 0.05123757630505998, "planet": "Moon", "end_date": "1984-04-21T22:37:23.778400+00:00", "start_date": "1984-04-03T05:28:28.840395+00:00", "sub_periods": []}, {"years": 0.03586630341354199, "planet": "Mars", "end_date": "1984-05-05T01:01:38.235003+00:00", "start_date": "1984-04-21T22:37:23.778400+00:00", "sub_periods": []}, {"years": 0.09222763734910795, "planet": "Rahu", "end_date": "1984-06-07T17:29:41.123411+00:00", "start_date": "1984-05-05T01:01:38.235003+00:00", "sub_periods": []}, {"years": 0.08198012208809596, "planet": "Jupiter", "end_date": "1984-07-07T16:07:57.024218+00:00", "start_date": "1984-06-07T17:29:41.123411+00:00", "sub_periods": []}, {"years": 0.09735139497961395, "planet": "Saturn", "end_date": "1984-08-12T05:30:53.406427+00:00", "start_date": "1984-07-07T16:07:57.024218+00:00", "sub_periods": []}, {"years": 0.08710387971860195, "planet": "Mercury", "end_date": "1984-09-13T01:04:02.801035+00:00", "start_date": "1984-08-12T05:30:53.406427+00:00", "sub_periods": []}]}, {"years": 0.4303956409625037, "planet": "Mars", "end_date": "1985-02-17T05:54:56.280273+00:00", "start_date": "1984-09-13T01:04:02.801035+00:00", "sub_periods": [{"years": 0.02510641238947938, "planet": "Ketu", "end_date": "1984-09-22T05:09:00.920657+00:00", "start_date": "1984-09-13T01:04:02.801035+00:00", "sub_periods": []}, {"years": 0.07173260682708396, "planet": "Venus", "end_date": "1984-10-18T09:57:29.833863+00:00", "start_date": "1984-09-22T05:09:00.920657+00:00", "sub_periods": []}, {"years": 0.021519782048125182, "planet": "Sun", "end_date": "1984-10-26T06:36:02.507825+00:00", "start_date": "1984-10-18T09:57:29.833863+00:00", "sub_periods": []}, {"years": 0.03586630341354198, "planet": "Moon", "end_date": "1984-11-08T09:00:16.964428+00:00", "start_date": "1984-10-26T06:36:02.507825+00:00", "sub_periods": []}, {"years": 0.02510641238947938, "planet": "Mars", "end_date": "1984-11-17T13:05:15.084050+00:00", "start_date": "1984-11-08T09:00:16.964428+00:00", "sub_periods": []}, {"years": 0.06455934614437556, "planet": "Rahu", "end_date": "1984-12-11T03:00:53.105936+00:00", "start_date": "1984-11-17T13:05:15.084050+00:00", "sub_periods": []}, {"years": 0.05738608546166716, "planet": "Jupiter", "end_date": "1985-01-01T02:03:40.236501+00:00", "start_date": "1984-12-11T03:00:53.105936+00:00", "sub_periods": []}, {"years": 0.06814597648572976, "planet": "Saturn", "end_date": "1985-01-25T23:25:43.704047+00:00", "start_date": "1985-01-01T02:03:40.236501+00:00", "sub_periods": []}, {"years": 0.060972715803021355, "planet": "Mercury", "end_date": "1985-02-17T05:54:56.280272+00:00", "start_date": "1985-01-25T23:25:43.704047+00:00", "sub_periods": []}]}, {"years": 1.1067316481892955, "planet": "Rahu", "end_date": "1986-03-28T11:31:30.941172+00:00", "start_date": "1985-02-17T05:54:56.280273+00:00", "sub_periods": [{"years": 0.06455934614437557, "planet": "Ketu", "end_date": "1985-03-12T19:50:34.302159+00:00", "start_date": "1985-02-17T05:54:56.280273+00:00", "sub_periods": []}, {"years": 0.18445527469821593, "planet": "Venus", "end_date": "1985-05-19T04:46:40.078975+00:00", "start_date": "1985-03-12T19:50:34.302159+00:00", "sub_periods": []}, {"years": 0.05533658240946478, "planet": "Sun", "end_date": "1985-06-08T09:51:29.812020+00:00", "start_date": "1985-05-19T04:46:40.078975+00:00", "sub_periods": []}, {"years": 0.09222763734910797, "planet": "Moon", "end_date": "1985-07-12T02:19:32.700428+00:00", "start_date": "1985-06-08T09:51:29.812020+00:00", "sub_periods": []}, {"years": 0.06455934614437557, "planet": "Mars", "end_date": "1985-08-04T16:15:10.722314+00:00", "start_date": "1985-07-12T02:19:32.700428+00:00", "sub_periods": []}, {"years": 0.16600974722839432, "planet": "Rahu", "end_date": "1985-10-04T07:29:39.921449+00:00", "start_date": "1985-08-04T16:15:10.722314+00:00", "sub_periods": []}, {"years": 0.14756421975857273, "planet": "Jupiter", "end_date": "1985-11-27T05:02:32.542902+00:00", "start_date": "1985-10-04T07:29:39.921449+00:00", "sub_periods": []}, {"years": 0.17523251096330514, "planet": "Saturn", "end_date": "1986-01-30T05:07:50.030878+00:00", "start_date": "1985-11-27T05:02:32.542902+00:00", "sub_periods": []}, {"years": 0.15678698349348352, "planet": "Mercury", "end_date": "1986-03-28T11:31:30.941172+00:00", "start_date": "1986-01-30T05:07:50.030878+00:00", "sub_periods": []}]}, {"years": 0.9837614650571515, "planet": "Jupiter", "end_date": "1987-03-22T19:10:41.750860+00:00", "start_date": "1986-03-28T11:31:30.941172+00:00", "sub_periods": [{"years": 0.057386085461667166, "planet": "Ketu", "end_date": "1986-04-18T10:34:18.071737+00:00", "start_date": "1986-03-28T11:31:30.941172+00:00", "sub_periods": []}, {"years": 0.16396024417619193, "planet": "Venus", "end_date": "1986-06-17T07:50:49.873352+00:00", "start_date": "1986-04-18T10:34:18.071737+00:00", "sub_periods": []}, {"years": 0.049188073252857574, "planet": "Sun", "end_date": "1986-07-05T07:01:47.413836+00:00", "start_date": "1986-06-17T07:50:49.873352+00:00", "sub_periods": []}, {"years": 0.08198012208809596, "planet": "Moon", "end_date": "1986-08-04T05:40:03.314643+00:00", "start_date": "1986-07-05T07:01:47.413836+00:00", "sub_periods": []}, {"years": 0.057386085461667166, "planet": "Mars", "end_date": "1986-08-25T04:42:50.445208+00:00", "start_date": "1986-08-04T05:40:03.314643+00:00", "sub_periods": []}, {"years": 0.14756421975857273, "planet": "Rahu", "end_date": "1986-10-18T02:15:43.066661+00:00", "start_date": "1986-08-25T04:42:50.445208+00:00", "sub_periods": []}, {"years": 0.13116819534095353, "planet": "Jupiter", "end_date": "1986-12-05T00:04:56.507953+00:00", "start_date": "1986-10-18T02:15:43.066661+00:00", "sub_periods": []}, {"years": 0.15576223196738231, "planet": "Saturn", "end_date": "1987-01-30T21:29:38.719487+00:00", "start_date": "1986-12-05T00:04:56.507953+00:00", "sub_periods": []}, {"years": 0.13936620754976312, "planet": "Mercury", "end_date": "1987-03-22T19:10:41.750859+00:00", "start_date": "1987-01-30T21:29:38.719487+00:00", "sub_periods": []}]}, {"years": 1.1682167397553676, "planet": "Saturn", "end_date": "1988-05-22T11:45:58.337364+00:00", "start_date": "1987-03-22T19:10:41.750860+00:00", "sub_periods": [{"years": 0.06814597648572977, "planet": "Ketu", "end_date": "1987-04-16T16:32:45.218406+00:00", "start_date": "1987-03-22T19:10:41.750860+00:00", "sub_periods": []}, {"years": 0.1947027899592279, "planet": "Venus", "end_date": "1987-06-26T19:18:37.982823+00:00", "start_date": "1987-04-16T16:32:45.218406+00:00", "sub_periods": []}, {"years": 0.05841083698776838, "planet": "Sun", "end_date": "1987-07-18T03:20:23.812148+00:00", "start_date": "1987-06-26T19:18:37.982823+00:00", "sub_periods": []}, {"years": 0.09735139497961395, "planet": "Moon", "end_date": "1987-08-22T16:43:20.194357+00:00", "start_date": "1987-07-18T03:20:23.812148+00:00", "sub_periods": []}, {"years": 0.06814597648572977, "planet": "Mars", "end_date": "1987-09-16T14:05:23.661903+00:00", "start_date": "1987-08-22T16:43:20.194357+00:00", "sub_periods": []}, {"years": 0.17523251096330514, "planet": "Rahu", "end_date": "1987-11-19T14:10:41.149879+00:00", "start_date": "1987-09-16T14:05:23.661903+00:00", "sub_periods": []}, {"years": 0.15576223196738234, "planet": "Jupiter", "end_date": "1988-01-15T11:35:23.361413+00:00", "start_date": "1987-11-19T14:10:41.149879+00:00", "sub_periods": []}, {"years": 0.18496765046126654, "planet": "Saturn", "end_date": "1988-03-23T01:00:58.487609+00:00", "start_date": "1988-01-15T11:35:23.361413+00:00", "sub_periods": []}, {"years": 0.16549737146534374, "planet": "Mercury", "end_date": "1988-05-22T11:45:58.337364+00:00", "start_date": "1988-03-23T01:00:58.487609+00:00", "sub_periods": []}]}, {"years": 1.0452465566232234, "planet": "Mercury", "end_date": "1989-06-08T06:23:51.072657+00:00", "start_date": "1988-05-22T11:45:58.337364+00:00", "sub_periods": [{"years": 0.06097271580302136, "planet": "Ketu", "end_date": "1988-06-13T18:15:10.913589+00:00", "start_date": "1988-05-22T11:45:58.337364+00:00", "sub_periods": []}, {"years": 0.1742077594372039, "planet": "Venus", "end_date": "1988-08-16T09:21:29.702805+00:00", "start_date": "1988-06-13T18:15:10.913589+00:00", "sub_periods": []}, {"years": 0.052262327831161165, "planet": "Sun", "end_date": "1988-09-04T11:29:23.339570+00:00", "start_date": "1988-08-16T09:21:29.702805+00:00", "sub_periods": []}, {"years": 0.08710387971860195, "planet": "Moon", "end_date": "1988-10-06T07:02:32.734178+00:00", "start_date": "1988-09-04T11:29:23.339570+00:00", "sub_periods": []}, {"years": 0.06097271580302136, "planet": "Mars", "end_date": "1988-10-28T13:31:45.310403+00:00", "start_date": "1988-10-06T07:02:32.734178+00:00", "sub_periods": []}, {"years": 0.1567869834934835, "planet": "Rahu", "end_date": "1988-12-24T19:55:26.220697+00:00", "start_date": "1988-10-28T13:31:45.310403+00:00", "sub_periods": []}, {"years": 0.13936620754976312, "planet": "Jupiter", "end_date": "1989-02-13T17:36:29.252069+00:00", "start_date": "1988-12-24T19:55:26.220697+00:00", "sub_periods": []}, {"years": 0.1654973714653437, "planet": "Saturn", "end_date": "1989-04-15T04:21:29.101824+00:00", "start_date": "1989-02-13T17:36:29.252069+00:00", "sub_periods": []}, {"years": 0.1480765955216233, "planet": "Mercury", "end_date": "1989-06-08T06:23:51.072657+00:00", "start_date": "1989-04-15T04:21:29.101824+00:00", "sub_periods": []}]}]}	{"Art": {"sign": "Pisces", "longitude": 359.11655194843917, "interpretation": "Искусство, творчество, эстетика, гармония"}, "Gain": {"sign": "Taurus", "longitude": 40.65254585024846, "interpretation": "Прибыль, приобретения, выгода"}, "Home": {"sign": "Gemini", "longitude": 72.90409653853791, "interpretation": "Дом, семья, корни, недвижимость"}, "Loss": {"sign": "Capricorn", "longitude": 277.45380581289214, "interpretation": "Потери, утраты, расставания"}, "Love": {"sign": "Aries", "longitude": 16.437927835926644, "interpretation": "Любовные отношения, романтика"}, "Risk": {"sign": "Pisces", "longitude": 352.07350200784174, "interpretation": "Риск, авантюра, опасность"}, "Soul": {"sign": "Taurus", "longitude": 58.65626552882384, "interpretation": "Душа, внутренняя сущность, истинное Я"}, "Death": {"sign": "Aquarius", "longitude": 319.82195131955234, "interpretation": "Трансформация, потери"}, "Faith": {"sign": "Capricorn", "longitude": 293.95554525322683, "interpretation": "Религия, вера, убеждения"}, "Karma": {"sign": "Aquarius", "longitude": 319.82195131955234, "interpretation": "Карма, долги, уроки прошлого"}, "Magic": {"sign": "Aries", "longitude": 23.518429170611284, "interpretation": "Магия, мистика, оккультные способности"}, "Power": {"sign": "Capricorn", "longitude": 282.27890596771266, "interpretation": "Власть, влияние, трансформация"}, "Truth": {"sign": "Taurus", "longitude": 51.500860287257694, "interpretation": "Истина, правда, реальность"}, "Career": {"sign": "Pisces", "longitude": 359.9361883955919, "interpretation": "Карьера, призвание, социальный статус, достижения"}, "Change": {"sign": "Aries", "longitude": 1.2979221830224787, "interpretation": "Перемены, изменения, трансформация"}, "Enmity": {"sign": "Aries", "longitude": 8.500337541294954, "interpretation": "Вражда, конфликты, соперничество, борьба"}, "Father": {"sign": "Sagittarius", "longitude": 244.45498612506105, "interpretation": "Отношения с отцом"}, "Genius": {"sign": "Cancer", "longitude": 91.04274316233398, "interpretation": "Гениальность, озарения, инсайты"}, "Mother": {"sign": "Pisces", "longitude": 357.6120352509281, "interpretation": "Отношения с матерью"}, "Reason": {"sign": "Gemini", "longitude": 75.97764141631131, "interpretation": "Разум, логика, рациональное мышление"}, "Spirit": {"sign": "Pisces", "longitude": 334.06978232926645, "interpretation": "Духовность, внутренний мир, философия"}, "Travel": {"sign": "Pisces", "longitude": 336.2487868530055, "interpretation": "Путешествия, перемещения, экспансия, дальние поездки"}, "Wisdom": {"sign": "Capricorn", "longitude": 276.63416936573935, "interpretation": "Мудрость, знание, философия"}, "Courage": {"sign": "Sagittarius", "longitude": 252.344647444536, "interpretation": "Смелость, решительность, сила духа"}, "Destiny": {"sign": "Capricorn", "longitude": 277.52870971977364, "interpretation": "Судьба, предназначение, рок, фатум"}, "Fortune": {"sign": "Taurus", "longitude": 58.65626552882384, "interpretation": "Материальное благополучие, успех, удача"}, "Freedom": {"sign": "Taurus", "longitude": 57.83899479251525, "interpretation": "Свобода, независимость, освобождение"}, "Healing": {"sign": "Virgo", "longitude": 165.57426538803884, "interpretation": "Исцеление, целительство, восстановление"}, "Passion": {"sign": "Sagittarius", "longitude": 269.591119425142, "interpretation": "Страсть, творческая энергия"}, "Science": {"sign": "Leo", "longitude": 132.5187140258041, "interpretation": "Наука, исследования, методология, открытия"}, "Secrets": {"sign": "Sagittarius", "longitude": 264.9575300802252, "interpretation": "Тайны, секреты, скрытая информация"}, "Service": {"sign": "Aquarius", "longitude": 316.74840644177897, "interpretation": "Служение, помощь, альтруизм"}, "Victory": {"sign": "Taurus", "longitude": 32.7898594624983, "interpretation": "Победа, достижения, триумф"}, "Children": {"sign": "Capricorn", "longitude": 293.8806413463453, "interpretation": "Дети, творчество"}, "Commerce": {"sign": "Taurus", "longitude": 33.68439981653262, "interpretation": "Бизнес, торговля, коммуникации"}, "Illusion": {"sign": "Aquarius", "longitude": 323.9038116833451, "interpretation": "Иллюзии, заблуждения, обман"}, "Learning": {"sign": "Cancer", "longitude": 116.0918784923509, "interpretation": "Обучение, образование, познание"}, "Marriage": {"sign": "Cancer", "longitude": 115.27224204519811, "interpretation": "Брак, партнерство"}, "Sickness": {"sign": "Aries", "longitude": 8.500337541294954, "interpretation": "Здоровье, болезни"}, "Teaching": {"sign": "Taurus", "longitude": 32.7898594624983, "interpretation": "Учительство, наставничество, передача знаний"}, "Abundance": {"sign": "Capricorn", "longitude": 293.8806413463453, "interpretation": "Изобилие, процветание, богатство"}, "Intuition": {"sign": "Aquarius", "longitude": 316.74840644177897, "interpretation": "Интуиция, предчувствия, подсознание"}, "Necessity": {"sign": "Capricorn", "longitude": 277.52870971977364, "interpretation": "Необходимость, обязательства, кармические долги"}, "Stability": {"sign": "Aquarius", "longitude": 319.82195131955234, "interpretation": "Стабильность, устойчивость, надежность"}, "Creativity": {"sign": "Leo", "longitude": 123.13492843294827, "interpretation": "Творчество, креативность, самовыражение"}, "Discipline": {"sign": "Aries", "longitude": 24.225710316795272, "interpretation": "Дисциплина, порядок, структура"}, "Friendship": {"sign": "Pisces", "longitude": 333.99487842238494, "interpretation": "Дружба, социальные связи, единомышленники"}, "Leadership": {"sign": "Cancer", "longitude": 115.19733813831661, "interpretation": "Лидерство, управление, руководство"}, "Inspiration": {"sign": "Pisces", "longitude": 341.1502836639511, "interpretation": "Вдохновение, идеалы, мечты"}, "Imprisonment": {"sign": "Aries", "longitude": 24.225710316795272, "interpretation": "Ограничения, тюрьма, изоляция, заточение"}, "Communication": {"sign": "Taurus", "longitude": 33.609495909651116, "interpretation": "Коммуникация, общение, связь"}}	[{"name": "Regulus", "latitude": "R", "longitude": 149.58055722095173, "magnitude": 1.35, "conjunctions": [], "constellation": "Leo"}, {"name": "Spica", "latitude": "S", "longitude": 203.5874866211259, "magnitude": 0.98, "conjunctions": [], "constellation": "Virgo"}, {"name": "Antares", "latitude": "A", "longitude": 249.50394326980955, "magnitude": 0.96, "conjunctions": [], "constellation": "Scorpio"}, {"name": "Sirius", "latitude": "S", "longitude": 103.83736713679117, "magnitude": -1.46, "conjunctions": [], "constellation": "Canis Major"}, {"name": "Vega", "latitude": "V", "longitude": 285.04886531415843, "magnitude": 0.03, "conjunctions": [], "constellation": "Lyra"}, {"name": "Aldebaran", "latitude": "A", "longitude": 69.53778988525181, "magnitude": 0.87, "conjunctions": [], "constellation": "Taurus"}, {"name": "Rigel", "latitude": "R", "longitude": 76.57944031888346, "magnitude": 0.18, "conjunctions": [], "constellation": "Orion"}, {"name": "Betelgeuse", "latitude": "B", "longitude": 88.50479830634764, "magnitude": 0.45, "conjunctions": [], "constellation": "Orion"}, {"name": "Procyon", "latitude": "P", "longitude": 115.53978575621976, "magnitude": 0.34, "conjunctions": [], "constellation": "Canis Minor"}, {"name": "Achernar", "latitude": "A", "longitude": 345.04413199475914, "magnitude": 0.46, "conjunctions": [], "constellation": "Eridanus"}, {"name": "Hadar", "latitude": "H", "longitude": 233.53560896584307, "magnitude": 0.61, "conjunctions": [], "constellation": "Centaurus"}, {"name": "Altair", "latitude": "A", "longitude": 301.51230921983614, "magnitude": 0.77, "conjunctions": [{"orb": 0.5162504852822849, "planet": "Sun"}, {"orb": 0.4413465784007826, "planet": "Venus"}], "constellation": "Aquila"}, {"name": "Acrux", "latitude": "A", "longitude": 221.61554136920645, "magnitude": 0.77, "conjunctions": [], "constellation": "Crux"}, {"name": "Fomalhaut", "latitude": "F", "longitude": 333.59814853732087, "magnitude": 1.17, "conjunctions": [], "constellation": "Piscis Austrinus"}]	{"is_day": true, "planet": "Venus", "sunset": "1982-01-21T18:00:00+00:00", "sunrise": "1982-01-21T06:00:00+00:00", "day_hours": 12.0, "hour_number": 4, "night_hours": 12.0}	24.489649	3831.0120	f	317.71	{"sign": "Sagittarius", "house": 8, "tithi": 0, "is_void": false, "age_days": 26.06, "nakshatra": "", "next_phase": "New Moon", "phase_name": "New Moon", "distance_km": 405107, "phase_angle": 317.7067584002213, "illumination": 0, "is_blue_moon": false, "is_super_moon": false, "nakshatra_pada": 0, "is_eclipse_season": false, "days_to_next_phase": 26.06}	{"sign": "Aquarius", "house": 11, "season": "winter", "sunset": null, "dignity": {"face": "Face of Venus", "term": "Term of Mercury", "detriment": "Detriment"}, "sunrise": null, "day_length": 12, "is_equinox": false, "declination": 0.0001, "distance_km": 147227915, "is_solstice": false, "right_ascension": 20.0664}	[]	[]	[{"sign": "Aquarius", "degree": 0.9960587345538556, "planet": "Sun", "critical_degree": 0}, {"sign": "Sagittarius", "degree": 25.858222376341303, "planet": "Neptune", "critical_degree": 26}, {"sign": "Libra", "degree": 26.911940773221403, "planet": "Pluto", "critical_degree": 26}]	{"Sun_Mars": 247.64755843604303, "Sun_Moon": 279.8494379346645, "Moon_Mars": 226.5009376361537, "Sun_Pluto": 253.95399975388762, "Sun_Venus": 301.03351068799464, "Mars_Pluto": 200.60549945537682, "Moon_Pluto": 232.8073789539983, "Moon_Venus": 279.88688988810526, "Sun_Chiron": 354.45505866416136, "Sun_Lilith": 296.5510509589035, "Sun_Saturn": 251.5789016299181, "Sun_Uranus": 272.3168870616532, "Venus_Mars": 247.6850103894838, "Mars_Chiron": 121.10655836565054, "Mars_Lilith": 243.20255066039266, "Mars_Saturn": 198.2304013314073, "Mars_Uranus": 218.96838676314235, "Moon_Chiron": 333.30843786427204, "Moon_Lilith": 275.4044301590141, "Moon_Saturn": 230.4322808300288, "Moon_Uranus": 251.17026626176383, "Sun_Jupiter": 259.7923193966447, "Sun_Mercury": 309.6567466782976, "Sun_Neptune": 283.4271405554476, "Venus_Pluto": 253.9914517073284, "Mars_Jupiter": 206.4438190981339, "Mars_Neptune": 230.07864025693675, "Mercury_Mars": 256.3082463797868, "Moon_Jupiter": 238.64569859675538, "Moon_Mercury": 288.51012587840825, "Moon_Neptune": 262.2805197555582, "Pluto_Chiron": 127.41299968349513, "Pluto_Lilith": 249.50899197823725, "Saturn_Pluto": 204.5368426492519, "Uranus_Pluto": 225.27482808098694, "Venus_Chiron": 354.4925106176021, "Venus_Lilith": 296.5885029123442, "Venus_Saturn": 251.6163535833589, "Venus_Uranus": 272.35433901509396, "Chiron_Lilith": 350.01005088851093, "Jupiter_Pluto": 212.7502604159785, "Mercury_Pluto": 262.6146876976314, "Mercury_Venus": 309.69419863173835, "Neptune_Pluto": 236.38508157478134, "Saturn_Chiron": 125.03790155952562, "Saturn_Lilith": 247.13389385426774, "Saturn_Uranus": 222.89972995701743, "Sun_Mean_Node": 26.551050958903488, "Sun_True_Node": 26.734354745243536, "Uranus_Chiron": 325.7758869912607, "Uranus_Lilith": 267.8718792860028, "Venus_Jupiter": 259.8297713500855, "Venus_Neptune": 283.46459250888836, "Jupiter_Chiron": 133.25131932625223, "Jupiter_Lilith": 255.34731162099433, "Jupiter_Saturn": 210.37516229200898, "Jupiter_Uranus": 231.11314772374402, "Mars_Mean_Node": 153.20255066039266, "Mars_True_Node": 153.3858544467327, "Mercury_Chiron": 3.1157466079050664, "Mercury_Lilith": 305.2117389026472, "Mercury_Saturn": 260.2395895736619, "Mercury_Uranus": 280.97757500539694, "Moon_Mean_Node": 185.4044301590141, "Moon_True_Node": 185.58773394535416, "Neptune_Chiron": 336.8861404850551, "Neptune_Lilith": 278.9821327797972, "Saturn_Neptune": 234.00998345081183, "Uranus_Neptune": 254.7479688825469, "Jupiter_Neptune": 242.22340121753842, "Mercury_Jupiter": 268.45300734038847, "Mercury_Neptune": 292.08782849919135, "Pluto_Mean_Node": 159.50899197823725, "Pluto_True_Node": 159.6922957645773, "Venus_Mean_Node": 26.58850291234421, "Venus_True_Node": 26.77180669868426, "Mean_Node_Chiron": 80.01005088851096, "Mean_Node_Lilith": 202.10604318325306, "Saturn_Mean_Node": 157.13389385426774, "Saturn_True_Node": 157.3171976406078, "True_Node_Chiron": 80.19335467485102, "True_Node_Lilith": 202.2893469695931, "Uranus_Mean_Node": 177.87187928600278, "Uranus_True_Node": 178.05518307234283, "Jupiter_Mean_Node": 165.34731162099433, "Jupiter_True_Node": 165.53061540733438, "Mercury_Mean_Node": 35.2117389026472, "Mercury_True_Node": 35.395042688987246, "Neptune_Mean_Node": 188.98213277979718, "Neptune_True_Node": 189.16543656613723, "True_Node_Mean_Node": 112.28934696959311}	[{"orb": 0.07490390688150228, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.9906370116398122, "psychological": "интеграция качеств. творческая гармония"}, {"orb": 2.6416566541986413, "type": "sextile", "nature": "возможность", "applying": true, "strength": 0.3395858364503397, "psychological": "шанс, потенциал. "}, {"orb": 4.084117961332453, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.3193136731112579, "psychological": "мотивация, действие. "}, {"orb": 8.523407978620696, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0, "psychological": "осознание через других. "}, {"orb": 8.890015551300792, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0, "psychological": "осознание через других. "}, {"orb": 8.890015551300792, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0, "psychological": "интеграция качеств. "}, {"orb": 0.38538251273382684, "type": "sextile", "nature": "возможность", "applying": true, "strength": 0.9036543718165433, "psychological": "шанс, потенциал. "}, {"orb": 3.4589273905072275, "type": "sextile", "nature": "возможность", "applying": true, "strength": 0.13526815237319312, "psychological": "шанс, потенциал. "}, {"orb": 7.155405241566143, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.10557434480423211, "psychological": "интеграция качеств. экстрасенсорика"}, {"orb": 0.7887585410063025, "type": "quincunx", "nature": "настройка/адаптация", "applying": true, "strength": 0.7370804863312326, "psychological": "гибкость, обучение. "}, {"orb": 4.018376484509105, "type": "trine", "nature": "гармония/талант", "applying": true, "strength": 0.33027058591514924, "psychological": "легкость, поток. "}, {"orb": 3.8443099032410544, "type": "trine", "nature": "гармония/талант", "applying": true, "strength": 0.35928168279315764, "psychological": "легкость, поток. "}, {"orb": 0.40337602827247565, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.9327706619545874, "psychological": "мотивация, действие. "}, {"orb": 2.566752747317139, "type": "sextile", "nature": "возможность", "applying": false, "strength": 0.35831181317071525, "psychological": "шанс, потенциал. "}, {"orb": 4.159021868213955, "type": "square", "nature": "кризис/рост", "applying": false, "strength": 0.30682968863100746, "psychological": "мотивация, действие. "}, {"orb": 7.862686387750159, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.017164201531230106, "psychological": "интеграция качеств. дисциплина"}, {"orb": 3.6964778510589156, "type": "sextile", "nature": "возможность", "applying": false, "strength": 0.0758805372352711, "psychological": "шанс, потенциал. "}, {"orb": 4.750196247939016, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.406225469007623, "psychological": "интеграция качеств. трансформация"}, {"orb": 0.3109062306507866, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.9481822948915356, "psychological": "мотивация, действие. "}, {"orb": 0.05570134202932309, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.9907164429951129, "psychological": "мотивация, действие. "}, {"orb": 0.05570134202932309, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.9907164429951129, "psychological": "мотивация, действие. "}, {"orb": 1.0537183968801003, "type": "sextile", "nature": "возможность", "applying": true, "strength": 0.7365704007799749, "psychological": "шанс, потенциал. "}, {"orb": 4.439290017288229, "type": "square", "nature": "кризис/рост", "applying": false, "strength": 0.26011833045196175, "psychological": "мотивация, действие. "}, {"orb": 4.805897589968339, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.19901706833861021, "psychological": "мотивация, действие. "}, {"orb": 4.805897589968339, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.19901706833861021, "psychological": "мотивация, действие. "}, {"orb": 0.3666075726801097, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.9541740534149863, "psychological": "интеграция качеств. "}, {"orb": 0.3666075726800955, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.9541740534149881, "psychological": "осознание через других. "}, {"orb": 0.0, "type": "opposition", "nature": "напряжение/проекция", "applying": false, "strength": 1, "psychological": "осознание через других. "}, {"orb": 4.191984589484207, "type": "trine", "nature": "гармония/талант", "applying": true, "strength": 0.30133590175263214, "psychological": "легкость, поток. "}]	{"yod": null, "bowl": null, "kite": null, "bucket": {"sign": "Aquarius", "bucket": ["Sun", "Mercury", "Venus"], "handle": "True_Node", "description": "Корзина: стеллмум в Aquarius с ручкой на True_Node"}, "bundle": null, "castle": null, "seesaw": {"left_group": ["True_Node", "Mean_Node", "Chiron"], "description": "Качели: 3 vs 11 планет", "oppositions": 4, "right_group": ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "Lilith"]}, "splash": null, "stellium": {"by_sign": {"Libra": 3, "Aquarius": 3, "Sagittarius": 3}, "by_house": {"7": 3}}, "t_square": {"apex": "Pluto", "base": ["Sun", "True_Node"], "planets": ["Sun", "True_Node", "Pluto"], "description": "Тау-квадрат с вершиной на Pluto"}, "locomotive": {"planets": ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "True_Node", "Mean_Node", "Chiron", "Lilith"], "gap_size": 89.59662397172752, "gap_start": 318.31743462204133, "description": "Локомотив: пустой сектор 89.6°"}, "grand_cross": null, "grand_trine": [], "mystic_rectangle": {"confidence": "low", "description": "Мистический прямоугольник (возможен)"}}	[{"orb": 0.5162504852822849, "star": "Altair", "planet": "Sun", "meaning": "полет, свобода", "negative": "безрассудство", "positive": "независимость, смелость"}, {"orb": 0.4413465784007826, "star": "Altair", "planet": "Venus", "meaning": "полет, свобода", "negative": "безрассудство", "positive": "независимость, смелость"}]	{"Art": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 1.879506786114689, "aspect": "sextile", "planet": "Sun"}, {"orb": 1.9544106929961913, "aspect": "sextile", "planet": "Venus"}, {"orb": 4.52116344031333, "aspect": "trine", "planet": "Uranus"}, {"orb": 3.258329572097864, "aspect": "square", "planet": "Neptune"}], "longitude": 359.11655194843917, "conjunctions": [], "interpretation": "Art в 12 доме"}, "Gain": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 2.063965791512885, "aspect": "opposition", "planet": "Jupiter"}], "longitude": 40.65254585024846, "conjunctions": [], "interpretation": "Gain в 1 доме"}, "Home": {"sign": "Gemini", "house": 2, "aspects": [{"orb": 1.394961598994314, "aspect": "trine", "planet": "Mars"}], "longitude": 72.90409653853791, "conjunctions": [], "interpretation": "Home в 2 доме"}, "Loss": {"sign": "Capricorn", "house": 10, "aspects": [{"orb": 1.1347742458434311, "aspect": "sextile", "planet": "Jupiter"}], "longitude": 277.45380581289214, "conjunctions": [], "interpretation": "Loss в 10 доме"}, "Love": {"sign": "Aries", "house": 1, "aspects": [{"orb": 2.264889298848516, "aspect": "trine", "planet": "Moon"}, {"orb": 1.879506786114689, "aspect": "sextile", "planet": "Mercury"}, {"orb": 2.1388696983944158, "aspect": "opposition", "planet": "Mars"}], "longitude": 16.437927835926644, "conjunctions": [], "interpretation": "Любовь в 1 доме: отношения через сферу дома"}, "Risk": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 3.3706848730665797, "aspect": "square", "planet": "Moon"}, {"orb": 3.7847203684995634, "aspect": "square", "planet": "Neptune"}, {"orb": 0.3991487480914202, "aspect": "trine", "planet": "True_Node"}, {"orb": 0.03254117541132473, "aspect": "trine", "planet": "Mean_Node"}, {"orb": 4.159443414072882, "aspect": "sextile", "planet": "Chiron"}, {"orb": 0.03254117541132473, "aspect": "sextile", "planet": "Lilith"}], "longitude": 352.07350200784174, "conjunctions": [], "interpretation": "Risk в 12 доме"}, "Soul": {"sign": "Taurus", "house": 2, "aspects": [{"orb": 2.339793205730018, "aspect": "trine", "planet": "Sun"}, {"orb": 2.4146971126115204, "aspect": "trine", "planet": "Venus"}, {"orb": 4.981449859928659, "aspect": "opposition", "planet": "Uranus"}], "longitude": 58.65626552882384, "conjunctions": [], "interpretation": "Soul в 2 доме"}, "Death": {"sign": "Aquarius", "house": 12, "aspects": [{"orb": 1.119134184777181, "aspect": "sextile", "planet": "Moon"}, {"orb": 1.5045166975110078, "aspect": "conjunction", "planet": "Mercury"}, {"orb": 2.3397932057300466, "aspect": "trine", "planet": "Saturn"}, {"orb": 1.9078927257834835, "aspect": "square", "planet": "Chiron"}], "longitude": 319.82195131955234, "conjunctions": [{"orb": 1.5045166975110078, "house": 12, "planet": "Mercury"}], "interpretation": "Трансформация в 12 доме: потери. Соединение с Mercury усиливает влияние"}, "Faith": {"sign": "Capricorn", "house": 11, "aspects": [{"orb": 1.7938007279444435, "aspect": "square", "planet": "Saturn"}, {"orb": 2.9563955199945724, "aspect": "square", "planet": "Pluto"}, {"orb": 1.482894497293671, "aspect": "opposition", "planet": "True_Node"}, {"orb": 1.8495020699737665, "aspect": "opposition", "planet": "Mean_Node"}, {"orb": 1.8495020699737665, "aspect": "conjunction", "planet": "Lilith"}], "longitude": 293.95554525322683, "conjunctions": [{"orb": 1.8495020699737665, "house": 10, "planet": "Lilith"}], "interpretation": "Вера в 11 доме: философские убеждения. Соединение с Lilith усиливает влияние"}, "Karma": {"sign": "Aquarius", "house": 12, "aspects": [{"orb": 1.119134184777181, "aspect": "sextile", "planet": "Moon"}, {"orb": 1.5045166975110078, "aspect": "conjunction", "planet": "Mercury"}, {"orb": 2.3397932057300466, "aspect": "trine", "planet": "Saturn"}, {"orb": 1.9078927257834835, "aspect": "square", "planet": "Chiron"}], "longitude": 319.82195131955234, "conjunctions": [{"orb": 1.5045166975110078, "house": 12, "planet": "Mercury"}], "interpretation": "Karma в 12 доме. Соединение с Mercury усиливает влияние"}, "Magic": {"sign": "Aries", "house": 1, "aspects": [{"orb": 4.815612035836125, "aspect": "trine", "planet": "Moon"}, {"orb": 1.3566846453288974, "aspect": "opposition", "planet": "Saturn"}, {"orb": 2.339793205730018, "aspect": "trine", "planet": "Neptune"}, {"orb": 3.3935116026101184, "aspect": "opposition", "planet": "Pluto"}, {"orb": 1.0457784146781108, "aspect": "square", "planet": "True_Node"}, {"orb": 1.4123859873582205, "aspect": "square", "planet": "Mean_Node"}, {"orb": 1.4123859873582205, "aspect": "square", "planet": "Lilith"}], "longitude": 23.518429170611284, "conjunctions": [], "interpretation": "Magic в 1 доме"}, "Power": {"sign": "Capricorn", "house": 10, "aspects": [{"orb": 2.0201521698195677, "aspect": "square", "planet": "Mars"}, {"orb": 3.690325908977087, "aspect": "sextile", "planet": "Jupiter"}], "longitude": 282.27890596771266, "conjunctions": [], "interpretation": "Power в 10 доме"}, "Truth": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 3.1834256652163617, "aspect": "square", "planet": "Mercury"}, {"orb": 0.9717904686754792, "aspect": "sextile", "planet": "True_Node"}, {"orb": 0.6051828959953696, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 3.5868016934888303, "aspect": "conjunction", "planet": "Chiron"}, {"orb": 0.6051828959953696, "aspect": "trine", "planet": "Lilith"}], "longitude": 51.500860287257694, "conjunctions": [], "interpretation": "Truth в 1 доме"}, "Career": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 1.0598703389619573, "aspect": "sextile", "planet": "Sun"}, {"orb": 1.1347742458434595, "aspect": "sextile", "planet": "Venus"}, {"orb": 3.7015269931605985, "aspect": "trine", "planet": "Uranus"}, {"orb": 4.077966019250596, "aspect": "square", "planet": "Neptune"}], "longitude": 359.9361883955919, "conjunctions": [], "interpretation": "Career в 12 доме"}, "Change": {"sign": "Aries", "house": 12, "aspects": [{"orb": 0.3018634484686231, "aspect": "sextile", "planet": "Sun"}, {"orb": 0.22695954158712084, "aspect": "sextile", "planet": "Venus"}, {"orb": 2.339793205730018, "aspect": "trine", "planet": "Uranus"}], "longitude": 1.2979221830224787, "conjunctions": [], "interpretation": "Change в 12 доме"}, "Enmity": {"sign": "Aries", "house": 12, "aspects": [{"orb": 4.862622152542457, "aspect": "trine", "planet": "Uranus"}], "longitude": 8.500337541294954, "conjunctions": [], "interpretation": "Enmity в 12 доме"}, "Father": {"sign": "Sagittarius", "house": 8, "aspects": [{"orb": 3.458927390507199, "aspect": "sextile", "planet": "Sun"}, {"orb": 3.384023483625697, "aspect": "sextile", "planet": "Venus"}, {"orb": 0.8172707363085578, "aspect": "conjunction", "planet": "Uranus"}], "longitude": 244.45498612506105, "conjunctions": [{"orb": 0.8172707363085578, "house": 8, "planet": "Uranus"}], "interpretation": "Отец в 8 доме: отношения с отцом. Соединение с Uranus усиливает влияние"}, "Genius": {"sign": "Cancer", "house": 3, "aspects": [{"orb": 4.130802389112574, "aspect": "trine", "planet": "Pluto"}], "longitude": 91.04274316233398, "conjunctions": [], "interpretation": "Genius в 3 доме"}, "Mother": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 3.3840234836257537, "aspect": "sextile", "planet": "Sun"}, {"orb": 3.458927390507256, "aspect": "sextile", "planet": "Venus"}, {"orb": 1.7538128745867994, "aspect": "square", "planet": "Neptune"}], "longitude": 357.6120352509281, "conjunctions": [], "interpretation": "Мать в 12 доме: отношения с матерью"}, "Reason": {"sign": "Gemini", "house": 2, "aspects": [{"orb": 2.725175718463845, "aspect": "opposition", "planet": "Moon"}, {"orb": 2.339793205730018, "aspect": "trine", "planet": "Mercury"}, {"orb": 1.6785832787790866, "aspect": "trine", "planet": "Mars"}], "longitude": 75.97764141631131, "conjunctions": [], "interpretation": "Reason в 2 доме"}, "Spirit": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 4.518797729469128, "aspect": "trine", "planet": "Jupiter"}, {"orb": 0.43206694051394834, "aspect": "square", "planet": "Uranus"}], "longitude": 334.06978232926645, "conjunctions": [], "interpretation": "Дух в 12 доме: духовный рост через сферу дома"}, "Travel": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 2.3397932057300466, "aspect": "trine", "planet": "Jupiter"}, {"orb": 2.6110714642530297, "aspect": "square", "planet": "Uranus"}], "longitude": 336.2487868530055, "conjunctions": [], "interpretation": "Travel в 12 доме"}, "Wisdom": {"sign": "Capricorn", "house": 10, "aspects": [{"orb": 1.9544106929962197, "aspect": "sextile", "planet": "Jupiter"}], "longitude": 276.63416936573935, "conjunctions": [], "interpretation": "Wisdom в 10 доме"}, "Courage": {"sign": "Sagittarius", "house": 8, "aspects": [{"orb": 1.9544106929962197, "aspect": "sextile", "planet": "Mars"}], "longitude": 252.344647444536, "conjunctions": [], "interpretation": "Courage в 8 доме"}, "Destiny": {"sign": "Capricorn", "house": 10, "aspects": [{"orb": 1.0598703389619288, "aspect": "sextile", "planet": "Jupiter"}], "longitude": 277.52870971977364, "conjunctions": [], "interpretation": "Destiny в 10 доме"}, "Fortune": {"sign": "Taurus", "house": 2, "aspects": [{"orb": 2.339793205730018, "aspect": "trine", "planet": "Sun"}, {"orb": 2.4146971126115204, "aspect": "trine", "planet": "Venus"}, {"orb": 4.981449859928659, "aspect": "opposition", "planet": "Uranus"}], "longitude": 58.65626552882384, "conjunctions": [], "interpretation": "Фортуна в 2 доме: удача через сферу дома"}, "Freedom": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 3.1570639420386044, "aspect": "trine", "planet": "Sun"}, {"orb": 3.2319678489201067, "aspect": "trine", "planet": "Venus"}], "longitude": 57.83899479251525, "conjunctions": [], "interpretation": "Freedom в 1 доме"}, "Healing": {"sign": "Virgo", "house": 6, "aspects": [{"orb": 3.1285517467363206, "aspect": "square", "planet": "Moon"}, {"orb": 2.339793205730018, "aspect": "trine", "planet": "Chiron"}], "longitude": 165.57426538803884, "conjunctions": [], "interpretation": "Healing в 6 доме"}, "Passion": {"sign": "Sagittarius", "house": 9, "aspects": [{"orb": 3.7328970488006803, "aspect": "conjunction", "planet": "Neptune"}, {"orb": 2.67917865192058, "aspect": "sextile", "planet": "Pluto"}], "longitude": 269.591119425142, "conjunctions": [], "interpretation": "Страсть в 9 доме: творческая энергия"}, "Science": {"sign": "Leo", "house": 5, "aspects": [{"orb": 1.7803441117281409, "aspect": "sextile", "planet": "Mars"}, {"orb": 3.930133967068514, "aspect": "square", "planet": "Jupiter"}], "longitude": 132.5187140258041, "conjunctions": [], "interpretation": "Science в 5 доме"}, "Secrets": {"sign": "Sagittarius", "house": 9, "aspects": [{"orb": 2.795785554942796, "aspect": "sextile", "planet": "Saturn"}, {"orb": 0.9006922961161195, "aspect": "conjunction", "planet": "Neptune"}, {"orb": 1.9544106929962197, "aspect": "sextile", "planet": "Pluto"}], "longitude": 264.9575300802252, "conjunctions": [{"orb": 0.9006922961161195, "house": 9, "planet": "Neptune"}], "interpretation": "Secrets в 9 доме. Соединение с Neptune усиливает влияние"}, "Service": {"sign": "Aquarius", "house": 11, "aspects": [{"orb": 1.9544106929961913, "aspect": "sextile", "planet": "Moon"}, {"orb": 1.5690281802623645, "aspect": "conjunction", "planet": "Mercury"}, {"orb": 2.4493483042467403, "aspect": "trine", "planet": "Mars"}, {"orb": 1.1656521519898888, "aspect": "square", "planet": "Chiron"}], "longitude": 316.74840644177897, "conjunctions": [{"orb": 1.5690281802623645, "house": 12, "planet": "Mercury"}], "interpretation": "Service в 11 доме. Соединение с Mercury усиливает влияние"}, "Victory": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 1.7938007279444719, "aspect": "square", "planet": "Sun"}, {"orb": 1.7188968210629127, "aspect": "square", "planet": "Venus"}], "longitude": 32.7898594624983, "conjunctions": [], "interpretation": "Победа в 1 доме: достижения"}, "Children": {"sign": "Capricorn", "house": 11, "aspects": [{"orb": 1.7188968210629412, "aspect": "square", "planet": "Saturn"}, {"orb": 3.0312994268760747, "aspect": "square", "planet": "Pluto"}, {"orb": 1.4079905904121688, "aspect": "opposition", "planet": "True_Node"}, {"orb": 1.7745981630922643, "aspect": "opposition", "planet": "Mean_Node"}, {"orb": 1.7745981630922643, "aspect": "conjunction", "planet": "Lilith"}], "longitude": 293.8806413463453, "conjunctions": [{"orb": 1.7745981630922643, "house": 10, "planet": "Lilith"}], "interpretation": "Дети в 11 доме: творчество. Соединение с Lilith усиливает влияние"}, "Commerce": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 2.6883410819787628, "aspect": "square", "planet": "Sun"}, {"orb": 2.6134371750972605, "aspect": "square", "planet": "Venus"}, {"orb": 4.904180242202955, "aspect": "opposition", "planet": "Jupiter"}], "longitude": 33.68439981653262, "conjunctions": [], "interpretation": "Бизнес в 1 доме: успех в делах"}, "Illusion": {"sign": "Aquarius", "house": 12, "aspects": [{"orb": 1.7420671580627243, "aspect": "trine", "planet": "Saturn"}, {"orb": 1.9544106929961913, "aspect": "sextile", "planet": "Neptune"}, {"orb": 3.0081290898762916, "aspect": "trine", "planet": "Pluto"}], "longitude": 323.9038116833451, "conjunctions": [], "interpretation": "Illusion в 12 доме"}, "Learning": {"sign": "Cancer", "house": 5, "aspects": [{"orb": 4.904180242202955, "aspect": "opposition", "planet": "Sun"}, {"orb": 4.979084149084457, "aspect": "opposition", "planet": "Venus"}, {"orb": 3.930133967068514, "aspect": "square", "planet": "Saturn"}, {"orb": 0.820062280870502, "aspect": "square", "planet": "Pluto"}, {"orb": 3.619227736417727, "aspect": "conjunction", "planet": "True_Node"}, {"orb": 3.985835309097837, "aspect": "conjunction", "planet": "Mean_Node"}, {"orb": 3.985835309097837, "aspect": "opposition", "planet": "Lilith"}], "longitude": 116.0918784923509, "conjunctions": [], "interpretation": "Learning в 5 доме"}, "Marriage": {"sign": "Cancer", "house": 5, "aspects": [{"orb": 3.110497519915725, "aspect": "square", "planet": "Saturn"}, {"orb": 1.6396987280232906, "aspect": "square", "planet": "Pluto"}, {"orb": 2.7995912892649386, "aspect": "conjunction", "planet": "True_Node"}, {"orb": 3.1661988619450483, "aspect": "conjunction", "planet": "Mean_Node"}, {"orb": 3.1661988619450483, "aspect": "opposition", "planet": "Lilith"}], "longitude": 115.27224204519811, "conjunctions": [{"orb": 2.7995912892649386, "house": 4, "planet": "True_Node"}], "interpretation": "Брак в 5 доме: партнерство. Соединение с True_Node усиливает влияние"}, "Sickness": {"sign": "Aries", "house": 12, "aspects": [{"orb": 4.862622152542457, "aspect": "trine", "planet": "Uranus"}], "longitude": 8.500337541294954, "conjunctions": [], "interpretation": "Здоровье в 12 доме: болезни"}, "Teaching": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 1.7938007279444719, "aspect": "square", "planet": "Sun"}, {"orb": 1.7188968210629127, "aspect": "square", "planet": "Venus"}], "longitude": 32.7898594624983, "conjunctions": [], "interpretation": "Teaching в 1 доме"}, "Abundance": {"sign": "Capricorn", "house": 11, "aspects": [{"orb": 1.7188968210629412, "aspect": "square", "planet": "Saturn"}, {"orb": 3.0312994268760747, "aspect": "square", "planet": "Pluto"}, {"orb": 1.4079905904121688, "aspect": "opposition", "planet": "True_Node"}, {"orb": 1.7745981630922643, "aspect": "opposition", "planet": "Mean_Node"}, {"orb": 1.7745981630922643, "aspect": "conjunction", "planet": "Lilith"}], "longitude": 293.8806413463453, "conjunctions": [{"orb": 1.7745981630922643, "house": 10, "planet": "Lilith"}], "interpretation": "Abundance в 11 доме. Соединение с Lilith усиливает влияние"}, "Intuition": {"sign": "Aquarius", "house": 11, "aspects": [{"orb": 1.9544106929961913, "aspect": "sextile", "planet": "Moon"}, {"orb": 1.5690281802623645, "aspect": "conjunction", "planet": "Mercury"}, {"orb": 2.4493483042467403, "aspect": "trine", "planet": "Mars"}, {"orb": 1.1656521519898888, "aspect": "square", "planet": "Chiron"}], "longitude": 316.74840644177897, "conjunctions": [{"orb": 1.5690281802623645, "house": 12, "planet": "Mercury"}], "interpretation": "Intuition в 11 доме. Соединение с Mercury усиливает влияние"}, "Necessity": {"sign": "Capricorn", "house": 10, "aspects": [{"orb": 1.0598703389619288, "aspect": "sextile", "planet": "Jupiter"}], "longitude": 277.52870971977364, "conjunctions": [], "interpretation": "Necessity в 10 доме"}, "Stability": {"sign": "Aquarius", "house": 12, "aspects": [{"orb": 1.119134184777181, "aspect": "sextile", "planet": "Moon"}, {"orb": 1.5045166975110078, "aspect": "conjunction", "planet": "Mercury"}, {"orb": 2.3397932057300466, "aspect": "trine", "planet": "Saturn"}, {"orb": 1.9078927257834835, "aspect": "square", "planet": "Chiron"}], "longitude": 319.82195131955234, "conjunctions": [{"orb": 1.5045166975110078, "house": 12, "planet": "Mercury"}], "interpretation": "Stability в 12 доме. Соединение с Mercury усиливает влияние"}, "Creativity": {"sign": "Leo", "house": 5, "aspects": [{"orb": 2.1388696983944158, "aspect": "opposition", "planet": "Sun"}, {"orb": 2.0639657915129135, "aspect": "opposition", "planet": "Venus"}, {"orb": 0.5027869558042255, "aspect": "trine", "planet": "Uranus"}], "longitude": 123.13492843294827, "conjunctions": [], "interpretation": "Creativity в 5 доме"}, "Discipline": {"sign": "Aries", "house": 1, "aspects": [{"orb": 2.063965791512885, "aspect": "opposition", "planet": "Saturn"}, {"orb": 1.6325120595460305, "aspect": "trine", "planet": "Neptune"}, {"orb": 2.686230456426131, "aspect": "opposition", "planet": "Pluto"}, {"orb": 1.7530595608620985, "aspect": "square", "planet": "True_Node"}, {"orb": 2.119667133542208, "aspect": "square", "planet": "Mean_Node"}, {"orb": 2.1196671335421797, "aspect": "square", "planet": "Lilith"}], "longitude": 24.225710316795272, "conjunctions": [], "interpretation": "Discipline в 1 доме"}, "Friendship": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 4.59370163635063, "aspect": "trine", "planet": "Jupiter"}, {"orb": 0.35716303363244606, "aspect": "square", "planet": "Uranus"}], "longitude": 333.99487842238494, "conjunctions": [], "interpretation": "Friendship в 12 доме"}, "Leadership": {"sign": "Cancer", "house": 5, "aspects": [{"orb": 3.035593613034223, "aspect": "square", "planet": "Saturn"}, {"orb": 1.714602634904793, "aspect": "square", "planet": "Pluto"}, {"orb": 2.7246873823834363, "aspect": "conjunction", "planet": "True_Node"}, {"orb": 3.091294955063546, "aspect": "conjunction", "planet": "Mean_Node"}, {"orb": 3.091294955063546, "aspect": "opposition", "planet": "Lilith"}], "longitude": 115.19733813831661, "conjunctions": [{"orb": 2.7246873823834363, "house": 4, "planet": "True_Node"}], "interpretation": "Leadership в 5 доме. Соединение с True_Node усиливает влияние"}, "Inspiration": {"sign": "Pisces", "house": 12, "aspects": [{"orb": 2.561703605215513, "aspect": "trine", "planet": "Jupiter"}], "longitude": 341.1502836639511, "conjunctions": [], "interpretation": "Inspiration в 12 доме"}, "Imprisonment": {"sign": "Aries", "house": 1, "aspects": [{"orb": 2.063965791512885, "aspect": "opposition", "planet": "Saturn"}, {"orb": 1.6325120595460305, "aspect": "trine", "planet": "Neptune"}, {"orb": 2.686230456426131, "aspect": "opposition", "planet": "Pluto"}, {"orb": 1.7530595608620985, "aspect": "square", "planet": "True_Node"}, {"orb": 2.119667133542208, "aspect": "square", "planet": "Mean_Node"}, {"orb": 2.1196671335421797, "aspect": "square", "planet": "Lilith"}], "longitude": 24.225710316795272, "conjunctions": [], "interpretation": "Imprisonment в 1 доме"}, "Communication": {"sign": "Taurus", "house": 1, "aspects": [{"orb": 2.6134371750972605, "aspect": "square", "planet": "Sun"}, {"orb": 2.538533268215758, "aspect": "square", "planet": "Venus"}, {"orb": 4.979084149084457, "aspect": "opposition", "planet": "Jupiter"}], "longitude": 33.609495909651116, "conjunctions": [], "interpretation": "Communication в 1 доме"}}	{"include_all": true, "profile_city": "Kaliningrad", "include_heavy": true, "patterns_count": 14, "profile_region": "Kaliningrad", "calculation_time_ms": 160, "aspect_qualities_count": 29, "arabic_connections_count": 51, "star_interpretations_count": 2}	Thursday	Jupiter	{"has_yod": false, "moon_phase": 317.7068, "has_t_square": true, "total_planets": 14, "avg_aspect_orb": 3.3326, "aspect_patterns": {"other": 1, "trine": 3, "square": 9, "sextile": 6, "opposition": 4, "conjunction": 6}, "element_balance": {"air": 6, "fire": 3, "earth": 2, "water": 3}, "has_grand_trine": false, "moon_phase_name": "new", "planet_strengths": {"Sun": 0.1, "Mars": 0.1, "Moon": 0.6, "Pluto": 0.6, "Venus": 0.44999999999999996, "Chiron": 0.44999999999999996, "Lilith": 0.44999999999999996, "Saturn": 0.9, "Uranus": 0.6, "Jupiter": 0.6, "Mercury": 0.9, "Neptune": 0.6, "Mean_Node": 0.44999999999999996, "True_Node": 0.6}, "retrograde_count": 4, "avg_dignity_score": 0.29, "fixed_stars_count": 14, "sign_distribution": {"Leo": 0, "Aries": 0, "Libra": 3, "Virgo": 0, "Cancer": 2, "Gemini": 0, "Pisces": 0, "Taurus": 1, "Scorpio": 1, "Aquarius": 3, "Capricorn": 1, "Sagittarius": 3}, "house_distribution": {"1": 1, "2": 0, "3": 0, "4": 2, "5": 0, "6": 1, "7": 3, "8": 2, "9": 1, "10": 1, "11": 2, "12": 1}, "retrograde_planets": ["Venus", "Mean_Node", "Chiron", "Lilith"], "avg_planet_strength": 0.5286, "active_patterns_count": 5, "aspect_qualities_count": 29, "critical_degrees_count": 3, "has_void_of_course_moon": false}	P	success	\N	2026-07-20 12:49:40.183919+00	2026-07-20 12:49:40.183919+00
\.


--
-- Data for Name: optimal_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optimal_activities (id, user_id, calculation_date, activity_indices, activity_types, activity_scores, confidence_scores, recommendations, time_slots, priority_order, energy_level, energy_trend, focus_areas, ml_features, feature_vector, model_version, is_generated, is_approved, user_feedback, generated_at, updated_at) FROM stdin;
1	1	2026-07-20	{3,0,1,6}	{}	{0.518691,0.5,0.5,0.571937,0.5,0.5,0.5}	{}	{}	{}	{}	0.5129	\N	{}	{"empathy": 0.258, "has_yod": 0.0, "iq_base": 0.924, "stamina": 0.0721, "vitality": 0.8972, "has_spica": 0.0, "luck_base": 0.8527, "work_ethic": 0.768, "chronic_risk": 0.7481, "extroversion": 0.4555, "big5_openness": 0.78725, "follow_through": 0.916, "learning_speed": 0.6422, "predictability": 0.9869, "drive_intensity": 0.0279, "big5_neuroticism": 0.4626, "system_stability": 0.7417, "talent_magnitude": 0.6505, "big5_extraversion": 0.4555, "blueprint_empathy": 0.258, "destiny_intensity": 0.9918, "big5_agreeableness": 0.25495, "blueprint_creative": 0.4972, "blueprint_diplomacy": 0.0549, "blueprint_practical": 0.4972, "blueprint_stability": 0.5374, "emotional_stability": 0.5374, "intuition_luck_corr": -0.1656, "blueprint_analytical": 0.8948, "blueprint_leadership": 0.0279, "blueprint_resilience": 0.3513, "intuition_reliability": 0.9544, "big5_conscientiousness": 0.842, "blueprint_extroversion": 0.4555, "transformative_potential": 0.8101, "blueprint_integrity_index": 0.4826, "blueprint_openness_balance": 0.7879, "blueprint_authenticity_level": 0.318, "blueprint_dependability_score": 0.842}	{0.25495,0.842,0.4555,0.4626,0.78725,0.8948,0.318,0.4972,0.842,0.0549,0.258,0.4555,0.4826,0.0279,0.7879,0.4972,0.3513,0.5374,0.7481,0.9918,0.0279,0.5374,0.258,0.4555,0.916,0,0,-0.1656,0.9544,0.924,0.6422,0.8527,0.9869,0.0721,0.7417,0.6505,0.8101,0.8972,0.768,0.518691,0.5,0.5,0.571937,0.5,0.5,0.5,1,1,0,1,0,0,1,39,0.512947,0.571937,0.5}	ml_1.0	t	f	\N	2026-07-20 12:49:41.789057+00	2026-07-20 12:49:41.789057+00
\.


--
-- Data for Name: profile_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profile_snapshots (id, user_id, snapshot_date, axes, ml_features, created_at) FROM stdin;
\.


--
-- Data for Name: psychological_tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychological_tests (id, user_id, test_type, test_version, test_name, questions, answers, raw_responses, scores, profile_type, interpretation, insights, completion_percentage, time_spent_seconds, device_info, status, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: psyho_matrices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psyho_matrices (user_id, first_number, second_number, third_number, fourth_number, matrix_digits, matrix_3x3, characteristics, talent_codes, strength_codes, energy_level, life_purpose, compatibility_hints, additional, karmic_analysis, forecasting, calculation_version, created_at, updated_at, calculated_at) FROM stdin;
1	24	6	22	4	{"1": 3, "2": 5, "3": 0, "4": 2, "5": 0, "6": 1, "7": 0, "8": 1, "9": 1}	[[3, 5, 0], [2, 0, 1], [0, 1, 1]]	{"duty": "Responsibility, reliability", "luck": "Luck through work and persistence", "labor": "Physical work brings satisfaction", "logic": "Intuitive thinking, creativity", "energy": "Colossal energy, gift of influence", "health": "Strong health, endurance", "memory": "Good memory, learning ability", "indices": {"duty_index": 12, "luck_index": 0, "labor_index": 10, "logic_index": 0, "energy_index": 75, "health_index": 20, "memory_index": 8, "purpose_index": 30, "interest_index": 0, "development_index": 48.15}, "interest": "Creative and humanitarian interests", "character": "Willful, purposeful character", "duty_count": 1, "duty_score": 40, "luck_count": 0, "luck_score": 10, "positional": {"center": 0, "corners": 4, "row_strength": [8, 3, 2], "anti_diagonal": 0, "balance_score": 68, "main_diagonal": 4, "column_strength": [5, 6, 2]}, "labor_count": 1, "labor_score": 40, "logic_count": 0, "logic_score": 10, "energy_count": 5, "energy_score": 100, "health_count": 2, "health_score": 70, "memory_count": 1, "memory_score": 40, "interest_count": 0, "interest_score": 10, "character_count": 3, "character_score": 90, "matrix_analysis": {"density": 66.67, "is_dense": true, "is_sparse": false, "empty_cells": [3, 5, 7], "filled_cells": [1, 2, 4, 6, 8, 9], "total_digits": 13, "unique_digits": 6, "dominant_count": 5, "dominant_digit": "2"}}	{MASTER_TALENT_CHARACTER,MASTER_TALENT_ENERGY,TALENT_CHARACTER,TALENT_ENERGY,TALENT_HEALTH,TALENT_HEALTH_HEALING,TALENT_HOLISTIC_THINKING,TALENT_LEADERSHIP_MANAGEMENT,TALENT_ROW_1_STRENGTH}	{MASTER_STRENGTH_CHARACTER,MASTER_STRENGTH_ENERGY,STRENGTH_CHARACTER,STRENGTH_ENERGY,STRENGTH_ENERGY_CHARISMA,STRENGTH_HEALTH,STRENGTH_HEALTH_STAMINA,STRENGTH_LEADERSHIP_WILL}	very_high	Stability and order - building reliable structures and systems	{"partner_types": [], "ideal_partners": ["Builders", "Administrators"], "recommendations": ["Learn compromise and flexibility in relationships", "Your high energy attracts many partners"], "compatible_numbers": [1, 2, 3], "relationship_score": 80, "challenging_numbers": [1], "energy_compatibility": "very_high", "communication_compatibility": "low"}	{"challenges": [{"challenge_area": "interest", "challenge_number": 3, "challenge_description": "Express creativity and communicate"}, {"challenge_area": "logic", "challenge_number": 5, "challenge_description": "Embrace change and freedom"}, {"challenge_area": "luck", "challenge_number": 7, "challenge_description": "Trust intuition and seek wisdom"}], "life_peaks": [{"period": "0-27 years", "description": "Early peak: Work and building foundations", "peak_number": 4}, {"period": "28-55 years", "description": "Middle peak: Freedom and change", "peak_number": 5}, {"period": "56-83 years", "description": "Late peak: Completion and transformation", "peak_number": 9}, {"period": "84+ years", "description": "Final peak: Creativity and expression", "peak_number": 3}], "soul_number": 3, "destiny_number": 6, "maturity_number": 1, "personality_number": 22, "karmic_number_present": false, "master_number_present": false}	{"soul_age": "Young soul (10-14)", "past_lives": {"archetype": "Humanitarian, philosopher, guide", "experience_level": "Old soul, wisdom keeper", "past_life_number": 9}, "karmic_debt": [], "karmic_tasks": [{"task": "Urgently balance excessive energy", "type": "urgent_balancing", "digit": 2, "priority": "high"}, {"task": "Develop interest", "type": "development", "digit": 3, "priority": "high"}, {"task": "Develop logic", "type": "development", "digit": 5, "priority": "high"}, {"task": "Develop luck", "type": "development", "digit": 7, "priority": "high"}, {"task": "Balance overuse of character", "type": "balancing", "digit": 1, "priority": "medium"}], "karmic_maturity": 95}	{"growth_areas": [{"area": "interest", "digit": 3, "potential": "To be developed", "suggestion": "Focus on developing interest"}, {"area": "logic", "digit": 5, "potential": "To be developed", "suggestion": "Focus on developing logic"}, {"area": "labor", "digit": 6, "potential": "Strengthening", "suggestion": "Practice and reinforce labor"}, {"area": "luck", "digit": 7, "potential": "To be developed", "suggestion": "Focus on developing luck"}, {"area": "duty", "digit": 8, "potential": "Strengthening", "suggestion": "Practice and reinforce duty"}, {"area": "memory", "digit": 9, "potential": "Strengthening", "suggestion": "Practice and reinforce memory"}], "current_cycle": {"focus": "Stability and order - building reliable structures and systems", "duration": "9 years", "cycle_name": "Cycle of Building and Stability", "cycle_number": 4}, "personal_years": [{"year": 2024, "description": "Change, freedom, adventure", "personal_year": 5}, {"year": 2025, "description": "Responsibility, family, service", "personal_year": 6}, {"year": 2026, "description": "Rest, reflection, analysis", "personal_year": 7}, {"year": 2027, "description": "Power, achievement, abundance", "personal_year": 8}, {"year": 2028, "description": "Completion, release, transformation", "personal_year": 9}], "recommendations": ["Develop missing qualities: interest, logic, luck", "Strengthen developing qualities: labor, duty, memory", "Balance overused qualities: character, energy"], "favorable_periods": [{"area": "Career and leadership", "advice": "Take initiative, start new projects", "favorable": true}, {"area": "Relationships and partnerships", "advice": "Build connections, collaborate", "favorable": true}, {"area": "Health and stability", "advice": "Build routines, focus on wellness", "favorable": true}]}	3.1	2026-07-20 12:49:37.873113+00	2026-07-20 12:49:37.873113+00	2026-07-20 12:49:37.873113+00
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommendations (id, user_id, calculation_date, title, content, summary, category, priority, relevance_score, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_audit_log (id, action_type, action_name, resource_type, resource_id, user_id, user_ip, user_agent, session_id, request_data, response_data, error_details, stack_trace, status_code, success, error_code, duration_ms, memory_usage_kb, service_name, endpoint, http_method, created_at) FROM stdin;
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_metrics (id, metric_name, metric_type, metric_value, metric_labels, service_name, hostname, collected_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_profiles (user_id, full_name, username, language_code, timezone, birth_country_code, system_language, birth_timezone, birth_date, birth_time, birth_region, birth_city, birth_country, birth_lat, birth_lng, profession, job_position, geocoder_query, geocoder_full_name, geocoder_source, current_city, current_lat, current_lng, notification_enabled, daily_recommendations_enabled, created_at, updated_at) FROM stdin;
1	\N	\N	ru	Europe/Moscow	RU	ru	Europe/Kaliningrad	1982-01-21	12:00:00	Kaliningrad	Kaliningrad	Russia	54.710400	20.507000	worker	\N	Kaliningrad	Kaliningrad	nominatim	Rfliningrad	\N	\N	t	t	2026-07-20 12:48:44.616084+00	2026-07-20 12:49:37.313003+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, telegram_id, max_id, udemy_id, google_id, apple_id, yandex_id, phone_hash, email_hash, password_hash, yandex_refresh_token, yandex_access_token, yandex_token_expires_at, yandex_email, yandex_login, primary_auth_method, status, is_verified, is_premium, privacy_level, created_at, updated_at, last_activity_at, premium_until) FROM stdin;
1	\N	\N	\N	\N	\N	2400511387	\N	cc272e1ca3534652ce2ebd9e6df2a793c3bcda31b169e941885f5570c5ec3ca4	\N	\N	y0__wgBEJvL0_gIGNn1RCChqtulGDDv94GPCH6l9JrIqsIxEmbpD6knRJqKRlxf	2026-07-20 13:48:44.604013+00	dailytuner@yandex.ru	dailytuner	yandex	active	t	f	standard	2026-07-20 12:48:44.616084+00	2026-07-20 12:48:44.616084+00	2026-07-20 12:48:44.616084+00	\N
\.


--
-- Name: astro_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.astro_events_id_seq', 1, false);


--
-- Name: biorhythms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.biorhythms_id_seq', 1, true);


--
-- Name: calculation_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calculation_cache_id_seq', 1, false);


--
-- Name: daily_forecast_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.daily_forecast_cache_id_seq', 2, true);


--
-- Name: forecast_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.forecast_feedback_id_seq', 1, false);


--
-- Name: magic_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.magic_profiles_id_seq', 1, true);


--
-- Name: ml_model_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ml_model_metrics_id_seq', 1, false);


--
-- Name: natal_charts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.natal_charts_id_seq', 1, true);


--
-- Name: optimal_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optimal_activities_id_seq', 1, true);


--
-- Name: profile_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.profile_snapshots_id_seq', 1, false);


--
-- Name: psychological_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.psychological_tests_id_seq', 1, false);


--
-- Name: recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recommendations_id_seq', 1, false);


--
-- Name: system_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_audit_log_id_seq', 1, false);


--
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: astro_events astro_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.astro_events
    ADD CONSTRAINT astro_events_pkey PRIMARY KEY (id);


--
-- Name: biorhythms biorhythms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms
    ADD CONSTRAINT biorhythms_pkey PRIMARY KEY (id);


--
-- Name: biorhythms biorhythms_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms
    ADD CONSTRAINT biorhythms_user_id_key UNIQUE (user_id);


--
-- Name: calculation_cache calculation_cache_cache_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache
    ADD CONSTRAINT calculation_cache_cache_key_key UNIQUE (cache_key);


--
-- Name: calculation_cache calculation_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache
    ADD CONSTRAINT calculation_cache_pkey PRIMARY KEY (id);


--
-- Name: daily_forecast_cache daily_forecast_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache
    ADD CONSTRAINT daily_forecast_cache_pkey PRIMARY KEY (id);


--
-- Name: daily_forecast_cache daily_forecast_cache_user_id_forecast_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache
    ADD CONSTRAINT daily_forecast_cache_user_id_forecast_date_key UNIQUE (user_id, forecast_date);


--
-- Name: forecast_feedback forecast_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forecast_feedback
    ADD CONSTRAINT forecast_feedback_pkey PRIMARY KEY (id);


--
-- Name: magic_profiles magic_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles
    ADD CONSTRAINT magic_profiles_pkey PRIMARY KEY (id);


--
-- Name: magic_profiles magic_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles
    ADD CONSTRAINT magic_profiles_user_id_key UNIQUE (user_id);


--
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- Name: natal_charts natal_charts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.natal_charts
    ADD CONSTRAINT natal_charts_pkey PRIMARY KEY (id);


--
-- Name: optimal_activities optimal_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities
    ADD CONSTRAINT optimal_activities_pkey PRIMARY KEY (id);


--
-- Name: optimal_activities optimal_activities_user_id_calculation_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities
    ADD CONSTRAINT optimal_activities_user_id_calculation_date_key UNIQUE (user_id, calculation_date);


--
-- Name: profile_snapshots profile_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_snapshots
    ADD CONSTRAINT profile_snapshots_pkey PRIMARY KEY (id);


--
-- Name: psychological_tests psychological_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests
    ADD CONSTRAINT psychological_tests_pkey PRIMARY KEY (id);


--
-- Name: psychological_tests psychological_tests_user_id_test_type_test_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests
    ADD CONSTRAINT psychological_tests_user_id_test_type_test_version_key UNIQUE (user_id, test_type, test_version);


--
-- Name: psyho_matrices psyho_matrices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psyho_matrices
    ADD CONSTRAINT psyho_matrices_pkey PRIMARY KEY (user_id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_user_id_calculation_date_category_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_calculation_date_category_key UNIQUE (user_id, calculation_date, category);


--
-- Name: system_audit_log system_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_audit_log
    ADD CONSTRAINT system_audit_log_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: users users_apple_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_apple_id_key UNIQUE (apple_id);


--
-- Name: users users_google_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_google_id_key UNIQUE (google_id);


--
-- Name: users users_max_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_max_id_key UNIQUE (max_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: users users_udemy_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_udemy_id_key UNIQUE (udemy_id);


--
-- Name: users users_yandex_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_yandex_id_key UNIQUE (yandex_id);


--
-- Name: idx_activities_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activities_user_date ON public.optimal_activities USING btree (user_id, calculation_date DESC);


--
-- Name: idx_astro_events_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_astro_events_date ON public.astro_events USING btree (event_date);


--
-- Name: idx_astro_events_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_astro_events_type ON public.astro_events USING btree (event_type);


--
-- Name: idx_audit_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_date ON public.system_audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_user ON public.system_audit_log USING btree (user_id);


--
-- Name: idx_biorhythms_profile_data_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_profile_data_gin ON public.biorhythms USING gin (profile_data);


--
-- Name: idx_biorhythms_profile_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_profile_date ON public.biorhythms USING btree (profile_calculated_at);


--
-- Name: idx_biorhythms_stability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_stability ON public.biorhythms USING btree (system_stability);


--
-- Name: idx_biorhythms_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_user ON public.biorhythms USING btree (user_id);


--
-- Name: idx_cache_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cache_expires ON public.calculation_cache USING btree (expires_at) WHERE (is_valid = true);


--
-- Name: idx_cache_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cache_key ON public.calculation_cache USING btree (cache_key);


--
-- Name: idx_daily_cache_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_cache_date ON public.daily_forecast_cache USING btree (user_id, forecast_date);


--
-- Name: idx_daily_forecast_cache_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_forecast_cache_user_date ON public.daily_forecast_cache USING btree (user_id, forecast_date);


--
-- Name: idx_feedback_accuracy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feedback_accuracy ON public.forecast_feedback USING btree (delta) WHERE (delta IS NOT NULL);


--
-- Name: idx_feedback_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feedback_user_date ON public.forecast_feedback USING btree (user_id, forecast_date);


--
-- Name: idx_magic_axes_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_axes_gin ON public.magic_profiles USING gin (axes);


--
-- Name: idx_magic_blueprint_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_blueprint_gin ON public.magic_profiles USING gin (psychological_blueprint);


--
-- Name: idx_magic_cluster_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_cluster_id ON public.magic_profiles USING btree (cluster_id);


--
-- Name: idx_magic_confidence; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_confidence ON public.magic_profiles USING btree (confidence_score);


--
-- Name: idx_magic_errors_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_errors_gin ON public.magic_profiles USING gin (validation_errors);


--
-- Name: idx_magic_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_metadata_gin ON public.magic_profiles USING gin (calculation_metadata);


--
-- Name: idx_magic_ml_features_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_ml_features_gin ON public.magic_profiles USING gin (ml_features);


--
-- Name: idx_magic_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_magic_user_id ON public.magic_profiles USING btree (user_id);


--
-- Name: idx_magic_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_version ON public.magic_profiles USING btree (profile_version);


--
-- Name: idx_metrics_name_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_metrics_name_date ON public.system_metrics USING btree (metric_name, collected_at DESC);


--
-- Name: idx_ml_metrics_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ml_metrics_model ON public.ml_model_metrics USING btree (model_name, "timestamp" DESC);


--
-- Name: idx_natal_arabic_connections_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_arabic_connections_gin ON public.natal_charts USING gin (arabic_connections);


--
-- Name: idx_natal_arabic_parts_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_arabic_parts_gin ON public.natal_charts USING gin (arabic_parts);


--
-- Name: idx_natal_aspect_qualities_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_aspect_qualities_gin ON public.natal_charts USING gin (aspect_qualities);


--
-- Name: idx_natal_critical_degrees_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_critical_degrees_gin ON public.natal_charts USING gin (critical_degrees);


--
-- Name: idx_natal_dasha_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_dasha_current ON public.natal_charts USING btree (((dasha ->> 'planet'::text)));


--
-- Name: idx_natal_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_date ON public.natal_charts USING btree (calculation_date);


--
-- Name: idx_natal_julian_day; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_julian_day ON public.natal_charts USING btree (julian_day);


--
-- Name: idx_natal_midpoints_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_midpoints_gin ON public.natal_charts USING gin (midpoints);


--
-- Name: idx_natal_ml_features_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_ml_features_gin ON public.natal_charts USING gin (ml_features);


--
-- Name: idx_natal_moon_data_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_moon_data_gin ON public.natal_charts USING gin (moon_data);


--
-- Name: idx_natal_nakshatra; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_nakshatra ON public.natal_charts USING btree (((panchanga ->> 'nakshatra_name'::text)));


--
-- Name: idx_natal_panchanga_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_panchanga_gin ON public.natal_charts USING gin (panchanga);


--
-- Name: idx_natal_patterns_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_patterns_gin ON public.natal_charts USING gin (patterns);


--
-- Name: idx_natal_planets_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_planets_gin ON public.natal_charts USING gin (planets);


--
-- Name: idx_natal_solar_data_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_solar_data_gin ON public.natal_charts USING gin (solar_data);


--
-- Name: idx_natal_star_interpretations_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_star_interpretations_gin ON public.natal_charts USING gin (star_interpretations);


--
-- Name: idx_natal_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_user_date ON public.natal_charts USING btree (user_id, calculation_date DESC);


--
-- Name: idx_natal_weekday; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_weekday ON public.natal_charts USING btree (weekday);


--
-- Name: idx_profiles_birth_city_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_birth_city_trgm ON public.user_profiles USING gin (birth_city public.gin_trgm_ops);


--
-- Name: idx_profiles_birth_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_birth_date ON public.user_profiles USING btree (birth_date);


--
-- Name: idx_profiles_birth_region_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_birth_region_trgm ON public.user_profiles USING gin (birth_region public.gin_trgm_ops);


--
-- Name: idx_psyho_matrices_3x3_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_3x3_gin ON public.psyho_matrices USING gin (matrix_3x3);


--
-- Name: idx_psyho_matrices_additional_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_additional_gin ON public.psyho_matrices USING gin (additional);


--
-- Name: idx_psyho_matrices_characteristics_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_characteristics_gin ON public.psyho_matrices USING gin (characteristics);


--
-- Name: idx_psyho_matrices_digits_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_digits_gin ON public.psyho_matrices USING gin (matrix_digits);


--
-- Name: idx_psyho_matrices_energy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_energy ON public.psyho_matrices USING btree (energy_level);


--
-- Name: idx_psyho_matrices_forecasting_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_forecasting_gin ON public.psyho_matrices USING gin (forecasting);


--
-- Name: idx_psyho_matrices_karmic_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_karmic_gin ON public.psyho_matrices USING gin (karmic_analysis);


--
-- Name: idx_psyho_matrices_user_energy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_user_energy ON public.psyho_matrices USING btree (user_id, energy_level);


--
-- Name: idx_psyho_matrices_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_user_id ON public.psyho_matrices USING btree (user_id);


--
-- Name: idx_psyho_matrices_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_version ON public.psyho_matrices USING btree (calculation_version);


--
-- Name: idx_recommendations_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recommendations_user_date ON public.recommendations USING btree (user_id, calculation_date DESC);


--
-- Name: idx_tests_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tests_type ON public.psychological_tests USING btree (test_type);


--
-- Name: idx_tests_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tests_user ON public.psychological_tests USING btree (user_id);


--
-- Name: idx_users_apple; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_apple ON public.users USING btree (apple_id) WHERE (apple_id IS NOT NULL);


--
-- Name: idx_users_auth_method; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_auth_method ON public.users USING btree (primary_auth_method) WHERE (primary_auth_method IS NOT NULL);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at DESC);


--
-- Name: idx_users_email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_email_unique ON public.users USING btree (email_hash) WHERE (email_hash IS NOT NULL);


--
-- Name: idx_users_google; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_google ON public.users USING btree (google_id) WHERE (google_id IS NOT NULL);


--
-- Name: idx_users_last_activity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_last_activity ON public.users USING btree (last_activity_at DESC);


--
-- Name: idx_users_max; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_max ON public.users USING btree (max_id) WHERE (max_id IS NOT NULL);


--
-- Name: idx_users_phone_email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_phone_email_unique ON public.users USING btree (phone_hash, email_hash) WHERE ((phone_hash IS NOT NULL) AND (email_hash IS NOT NULL));


--
-- Name: idx_users_phone_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_phone_unique ON public.users USING btree (phone_hash) WHERE (phone_hash IS NOT NULL);


--
-- Name: idx_users_premium; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_premium ON public.users USING btree (premium_until) WHERE (is_premium = true);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_status ON public.users USING btree (status) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_users_telegram; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_telegram ON public.users USING btree (telegram_id) WHERE (telegram_id IS NOT NULL);


--
-- Name: idx_users_udemy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_udemy ON public.users USING btree (udemy_id) WHERE (udemy_id IS NOT NULL);


--
-- Name: idx_users_yandex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_yandex ON public.users USING btree (yandex_id) WHERE (yandex_id IS NOT NULL);


--
-- Name: magic_profiles trigger_update_magic_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_magic_updated_at BEFORE UPDATE ON public.magic_profiles FOR EACH ROW EXECUTE FUNCTION public.update_magic_updated_at();


--
-- Name: recommendations update_activity_on_recommendation; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_activity_on_recommendation AFTER INSERT OR UPDATE ON public.recommendations FOR EACH ROW EXECUTE FUNCTION public.update_user_activity();


--
-- Name: psychological_tests update_activity_on_test; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_activity_on_test AFTER INSERT OR UPDATE ON public.psychological_tests FOR EACH ROW EXECUTE FUNCTION public.update_user_activity();


--
-- Name: astro_events update_astro_events_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_astro_events_updated_at BEFORE UPDATE ON public.astro_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: magic_profiles update_magic_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_magic_profiles_updated_at BEFORE UPDATE ON public.magic_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: natal_charts update_natal_charts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_natal_charts_updated_at BEFORE UPDATE ON public.natal_charts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: psyho_matrices update_psyho_matrices_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_psyho_matrices_updated_at BEFORE UPDATE ON public.psyho_matrices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: recommendations update_recommendations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_recommendations_updated_at BEFORE UPDATE ON public.recommendations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_profiles update_user_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: biorhythms biorhythms_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms
    ADD CONSTRAINT biorhythms_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calculation_cache calculation_cache_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache
    ADD CONSTRAINT calculation_cache_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: daily_forecast_cache daily_forecast_cache_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache
    ADD CONSTRAINT daily_forecast_cache_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forecast_feedback forecast_feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forecast_feedback
    ADD CONSTRAINT forecast_feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: magic_profiles magic_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles
    ADD CONSTRAINT magic_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ml_model_metrics ml_model_metrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: natal_charts natal_charts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.natal_charts
    ADD CONSTRAINT natal_charts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: optimal_activities optimal_activities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities
    ADD CONSTRAINT optimal_activities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profile_snapshots profile_snapshots_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_snapshots
    ADD CONSTRAINT profile_snapshots_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: psychological_tests psychological_tests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests
    ADD CONSTRAINT psychological_tests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: psyho_matrices psyho_matrices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psyho_matrices
    ADD CONSTRAINT psyho_matrices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recommendations recommendations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_audit_log system_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_audit_log
    ADD CONSTRAINT system_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_in(cstring) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_out(public.gtrgm); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_out(public.gtrgm) TO personal_assistant_app;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea) TO personal_assistant_app;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO personal_assistant_app;


--
-- Name: FUNCTION cleanup_old_data(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_old_data() TO personal_assistant_app;


--
-- Name: FUNCTION cleanup_old_forecasts(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_old_forecasts() TO personal_assistant_app;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dearmor(text) TO personal_assistant_app;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO personal_assistant_app;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO personal_assistant_app;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO personal_assistant_app;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO personal_assistant_app;


--
-- Name: FUNCTION gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gin_extract_value_trgm(text, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_value_trgm(text, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_compress(internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_consistent(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_consistent(internal, text, smallint, oid, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_decompress(internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_distance(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_distance(internal, text, smallint, oid, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_options(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_options(internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_penalty(internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_picksplit(internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_same(public.gtrgm, public.gtrgm, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_same(public.gtrgm, public.gtrgm, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_union(internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO personal_assistant_app;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO personal_assistant_app;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION set_limit(real); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_limit(real) TO personal_assistant_app;


--
-- Name: FUNCTION show_limit(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_limit() TO personal_assistant_app;


--
-- Name: FUNCTION show_trgm(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_trgm(text) TO personal_assistant_app;


--
-- Name: FUNCTION similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION similarity_dist(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_dist(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION update_magic_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_magic_updated_at() TO personal_assistant_app;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO personal_assistant_app;


--
-- Name: FUNCTION update_user_activity(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_user_activity() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO personal_assistant_app;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_nil() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_op(text, text) TO personal_assistant_app;


--
-- Name: TABLE astro_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.astro_events TO personal_assistant_app;


--
-- Name: SEQUENCE astro_events_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.astro_events_id_seq TO personal_assistant_app;


--
-- Name: TABLE biorhythms; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.biorhythms TO personal_assistant_app;


--
-- Name: SEQUENCE biorhythms_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.biorhythms_id_seq TO personal_assistant_app;


--
-- Name: TABLE calculation_cache; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.calculation_cache TO personal_assistant_app;


--
-- Name: SEQUENCE calculation_cache_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.calculation_cache_id_seq TO personal_assistant_app;


--
-- Name: TABLE daily_forecast_cache; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.daily_forecast_cache TO personal_assistant_app;


--
-- Name: SEQUENCE daily_forecast_cache_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.daily_forecast_cache_id_seq TO personal_assistant_app;


--
-- Name: TABLE recommendations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.recommendations TO personal_assistant_app;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO personal_assistant_app;


--
-- Name: TABLE daily_user_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.daily_user_summary TO personal_assistant_app;


--
-- Name: TABLE forecast_feedback; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.forecast_feedback TO personal_assistant_app;


--
-- Name: SEQUENCE forecast_feedback_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.forecast_feedback_id_seq TO personal_assistant_app;


--
-- Name: TABLE magic_profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.magic_profiles TO personal_assistant_app;


--
-- Name: SEQUENCE magic_profiles_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.magic_profiles_id_seq TO personal_assistant_app;


--
-- Name: TABLE ml_model_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ml_model_metrics TO personal_assistant_app;


--
-- Name: SEQUENCE ml_model_metrics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.ml_model_metrics_id_seq TO personal_assistant_app;


--
-- Name: TABLE ml_models_performance; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ml_models_performance TO personal_assistant_app;


--
-- Name: TABLE natal_charts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.natal_charts TO personal_assistant_app;


--
-- Name: SEQUENCE natal_charts_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.natal_charts_id_seq TO personal_assistant_app;


--
-- Name: TABLE optimal_activities; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.optimal_activities TO personal_assistant_app;


--
-- Name: SEQUENCE optimal_activities_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.optimal_activities_id_seq TO personal_assistant_app;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pg_stat_statements TO personal_assistant_app;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pg_stat_statements_info TO personal_assistant_app;


--
-- Name: TABLE profile_snapshots; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.profile_snapshots TO personal_assistant_app;


--
-- Name: SEQUENCE profile_snapshots_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.profile_snapshots_id_seq TO personal_assistant_app;


--
-- Name: TABLE psychological_tests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.psychological_tests TO personal_assistant_app;


--
-- Name: SEQUENCE psychological_tests_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.psychological_tests_id_seq TO personal_assistant_app;


--
-- Name: TABLE psyho_matrices; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.psyho_matrices TO personal_assistant_app;


--
-- Name: SEQUENCE recommendations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.recommendations_id_seq TO personal_assistant_app;


--
-- Name: TABLE system_audit_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.system_audit_log TO personal_assistant_app;


--
-- Name: SEQUENCE system_audit_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.system_audit_log_id_seq TO personal_assistant_app;


--
-- Name: TABLE system_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.system_metrics TO personal_assistant_app;


--
-- Name: SEQUENCE system_metrics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.system_metrics_id_seq TO personal_assistant_app;


--
-- Name: TABLE user_profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_profiles TO personal_assistant_app;


--
-- Name: TABLE user_complete_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_complete_info TO personal_assistant_app;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.users_id_seq TO personal_assistant_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT USAGE ON SEQUENCES  TO personal_assistant_app;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO personal_assistant_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO personal_assistant_app;


--
-- PostgreSQL database dump complete
--

\unrestrict lseLd6p8pwlobbp3GCO1s9kIIHJnsXfBsSif3DNjWC2QbgU8XsTPsr0ClVMWqmf

