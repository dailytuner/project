--
-- PostgreSQL database dump
--

\restrict nXheNhjhQYLOlIPCr1ZPJdPAH1W3rzCGq2vXITtCHtSem84a3qFuwHZtmTac8B2

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: activity_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.activity_type AS ENUM (
    'physical',
    'spiritual',
    'learning',
    'psychological',
    'career',
    'self_realization',
    'finances'
);


ALTER TYPE public.activity_type OWNER TO postgres;

--
-- Name: aspect_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.aspect_type AS ENUM (
    'conjunction',
    'sextile',
    'square',
    'trine',
    'opposition',
    'quincunx',
    'semi_sextile',
    'semi_square'
);


ALTER TYPE public.aspect_type OWNER TO postgres;

--
-- Name: energy_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.energy_level AS ENUM (
    'very_low',
    'low',
    'medium',
    'high',
    'very_high'
);


ALTER TYPE public.energy_level OWNER TO postgres;

--
-- Name: phase_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.phase_type AS ENUM (
    'positive',
    'negative',
    'critical',
    'neutral'
);


ALTER TYPE public.phase_type OWNER TO postgres;

--
-- Name: test_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.test_type AS ENUM (
    'mbti',
    'big5',
    'values',
    'maslow'
);


ALTER TYPE public.test_type OWNER TO postgres;

--
-- Name: trend_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.trend_type AS ENUM (
    'rising',
    'falling',
    'stable'
);


ALTER TYPE public.trend_type OWNER TO postgres;

--
-- Name: cleanup_old_data(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_data() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Удаляем старые метрики (90 дней)
    DELETE FROM system_metrics
    WHERE collected_at < NOW() - INTERVAL '90 days';

    -- Удаляем старые ML метрики (30 дней)
    DELETE FROM ml_model_metrics
    WHERE timestamp < NOW() - INTERVAL '30 days';

    -- Инвалидируем старый кэш (7 дней)
    UPDATE calculation_cache
    SET is_valid = FALSE
    WHERE expires_at < NOW() - INTERVAL '7 days';

    -- Архивируем старые аудит логи (1 год)
    DELETE FROM system_audit_log
    WHERE created_at < NOW() - INTERVAL '1 year';

    RAISE NOTICE 'Database cleanup completed at %', NOW();
END;
$$;


ALTER FUNCTION public.cleanup_old_data() OWNER TO postgres;

--
-- Name: cleanup_old_forecasts(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_forecasts() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM daily_forecast_cache
    WHERE expires_at < NOW();

    RAISE NOTICE 'Cleaned % expired forecasts at %',
        FOUND, NOW();
END;
$$;


ALTER FUNCTION public.cleanup_old_forecasts() OWNER TO postgres;

--
-- Name: update_magic_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_magic_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_magic_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: update_user_activity(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_user_activity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Используем CTE для обновления без рекурсивного триггера
    WITH activity_update AS (
        UPDATE users 
        SET last_activity_at = NOW()
        WHERE id = NEW.user_id
        AND last_activity_at < NOW() - INTERVAL '5 minutes'
        RETURNING 1
    )
    SELECT 1 FROM activity_update;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_activity() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: astro_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.astro_events (
    id bigint NOT NULL,
    event_date date NOT NULL,
    event_time timestamp with time zone,
    event_type character varying(50) NOT NULL,
    event_name character varying(100) NOT NULL,
    description text,
    significance_level character varying(20),
    zodiac_sign character varying(20),
    degree numeric(5,2),
    planetary_aspects jsonb DEFAULT '{}'::jsonb,
    general_recommendations text[] DEFAULT '{}'::text[],
    caution_areas text[] DEFAULT '{}'::text[],
    source character varying(50) DEFAULT 'calculated'::character varying,
    confidence real DEFAULT 1.0,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT astro_events_confidence_check CHECK (((confidence >= (0)::double precision) AND (confidence <= (1)::double precision))),
    CONSTRAINT astro_events_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['new_moon'::character varying, 'full_moon'::character varying, 'first_quarter'::character varying, 'last_quarter'::character varying, 'mercury_retrograde'::character varying, 'venus_retrograde'::character varying, 'mars_retrograde'::character varying, 'jupiter_retrograde'::character varying, 'saturn_retrograde'::character varying, 'uranus_retrograde'::character varying, 'neptune_retrograde'::character varying, 'pluto_retrograde'::character varying, 'eclipse_solar'::character varying, 'eclipse_lunar'::character varying, 'planetary_transit'::character varying])::text[]))),
    CONSTRAINT astro_events_significance_level_check CHECK (((significance_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.astro_events OWNER TO postgres;

--
-- Name: TABLE astro_events; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.astro_events IS 'Астрологические события и лунные фазы';


--
-- Name: astro_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.astro_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.astro_events_id_seq OWNER TO postgres;

--
-- Name: astro_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.astro_events_id_seq OWNED BY public.astro_events.id;


--
-- Name: biorhythms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.biorhythms (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date NOT NULL,
    profile_version character varying(10) DEFAULT '1.0'::character varying NOT NULL,
    profile_calculated_at date,
    days_analyzed integer,
    birth_physical double precision,
    birth_emotional double precision,
    birth_intellectual double precision,
    birth_intuitive double precision,
    system_stability double precision,
    predictability double precision,
    profile_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT biorhythms_birth_emotional_check CHECK (((birth_emotional >= ('-1.0'::numeric)::double precision) AND (birth_emotional <= (1.0)::double precision))),
    CONSTRAINT biorhythms_birth_intellectual_check CHECK (((birth_intellectual >= ('-1.0'::numeric)::double precision) AND (birth_intellectual <= (1.0)::double precision))),
    CONSTRAINT biorhythms_birth_intuitive_check CHECK (((birth_intuitive >= ('-1.0'::numeric)::double precision) AND (birth_intuitive <= (1.0)::double precision))),
    CONSTRAINT biorhythms_birth_physical_check CHECK (((birth_physical >= ('-1.0'::numeric)::double precision) AND (birth_physical <= (1.0)::double precision))),
    CONSTRAINT biorhythms_days_analyzed_check CHECK ((days_analyzed > 0)),
    CONSTRAINT biorhythms_predictability_check CHECK (((predictability >= (0)::double precision) AND (predictability <= (1)::double precision))),
    CONSTRAINT biorhythms_system_stability_check CHECK (((system_stability >= (0)::double precision) AND (system_stability <= (1)::double precision)))
);


ALTER TABLE public.biorhythms OWNER TO postgres;

--
-- Name: TABLE biorhythms; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.biorhythms IS 'Расчёты биоритмов пользователей';


--
-- Name: COLUMN biorhythms.profile_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.profile_version IS 'Версия алгоритма расчета профиля';


--
-- Name: COLUMN biorhythms.profile_calculated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.profile_calculated_at IS 'Дата расчета профиля';


--
-- Name: COLUMN biorhythms.days_analyzed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.days_analyzed IS 'Количество дней для анализа (обычно 1825 = 5 лет)';


--
-- Name: COLUMN biorhythms.birth_physical; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.birth_physical IS 'Фаза физического цикла при рождении (-1..1)';


--
-- Name: COLUMN biorhythms.system_stability; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.system_stability IS 'Стабильность системы (0-1)';


--
-- Name: COLUMN biorhythms.profile_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.biorhythms.profile_data IS 'Полные данные профиля для Mistral';


--
-- Name: biorhythms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.biorhythms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.biorhythms_id_seq OWNER TO postgres;

--
-- Name: biorhythms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.biorhythms_id_seq OWNED BY public.biorhythms.id;


--
-- Name: calculation_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calculation_cache (
    id bigint NOT NULL,
    cache_key character varying(255) NOT NULL,
    cache_group character varying(100) NOT NULL,
    data jsonb NOT NULL,
    data_hash character varying(64) NOT NULL,
    calculation_type character varying(50) NOT NULL,
    user_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    last_accessed_at timestamp with time zone DEFAULT now() NOT NULL,
    access_count integer DEFAULT 0,
    is_valid boolean DEFAULT true
);


ALTER TABLE public.calculation_cache OWNER TO postgres;

--
-- Name: TABLE calculation_cache; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.calculation_cache IS 'Кэш результатов расчётов для оптимизации';


--
-- Name: calculation_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calculation_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calculation_cache_id_seq OWNER TO postgres;

--
-- Name: calculation_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calculation_cache_id_seq OWNED BY public.calculation_cache.id;


--
-- Name: daily_forecast_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_forecast_cache (
    id integer NOT NULL,
    user_id integer NOT NULL,
    forecast_date date NOT NULL,
    axes_deltas jsonb NOT NULL,
    daily_axes jsonb NOT NULL,
    recommendations jsonb,
    background_risks jsonb,
    subtle_signals jsonb,
    signal_categories jsonb,
    rules_version character varying(20) DEFAULT 'v1.0'::character varying,
    invalidated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.daily_forecast_cache OWNER TO postgres;

--
-- Name: COLUMN daily_forecast_cache.background_risks; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.daily_forecast_cache.background_risks IS 'Список фоновых рисков от слабых сигналов';


--
-- Name: COLUMN daily_forecast_cache.subtle_signals; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.daily_forecast_cache.subtle_signals IS 'Детали слабых сигналов по осям';


--
-- Name: COLUMN daily_forecast_cache.signal_categories; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.daily_forecast_cache.signal_categories IS 'Категоризация всех сигналов (critical/strong/medium/weak)';


--
-- Name: daily_forecast_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.daily_forecast_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_forecast_cache_id_seq OWNER TO postgres;

--
-- Name: daily_forecast_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.daily_forecast_cache_id_seq OWNED BY public.daily_forecast_cache.id;


--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommendations (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    summary text,
    category character varying(50) NOT NULL,
    priority smallint DEFAULT 3 NOT NULL,
    relevance_score real DEFAULT 0.5 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT recommendations_priority_check CHECK (((priority >= 1) AND (priority <= 5))),
    CONSTRAINT recommendations_relevance_score_check CHECK (((relevance_score >= (0)::double precision) AND (relevance_score <= (1)::double precision)))
);


ALTER TABLE public.recommendations OWNER TO postgres;

--
-- Name: TABLE recommendations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.recommendations IS 'Итоговые персонализированные рекомендации';


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    telegram_id bigint,
    max_id character varying(255),
    udemy_id character varying(255),
    google_id character varying(255),
    apple_id character varying(255),
    yandex_id character varying(255),
    phone_hash character varying(128),
    email_hash character varying(128),
    password_hash character varying(255),
    yandex_refresh_token text,
    yandex_access_token text,
    yandex_token_expires_at timestamp with time zone,
    yandex_email character varying(255),
    yandex_login character varying(255),
    primary_auth_method character varying(20) DEFAULT 'telegram'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    is_verified boolean DEFAULT false,
    is_premium boolean DEFAULT false,
    privacy_level character varying(20) DEFAULT 'standard'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    premium_until timestamp with time zone,
    CONSTRAINT users_primary_auth_method_check CHECK (((primary_auth_method)::text = ANY ((ARRAY['telegram'::character varying, 'max'::character varying, 'udemy'::character varying, 'phone'::character varying, 'email'::character varying, 'google'::character varying, 'apple'::character varying, 'yandex'::character varying])::text[]))),
    CONSTRAINT users_privacy_level_check CHECK (((privacy_level)::text = ANY ((ARRAY['minimal'::character varying, 'standard'::character varying, 'maximum'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.users IS 'Основная таблица пользователей системы';


--
-- Name: COLUMN users.telegram_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.telegram_id IS 'ID пользователя в Telegram (уникальный, если указан)';


--
-- Name: COLUMN users.max_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.max_id IS 'ID пользователя в MAX платформе';


--
-- Name: COLUMN users.udemy_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.udemy_id IS 'ID пользователя в Udemy';


--
-- Name: COLUMN users.google_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.google_id IS 'ID пользователя в Google';


--
-- Name: COLUMN users.apple_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.apple_id IS 'ID пользователя в Apple';


--
-- Name: COLUMN users.phone_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.phone_hash IS 'Хеш телефона для анонимизации';


--
-- Name: COLUMN users.email_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.email_hash IS 'Хеш email для анонимизации';


--
-- Name: COLUMN users.primary_auth_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.primary_auth_method IS 'Основной метод авторизации пользователя';


--
-- Name: COLUMN users.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.status IS 'Статус аккаунта: active, inactive, suspended, deleted';


--
-- Name: COLUMN users.is_verified; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_verified IS 'Подтвержден ли аккаунт';


--
-- Name: COLUMN users.is_premium; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_premium IS 'Есть ли премиум-доступ';


--
-- Name: COLUMN users.privacy_level; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.privacy_level IS 'Уровень конфиденциальности: minimal, standard, maximum';


--
-- Name: COLUMN users.premium_until; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.premium_until IS 'Дата окончания премиум-доступа';


--
-- Name: daily_user_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.daily_user_summary AS
 SELECT date(users.created_at) AS date,
    count(*) AS new_users,
    count(*) FILTER (WHERE (users.is_premium = true)) AS new_premium_users,
    count(DISTINCT users.telegram_id) AS active_users,
    ( SELECT count(*) AS count
           FROM public.recommendations
          WHERE (recommendations.calculation_date = CURRENT_DATE)) AS daily_recommendations,
    ( SELECT count(*) AS count
           FROM public.biorhythms
          WHERE (biorhythms.calculation_date = CURRENT_DATE)) AS daily_biorhythms,
    round((((count(*) FILTER (WHERE (users.last_activity_at >= (now() - '7 days'::interval))))::numeric * 100.0) / (NULLIF(count(*), 0))::numeric), 2) AS weekly_retention_rate
   FROM public.users
  WHERE (users.created_at >= (CURRENT_DATE - '30 days'::interval))
  GROUP BY (date(users.created_at))
  ORDER BY (date(users.created_at)) DESC;


ALTER TABLE public.daily_user_summary OWNER TO postgres;

--
-- Name: forecast_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forecast_feedback (
    id integer NOT NULL,
    user_id integer,
    forecast_date date,
    axis_name character varying(50),
    predicted_score real,
    user_rating real,
    delta real,
    comment text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forecast_feedback OWNER TO postgres;

--
-- Name: forecast_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.forecast_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forecast_feedback_id_seq OWNER TO postgres;

--
-- Name: forecast_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.forecast_feedback_id_seq OWNED BY public.forecast_feedback.id;


--
-- Name: magic_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.magic_profiles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    axes jsonb DEFAULT '{}'::jsonb NOT NULL,
    axis_count integer DEFAULT 9 NOT NULL,
    data_sources text[] DEFAULT ARRAY[]::text[],
    psychological_blueprint jsonb DEFAULT '{}'::jsonb NOT NULL,
    ml_features jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_vector real[] DEFAULT ARRAY[]::real[] NOT NULL,
    cluster_id integer,
    anomaly_score real DEFAULT 0.0,
    profile_version character varying(20) DEFAULT '2.0'::character varying,
    confidence_score real DEFAULT 0.85,
    calculation_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_valid boolean DEFAULT true,
    validation_errors text[] DEFAULT ARRAY[]::text[],
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT magic_profiles_anomaly_score_check CHECK (((anomaly_score >= (0)::double precision) AND (anomaly_score <= (1)::double precision))),
    CONSTRAINT magic_profiles_confidence_score_check CHECK (((confidence_score >= (0)::double precision) AND (confidence_score <= (1)::double precision)))
);


ALTER TABLE public.magic_profiles OWNER TO postgres;

--
-- Name: TABLE magic_profiles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.magic_profiles IS 'Интегрированные психологические и эзотерические профили';


--
-- Name: COLUMN magic_profiles.axes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.axes IS '9 осей личности с полной структурой: energy_will, health_physical, intellect_logic, emotions_intuition, work_discipline, luck_talent, social_relations, karma_cycles, destiny_mission';


--
-- Name: COLUMN magic_profiles.psychological_blueprint; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.psychological_blueprint IS 'Интегрированный психологический портрет: core_personality, emotional_architecture, cognitive_style, social_dynamics, life_purpose_indicators';


--
-- Name: COLUMN magic_profiles.ml_features; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.ml_features IS 'ML-признаки: raw_features (18+ метрик), big_five, special_indicators (has_spica, has_yod, destiny_intensity)';


--
-- Name: COLUMN magic_profiles.feature_vector; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.feature_vector IS 'Фиксированный вектор для ML моделей (27 признаков: 18 raw + 5 big5 + 3 special)';


--
-- Name: COLUMN magic_profiles.calculation_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.magic_profiles.calculation_metadata IS 'Метаданные расчета: axis_count (9), feature_count (26), calculation_time_ms, data_sources';


--
-- Name: magic_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.magic_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.magic_profiles_id_seq OWNER TO postgres;

--
-- Name: magic_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.magic_profiles_id_seq OWNED BY public.magic_profiles.id;


--
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ml_model_metrics (
    id bigint NOT NULL,
    model_name character varying(100) NOT NULL,
    model_version character varying(20) NOT NULL,
    inference_time_ms integer NOT NULL,
    memory_usage_mb integer NOT NULL,
    success_rate real NOT NULL,
    input_size_bytes integer,
    output_size_bytes integer,
    user_id bigint,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ml_model_metrics_success_rate_check CHECK (((success_rate >= (0)::double precision) AND (success_rate <= (1)::double precision)))
);


ALTER TABLE public.ml_model_metrics OWNER TO postgres;

--
-- Name: TABLE ml_model_metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ml_model_metrics IS 'Метрики производительности ML моделей';


--
-- Name: ml_model_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ml_model_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ml_model_metrics_id_seq OWNER TO postgres;

--
-- Name: ml_model_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ml_model_metrics_id_seq OWNED BY public.ml_model_metrics.id;


--
-- Name: ml_models_performance; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.ml_models_performance AS
 SELECT ml_model_metrics.model_name,
    ml_model_metrics.model_version,
    count(*) AS total_inferences,
    avg(ml_model_metrics.inference_time_ms) AS avg_inference_time,
    (avg(ml_model_metrics.success_rate) * (100)::double precision) AS avg_success_rate,
    avg(ml_model_metrics.memory_usage_mb) AS avg_memory_mb,
    min(ml_model_metrics."timestamp") AS first_used,
    max(ml_model_metrics."timestamp") AS last_used
   FROM public.ml_model_metrics
  WHERE (ml_model_metrics."timestamp" >= (now() - '7 days'::interval))
  GROUP BY ml_model_metrics.model_name, ml_model_metrics.model_version
  ORDER BY (count(*)) DESC;


ALTER TABLE public.ml_models_performance OWNER TO postgres;

--
-- Name: natal_charts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.natal_charts (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date DEFAULT CURRENT_DATE NOT NULL,
    calculation_timestamp timestamp with time zone DEFAULT now() NOT NULL,
    calculation_time_ms integer,
    city_name character varying(100) NOT NULL,
    birth_region character varying(100),
    geocoder_query character varying(200),
    geocoder_full_name character varying(255),
    birth_lat numeric(9,6) NOT NULL,
    birth_lng numeric(9,6) NOT NULL,
    birth_timezone character varying(50) NOT NULL,
    birth_country_code character varying(2),
    system_language character varying(10) DEFAULT 'ru'::character varying,
    geocoder_cache_key character varying(64),
    geocoder_source character varying(20) DEFAULT 'manual'::character varying,
    birth_datetime_local timestamp with time zone,
    birth_datetime_utc timestamp with time zone,
    julian_day numeric(15,6),
    planets jsonb DEFAULT '{}'::jsonb NOT NULL,
    houses jsonb DEFAULT '{}'::jsonb NOT NULL,
    aspects jsonb DEFAULT '[]'::jsonb NOT NULL,
    panchanga jsonb DEFAULT '{}'::jsonb NOT NULL,
    dasha jsonb DEFAULT '{}'::jsonb NOT NULL,
    arabic_parts jsonb DEFAULT '{}'::jsonb NOT NULL,
    fixed_stars jsonb DEFAULT '[]'::jsonb NOT NULL,
    planetary_hour jsonb DEFAULT '{}'::jsonb NOT NULL,
    ayanamsa numeric(10,6),
    sidereal_time numeric(8,4),
    void_of_course_moon boolean DEFAULT false,
    moon_phase_degrees numeric(6,2),
    moon_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    solar_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    lunar_returns jsonb DEFAULT '[]'::jsonb NOT NULL,
    solar_returns jsonb DEFAULT '[]'::jsonb NOT NULL,
    critical_degrees jsonb DEFAULT '[]'::jsonb NOT NULL,
    midpoints jsonb DEFAULT '{}'::jsonb NOT NULL,
    aspect_qualities jsonb DEFAULT '[]'::jsonb NOT NULL,
    patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    star_interpretations jsonb DEFAULT '[]'::jsonb NOT NULL,
    arabic_connections jsonb DEFAULT '{}'::jsonb NOT NULL,
    calculation_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    weekday character varying(20) DEFAULT 'Monday'::character varying,
    weekday_ruler character varying(20),
    ml_features jsonb DEFAULT '{}'::jsonb NOT NULL,
    house_system character varying(20) DEFAULT 'Placidus'::character varying,
    calculation_status character varying(20) DEFAULT 'success'::character varying,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT natal_charts_calculation_status_check CHECK (((calculation_status)::text = ANY ((ARRAY['pending'::character varying, 'success'::character varying, 'failed'::character varying, 'partial'::character varying])::text[]))),
    CONSTRAINT natal_charts_geocoder_source_check CHECK (((geocoder_source)::text = ANY ((ARRAY['manual'::character varying, 'memory_cache'::character varying, 'db_cache'::character varying, 'api'::character varying, 'nominatim'::character varying, 'google'::character varying, 'yandex'::character varying])::text[])))
);


ALTER TABLE public.natal_charts OWNER TO postgres;

--
-- Name: TABLE natal_charts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.natal_charts IS 'Натальные астрологические карты';


--
-- Name: natal_charts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.natal_charts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.natal_charts_id_seq OWNER TO postgres;

--
-- Name: natal_charts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.natal_charts_id_seq OWNED BY public.natal_charts.id;


--
-- Name: optimal_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optimal_activities (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    calculation_date date NOT NULL,
    activity_indices smallint[] DEFAULT '{}'::smallint[] NOT NULL,
    activity_types public.activity_type[] DEFAULT '{}'::public.activity_type[] NOT NULL,
    activity_scores real[] DEFAULT '{}'::real[] NOT NULL,
    confidence_scores real[] DEFAULT '{}'::real[] NOT NULL,
    recommendations text[] DEFAULT '{}'::text[] NOT NULL,
    time_slots jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority_order smallint[] DEFAULT '{}'::smallint[] NOT NULL,
    energy_level real NOT NULL,
    energy_trend character varying(10),
    focus_areas text[] DEFAULT '{}'::text[],
    ml_features jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_vector real[] DEFAULT '{}'::real[] NOT NULL,
    model_version character varying(20) DEFAULT '1.0'::character varying,
    is_generated boolean DEFAULT true,
    is_approved boolean DEFAULT false,
    user_feedback smallint,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT optimal_activities_energy_level_check CHECK (((energy_level >= (0)::double precision) AND (energy_level <= (1)::double precision))),
    CONSTRAINT optimal_activities_energy_trend_check CHECK (((energy_trend)::text = ANY ((ARRAY['rising'::character varying, 'falling'::character varying, 'stable'::character varying])::text[]))),
    CONSTRAINT optimal_activities_user_feedback_check CHECK (((user_feedback >= 1) AND (user_feedback <= 5)))
);


ALTER TABLE public.optimal_activities OWNER TO postgres;

--
-- Name: TABLE optimal_activities; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.optimal_activities IS 'Рекомендации оптимальных активностей';


--
-- Name: optimal_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optimal_activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optimal_activities_id_seq OWNER TO postgres;

--
-- Name: optimal_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optimal_activities_id_seq OWNED BY public.optimal_activities.id;


--
-- Name: profile_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profile_snapshots (
    id integer NOT NULL,
    user_id integer NOT NULL,
    snapshot_date date NOT NULL,
    axes jsonb NOT NULL,
    ml_features jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.profile_snapshots OWNER TO postgres;

--
-- Name: profile_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.profile_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_snapshots_id_seq OWNER TO postgres;

--
-- Name: profile_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.profile_snapshots_id_seq OWNED BY public.profile_snapshots.id;


--
-- Name: psychological_tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychological_tests (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    test_type public.test_type NOT NULL,
    test_version character varying(20) NOT NULL,
    test_name character varying(100) NOT NULL,
    questions jsonb DEFAULT '[]'::jsonb NOT NULL,
    answers jsonb DEFAULT '{}'::jsonb NOT NULL,
    raw_responses jsonb DEFAULT '{}'::jsonb NOT NULL,
    scores jsonb DEFAULT '{}'::jsonb NOT NULL,
    profile_type character varying(50),
    interpretation text,
    insights jsonb DEFAULT '{}'::jsonb NOT NULL,
    completion_percentage smallint DEFAULT 100 NOT NULL,
    time_spent_seconds integer,
    device_info jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'completed'::character varying,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT psychological_tests_completion_percentage_check CHECK (((completion_percentage >= 0) AND (completion_percentage <= 100))),
    CONSTRAINT psychological_tests_status_check CHECK (((status)::text = ANY ((ARRAY['started'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'abandoned'::character varying])::text[])))
);


ALTER TABLE public.psychological_tests OWNER TO postgres;

--
-- Name: TABLE psychological_tests; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.psychological_tests IS 'Результаты психологических тестов пользователей';


--
-- Name: psychological_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.psychological_tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.psychological_tests_id_seq OWNER TO postgres;

--
-- Name: psychological_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.psychological_tests_id_seq OWNED BY public.psychological_tests.id;


--
-- Name: psyho_matrices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psyho_matrices (
    user_id bigint NOT NULL,
    first_number integer NOT NULL,
    second_number integer NOT NULL,
    third_number integer NOT NULL,
    fourth_number integer NOT NULL,
    matrix_digits jsonb DEFAULT '{}'::jsonb NOT NULL,
    matrix_3x3 jsonb DEFAULT '[[0, 0, 0], [0, 0, 0], [0, 0, 0]]'::jsonb NOT NULL,
    characteristics jsonb DEFAULT '{}'::jsonb NOT NULL,
    talent_codes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    strength_codes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    energy_level public.energy_level DEFAULT 'medium'::public.energy_level NOT NULL,
    life_purpose text,
    compatibility_hints jsonb DEFAULT '{}'::jsonb NOT NULL,
    additional jsonb DEFAULT '{}'::jsonb NOT NULL,
    karmic_analysis jsonb DEFAULT '{}'::jsonb NOT NULL,
    forecasting jsonb DEFAULT '{}'::jsonb NOT NULL,
    calculation_version character varying(20) DEFAULT '3.1'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT psyho_matrices_calculation_version_check CHECK (((calculation_version)::text = ANY ((ARRAY['1.0'::character varying, '2.0'::character varying, '3.0'::character varying, '3.1'::character varying])::text[]))),
    CONSTRAINT psyho_matrices_first_number_check CHECK (((first_number >= 1) AND (first_number <= 99))),
    CONSTRAINT psyho_matrices_fourth_number_check CHECK (((fourth_number >= 1) AND (fourth_number <= 99))),
    CONSTRAINT psyho_matrices_second_number_check CHECK (((second_number >= 1) AND (second_number <= 99))),
    CONSTRAINT psyho_matrices_third_number_check CHECK (((third_number >= 1) AND (third_number <= 99)))
);


ALTER TABLE public.psyho_matrices OWNER TO postgres;

--
-- Name: TABLE psyho_matrices; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.psyho_matrices IS 'Нумерологические психоматрицы по методу Пифагора';


--
-- Name: COLUMN psyho_matrices.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.user_id IS 'ID пользователя (внешний ключ)';


--
-- Name: COLUMN psyho_matrices.first_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.first_number IS 'Первое число - сумма всех цифр даты рождения (1-99)';


--
-- Name: COLUMN psyho_matrices.second_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.second_number IS 'Второе число - редукция первого (1-9 или 11,22,33)';


--
-- Name: COLUMN psyho_matrices.third_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.third_number IS 'Третье число - первое минус удвоенный день (1-99)';


--
-- Name: COLUMN psyho_matrices.fourth_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.fourth_number IS 'Четвертое число - редукция третьего (1-9 или 11,22,33)';


--
-- Name: COLUMN psyho_matrices.matrix_digits; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.matrix_digits IS 'JSON объект с количеством каждой цифры 1-9';


--
-- Name: COLUMN psyho_matrices.matrix_3x3; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.matrix_3x3 IS 'Матрица 3x3 для позиционного анализа';


--
-- Name: COLUMN psyho_matrices.characteristics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.characteristics IS 'Детальный анализ всех характеристик';


--
-- Name: COLUMN psyho_matrices.talent_codes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.talent_codes IS 'Массив кодов талантов';


--
-- Name: COLUMN psyho_matrices.strength_codes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.strength_codes IS 'Массив кодов сильных сторон';


--
-- Name: COLUMN psyho_matrices.energy_level; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.energy_level IS 'Уровень энергии (very_low, low, medium, high, very_high)';


--
-- Name: COLUMN psyho_matrices.life_purpose; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.life_purpose IS 'Описание жизненного предназначения';


--
-- Name: COLUMN psyho_matrices.compatibility_hints; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.compatibility_hints IS 'Данные для анализа совместимости';


--
-- Name: COLUMN psyho_matrices.additional; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.additional IS 'Дополнительные нумерологические расчеты';


--
-- Name: COLUMN psyho_matrices.karmic_analysis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.karmic_analysis IS 'Кармический анализ (долги, задачи, прошлые жизни)';


--
-- Name: COLUMN psyho_matrices.forecasting; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.forecasting IS 'Прогностические данные (годы, периоды, рекомендации)';


--
-- Name: COLUMN psyho_matrices.calculation_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.calculation_version IS 'Версия алгоритма расчета';


--
-- Name: COLUMN psyho_matrices.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.created_at IS 'Время создания записи';


--
-- Name: COLUMN psyho_matrices.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.psyho_matrices.updated_at IS 'Время последнего обновления';


--
-- Name: recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recommendations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recommendations_id_seq OWNER TO postgres;

--
-- Name: recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recommendations_id_seq OWNED BY public.recommendations.id;


--
-- Name: system_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_audit_log (
    id bigint NOT NULL,
    action_type character varying(50) NOT NULL,
    action_name character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(100),
    user_id bigint,
    user_ip inet,
    user_agent text,
    session_id uuid,
    request_data jsonb,
    response_data jsonb,
    error_details text,
    stack_trace text,
    status_code integer,
    success boolean DEFAULT true,
    error_code character varying(50),
    duration_ms integer,
    memory_usage_kb integer,
    service_name character varying(50) NOT NULL,
    endpoint character varying(255),
    http_method character varying(10),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_audit_log_action_type_check CHECK (((action_type)::text = ANY ((ARRAY['create'::character varying, 'read'::character varying, 'update'::character varying, 'delete'::character varying, 'login'::character varying, 'logout'::character varying, 'error'::character varying])::text[]))),
    CONSTRAINT system_audit_log_duration_ms_check CHECK ((duration_ms >= 0))
);


ALTER TABLE public.system_audit_log OWNER TO postgres;

--
-- Name: TABLE system_audit_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_audit_log IS 'Логирование действий в системе';


--
-- Name: system_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_audit_log_id_seq OWNER TO postgres;

--
-- Name: system_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_audit_log_id_seq OWNED BY public.system_audit_log.id;


--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_metrics (
    id bigint NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type character varying(50) NOT NULL,
    metric_value double precision NOT NULL,
    metric_labels jsonb DEFAULT '{}'::jsonb,
    service_name character varying(50) NOT NULL,
    hostname character varying(100),
    collected_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK (((metric_type)::text = ANY ((ARRAY['counter'::character varying, 'gauge'::character varying, 'histogram'::character varying, 'summary'::character varying])::text[])))
);


ALTER TABLE public.system_metrics OWNER TO postgres;

--
-- Name: TABLE system_metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_metrics IS 'Метрики производительности системы';


--
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_metrics_id_seq OWNER TO postgres;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_profiles (
    user_id bigint NOT NULL,
    full_name character varying(255),
    username character varying(100),
    language_code character varying(10) DEFAULT 'ru'::character varying,
    timezone character varying(50) DEFAULT 'Europe/Moscow'::character varying,
    birth_country_code character varying(2) DEFAULT 'RU'::character varying,
    system_language character varying(10) DEFAULT 'ru'::character varying,
    birth_timezone character varying(50) DEFAULT 'Europe/Moscow'::character varying,
    birth_date date NOT NULL,
    birth_time time without time zone NOT NULL,
    birth_region character varying(100),
    birth_city character varying(100) NOT NULL,
    birth_country character varying(100) DEFAULT 'Russia'::character varying,
    birth_lat numeric(9,6),
    birth_lng numeric(9,6),
    profession character varying(100),
    job_position character varying(100),
    geocoder_query character varying(200),
    geocoder_full_name character varying(255),
    geocoder_source character varying(20),
    current_city character varying(100),
    current_lat numeric(9,6),
    current_lng numeric(9,6),
    notification_enabled boolean DEFAULT true,
    daily_recommendations_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_profiles_birth_country_code_check CHECK (((birth_country_code)::text ~ '^[A-Z]{2}$'::text)),
    CONSTRAINT user_profiles_system_language_check CHECK (((system_language)::text = ANY ((ARRAY['ru'::character varying, 'en'::character varying, 'de'::character varying, 'fr'::character varying, 'es'::character varying])::text[]))),
    CONSTRAINT valid_birth_date CHECK (((birth_date >= '1900-01-01'::date) AND (birth_date <= CURRENT_DATE))),
    CONSTRAINT valid_birth_time CHECK (((birth_time >= '00:00:00'::time without time zone) AND (birth_time < '24:00:00'::time without time zone)))
);


ALTER TABLE public.user_profiles OWNER TO postgres;

--
-- Name: TABLE user_profiles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_profiles IS 'Дополнительная информация о пользователях для расчётов';


--
-- Name: user_complete_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_complete_info AS
 SELECT u.id,
    u.telegram_id,
    u.status,
    COALESCE(u.is_premium, false) AS is_premium,
    u.created_at AS user_created,
    u.last_activity_at,
    up.full_name,
    up.username,
    up.language_code,
    up.birth_date,
    up.birth_city,
    up.profession,
    up.current_city,
    COALESCE(( SELECT count(*) AS count
           FROM public.natal_charts nc
          WHERE (nc.user_id = u.id)), (0)::bigint) AS natal_charts_count,
    COALESCE(( SELECT count(*) AS count
           FROM public.biorhythms b
          WHERE (b.user_id = u.id)), (0)::bigint) AS biorhythms_count,
    COALESCE(( SELECT count(*) AS count
           FROM public.recommendations r
          WHERE (r.user_id = u.id)), (0)::bigint) AS recommendations_count,
    COALESCE(( SELECT count(*) AS count
           FROM public.psychological_tests pt
          WHERE (pt.user_id = u.id)), (0)::bigint) AS tests_count
   FROM (public.users u
     LEFT JOIN public.user_profiles up ON ((u.id = up.user_id)));


ALTER TABLE public.user_complete_info OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: astro_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.astro_events ALTER COLUMN id SET DEFAULT nextval('public.astro_events_id_seq'::regclass);


--
-- Name: biorhythms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms ALTER COLUMN id SET DEFAULT nextval('public.biorhythms_id_seq'::regclass);


--
-- Name: calculation_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache ALTER COLUMN id SET DEFAULT nextval('public.calculation_cache_id_seq'::regclass);


--
-- Name: daily_forecast_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache ALTER COLUMN id SET DEFAULT nextval('public.daily_forecast_cache_id_seq'::regclass);


--
-- Name: forecast_feedback id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forecast_feedback ALTER COLUMN id SET DEFAULT nextval('public.forecast_feedback_id_seq'::regclass);


--
-- Name: magic_profiles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles ALTER COLUMN id SET DEFAULT nextval('public.magic_profiles_id_seq'::regclass);


--
-- Name: ml_model_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ml_model_metrics ALTER COLUMN id SET DEFAULT nextval('public.ml_model_metrics_id_seq'::regclass);


--
-- Name: natal_charts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.natal_charts ALTER COLUMN id SET DEFAULT nextval('public.natal_charts_id_seq'::regclass);


--
-- Name: optimal_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities ALTER COLUMN id SET DEFAULT nextval('public.optimal_activities_id_seq'::regclass);


--
-- Name: profile_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_snapshots ALTER COLUMN id SET DEFAULT nextval('public.profile_snapshots_id_seq'::regclass);


--
-- Name: psychological_tests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests ALTER COLUMN id SET DEFAULT nextval('public.psychological_tests_id_seq'::regclass);


--
-- Name: recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations ALTER COLUMN id SET DEFAULT nextval('public.recommendations_id_seq'::regclass);


--
-- Name: system_audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_audit_log ALTER COLUMN id SET DEFAULT nextval('public.system_audit_log_id_seq'::regclass);


--
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: astro_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.astro_events (id, event_date, event_time, event_type, event_name, description, significance_level, zodiac_sign, degree, planetary_aspects, general_recommendations, caution_areas, source, confidence, calculated_at, updated_at) FROM stdin;
\.


--
-- Data for Name: biorhythms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.biorhythms (id, user_id, calculation_date, profile_version, profile_calculated_at, days_analyzed, birth_physical, birth_emotional, birth_intellectual, birth_intuitive, system_stability, predictability, profile_data, calculated_at) FROM stdin;
1	1	2026-09-05	1.0	2026-09-05	1826	0	0	0	0	0.7394000291824341	0.9868999719619751	{"birth_phase": {"luck": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "social": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "creative": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "physical": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "emotional": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "intuitive": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "nine_year": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "spiritual": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "seven_year": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "eleven_year": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}, "intellectual": {"value": 0.0, "percentage": 50.0, "day_in_cycle": 0}}, "base_periods": {"luck": 37, "social": 43, "creative": 45, "physical": 23, "emotional": 28, "intuitive": 38, "nine_year": 3285, "spiritual": 53, "seven_year": 2555, "eleven_year": 4015, "intellectual": 33}, "ml_indicators": {"luck_entropy": 0.8112, "luck_autocorr": 0.9797, "predictability": 0.9869, "social_entropy": 0.8133, "social_autocorr": 0.9764, "creative_entropy": 0.82, "physical_entropy": 0.7871, "system_stability": 0.7394, "creative_autocorr": 0.9754, "emotional_entropy": 0.6582, "intuitive_entropy": 0.7494, "nine_year_entropy": 0.7607, "physical_autocorr": 0.9874, "spiritual_entropy": 0.8094, "emotional_autocorr": 0.9847, "intuitive_autocorr": 0.9792, "seven_year_entropy": 0.7941, "spiritual_autocorr": 0.971, "eleven_year_entropy": 0.7493, "intellectual_entropy": 0.8072, "intellectual_autocorr": 0.982}, "cycle_statistics": {"luck": {"max": 0.999099, "min": -0.999099, "mean": -0.002812, "range": 1.998198, "median": 0.0, "std_dev": 0.706812, "peak_frequency": 78.36, "critical_frequency": 98.55}, "social": {"max": 0.999333, "min": -0.999333, "mean": 0.000544, "range": 1.998666, "median": 0.0, "std_dev": 0.707014, "peak_frequency": 76.36, "critical_frequency": 101.74}, "creative": {"max": 0.999391, "min": -0.999391, "mean": -0.000531, "range": 1.998782, "median": 0.0, "std_dev": 0.707947, "peak_frequency": 73.16, "critical_frequency": 97.75}, "physical": {"max": 0.997669, "min": -0.997669, "mean": -0.003571, "range": 1.995338, "median": 0.0, "std_dev": 0.707643, "peak_frequency": 78.96, "critical_frequency": 95.35}, "emotional": {"max": 1.0, "min": -1.0, "mean": -0.002879, "range": 2.0, "median": 0.0, "std_dev": 0.707958, "peak_frequency": 64.96, "critical_frequency": 130.73}, "intuitive": {"max": 0.996584, "min": -0.996584, "mean": 0.00096, "range": 1.993168, "median": 0.0, "std_dev": 0.707509, "peak_frequency": 77.16, "critical_frequency": 115.34}, "nine_year": {"max": 0.891549, "min": -1.0, "mean": -0.338794, "range": 1.891549, "median": -0.60086, "std_dev": 0.631757, "peak_frequency": 18.19, "critical_frequency": 94.35}, "spiritual": {"max": 0.999561, "min": -0.999561, "mean": 0.009139, "range": 1.999122, "median": 0.0, "std_dev": 0.707719, "peak_frequency": 76.96, "critical_frequency": 110.34}, "seven_year": {"max": 1.0, "min": -0.822876, "mean": 0.333026, "range": 1.822876, "median": 0.43333, "std_dev": 0.54662, "peak_frequency": 104.54, "critical_frequency": 73.36}, "eleven_year": {"max": 0.78371, "min": -1.0, "mean": -0.348693, "range": 1.78371, "median": -0.503271, "std_dev": 0.595326, "peak_frequency": 0.0, "critical_frequency": 106.74}, "intellectual": {"max": 0.998867, "min": -0.998867, "mean": 0.004849, "range": 1.997734, "median": 0.0, "std_dev": 0.708071, "peak_frequency": 78.36, "critical_frequency": 110.94}}, "cycle_correlations": {"social_luck": -0.0152, "creative_luck": -0.0221, "physical_luck": 0.0016, "emotional_luck": -0.0058, "intuitive_luck": -0.167, "luck_nine_year": 0.0017, "spiritual_luck": 0.0025, "creative_social": -0.0573, "luck_seven_year": 0.0053, "physical_social": 0.0011, "emotional_social": -0.0036, "intuitive_social": 0.0244, "luck_eleven_year": 0.0033, "social_nine_year": 0.002, "spiritual_social": 0.0002, "intellectual_luck": -0.0009, "physical_creative": 0.0013, "social_seven_year": -0.0019, "creative_nine_year": -0.0038, "emotional_creative": -0.0051, "intuitive_creative": 0.0241, "physical_emotional": 0.0113, "physical_intuitive": -0.0084, "physical_nine_year": -0.0044, "physical_spiritual": 0.0001, "social_eleven_year": 0.002, "spiritual_creative": -0.0019, "creative_seven_year": 0.0023, "emotional_intuitive": -0.0103, "emotional_nine_year": -0.0007, "emotional_spiritual": 0.0042, "intellectual_social": -0.0034, "intuitive_nine_year": -0.0044, "intuitive_spiritual": -0.0165, "physical_seven_year": 0.0089, "spiritual_nine_year": 0.009, "creative_eleven_year": -0.0042, "emotional_seven_year": 0.0063, "intuitive_seven_year": -0.0007, "physical_eleven_year": -0.0033, "seven_year_nine_year": -0.6994, "spiritual_seven_year": -0.022, "emotional_eleven_year": 0.0006, "intellectual_creative": -0.0028, "intuitive_eleven_year": -0.0056, "nine_year_eleven_year": 0.9901, "physical_intellectual": -0.0039, "spiritual_eleven_year": 0.006, "emotional_intellectual": 0.0073, "intellectual_intuitive": 0.0278, "intellectual_nine_year": 0.006, "intellectual_spiritual": -0.0033, "seven_year_eleven_year": -0.5975, "intellectual_seven_year": -0.0121, "intellectual_eleven_year": 0.0046}, "calculation_metadata": {"cycles_count": 11, "days_analyzed": 1826, "years_analyzed": 5.0, "use_extended_cycles": true}}	2026-09-05 15:18:28.922196+00
\.


--
-- Data for Name: calculation_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calculation_cache (id, cache_key, cache_group, data, data_hash, calculation_type, user_id, created_at, expires_at, last_accessed_at, access_count, is_valid) FROM stdin;
\.


--
-- Data for Name: daily_forecast_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_forecast_cache (id, user_id, forecast_date, axes_deltas, daily_axes, recommendations, background_risks, subtle_signals, signal_categories, rules_version, invalidated_at, created_at, expires_at) FROM stdin;
1	1	2026-09-05	{}	{"energy_will": {"daily": 0.05, "delta": -0.0692, "trend": "falling", "advice": "Отдыхай, избегай конфликтов, не начинай новое", "static": 0.095}, "luck_talent": {"daily": 0.9259, "delta": -0.012, "trend": "stable", "advice": "Рискуй, пробуй новое, проявляй таланты", "static": 0.9379}, "karma_cycles": {"daily": 0.5748, "delta": 0.0748, "trend": "rising", "advice": "Кармический период нейтрален", "static": 0.5}, "destiny_mission": {"daily": 0.5, "delta": 0.0, "trend": "stable", "advice": "Нейтральный период для миссии", "static": 0.5}, "health_physical": {"daily": 0.5446, "delta": -0.0969, "trend": "falling", "advice": "Здоровье в норме", "static": 0.6415}, "intellect_logic": {"daily": 0.9261, "delta": 0.024, "trend": "rising", "advice": "Учись, решай сложные задачи, планируй стратегию", "static": 0.9021}, "work_discipline": {"daily": 0.0873, "delta": -0.0192, "trend": "stable", "advice": "Не планируй много дел, делегируй, отдыхай", "static": 0.1065}, "social_relations": {"daily": 0.5858, "delta": -0.0131, "trend": "stable", "advice": "Социальные контакты в обычном режиме", "static": 0.5989}, "emotions_intuition": {"daily": 0.4928, "delta": -0.0072, "trend": "stable", "advice": "Эмоциональное состояние в норме", "static": 0.5}}	{"summary": "⚠️ Сильно снижены: здоровье (ещё 1 оси со спадом)", "best_time": null, "moon_info": {"sign": null, "phase": "unknown", "nakshatra": "Пунарвасу", "void_of_course": true}, "dasha_info": {"mahadasha": "Saturn", "antardasha": "Moon", "pratyaradasha": "Mercury", "mahadasha_progress": 0.6258826920305519, "antardasha_progress": 0.6124567474048442, "pratyaradasha_progress": 0.20987654320987653}, "top_advice": "✅ карма: Завершай старые дела", "caution_advice": "⚠️ здоровье: Береги себя, избегай перегрузок\\n📉 энергия: Отдыхай, не начинай конфликтов", "planetary_hour": {"is_day": true, "planet": "Moon", "hour_number": 7}, "financial_advice": {"emoji": "📊", "index": 58.6, "level": "medium", "advice": "Нейтральный фон — можно заниматься рутинными финансами, но избегай крупных рисков", "best_time": null, "avoid_actions": ["Спонтанные крупные траты", "Сомнительные инвестиции"], "risk_warnings": ["🌑 Луна без курса — не начинай крупные финансовые проекты"], "investment_hint": "Mercury в Virgo — благоприятны: аналитика, бухгалтерия, медицина", "planet_influence": {"Mars": -0.5, "Pluto": 1.0, "Venus": 1.0, "Saturn": 0.5, "Jupiter": 1.0, "Mercury": 1.5}, "favorable_actions": ["Планирование бюджета", "Рутинные платежи", "Анализ инвестиций"]}}	[]	{"weak_positive_axes": {"intellect_logic": 0.024}}	{"weak_negative": [], "weak_positive": [["intellect_logic", 0.024]], "medium_negative": [["energy_will", -0.0692]], "medium_positive": [["karma_cycles", 0.0748]], "strong_negative": [["health_physical", -0.0969]], "strong_positive": [], "critical_negative": [], "critical_positive": []}	v2.0	\N	2026-09-05 15:18:41.140356+00	2026-10-06 15:18:41.2313+00
2	1	2026-09-06	{}	{"energy_will": {"daily": 0.0819, "delta": -0.0131, "trend": "stable", "advice": "Отдыхай, избегай конфликтов, не начинай новое", "static": 0.095}, "luck_talent": {"daily": 0.9379, "delta": 0.0, "trend": "stable", "advice": "Рискуй, пробуй новое, проявляй таланты", "static": 0.9379}, "karma_cycles": {"daily": 0.5748, "delta": 0.0748, "trend": "rising", "advice": "Кармический период нейтрален", "static": 0.5}, "destiny_mission": {"daily": 0.5, "delta": 0.0, "trend": "stable", "advice": "Нейтральный период для миссии", "static": 0.5}, "health_physical": {"daily": 0.6145999999999999, "delta": -0.0269, "trend": "falling", "advice": "Здоровье в норме", "static": 0.6415}, "intellect_logic": {"daily": 0.9021, "delta": 0.0, "trend": "stable", "advice": "Учись, решай сложные задачи, планируй стратегию", "static": 0.9021}, "work_discipline": {"daily": 0.18130000000000002, "delta": 0.0748, "trend": "rising", "advice": "Не планируй много дел, делегируй, отдыхай", "static": 0.1065}, "social_relations": {"daily": 0.6258, "delta": 0.0269, "trend": "rising", "advice": "Социальные контакты в обычном режиме", "static": 0.5989}, "emotions_intuition": {"daily": 0.5517, "delta": 0.0517, "trend": "rising", "advice": "Эмоциональное состояние в норме", "static": 0.5}}	{"summary": "📊 Незначительный спад активности", "best_time": null, "moon_info": {"sign": null, "phase": "unknown", "nakshatra": "Пушья", "void_of_course": false}, "dasha_info": {"mahadasha": "Saturn", "antardasha": "Moon", "pratyaradasha": "Mercury", "mahadasha_progress": 0.6260268050151319, "antardasha_progress": 0.6141868512110726, "pratyaradasha_progress": 0.2222222222222222}, "top_advice": "✅ дисциплина: Делай рутину, закрывай долги\\n✅ карма: Завершай старые дела", "caution_advice": "✅ Особых предостережений нет", "planetary_hour": {"is_day": true, "planet": "Mars", "hour_number": 7}, "financial_advice": {"emoji": "📊", "index": 60.2, "level": "medium", "advice": "Нейтральный фон — можно заниматься рутинными финансами, но избегай крупных рисков", "best_time": null, "avoid_actions": ["Спонтанные крупные траты", "Сомнительные инвестиции"], "risk_warnings": [], "investment_hint": "Mercury в Virgo — благоприятны: аналитика, бухгалтерия, медицина", "planet_influence": {"Mars": -0.5, "Pluto": 1.0, "Venus": 1.0, "Saturn": 0.5, "Jupiter": 1.0, "Mercury": 1.5}, "favorable_actions": ["Планирование бюджета", "Рутинные платежи", "Анализ инвестиций"]}}	["🎯 Нет критических сигналов, но следи за деталями"]	{"weak_negative_axes": {"health_physical": -0.027}, "weak_positive_axes": {"social_relations": 0.027}}	{"weak_negative": [["health_physical", -0.0269]], "weak_positive": [["social_relations", 0.0269]], "medium_negative": [], "medium_positive": [["work_discipline", 0.0748], ["karma_cycles", 0.0748], ["emotions_intuition", 0.0517]], "strong_negative": [], "strong_positive": [], "critical_negative": [], "critical_positive": []}	v2.0	\N	2026-09-05 15:18:49.075293+00	2026-10-06 15:18:49.158868+00
\.


--
-- Data for Name: forecast_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forecast_feedback (id, user_id, forecast_date, axis_name, predicted_score, user_rating, delta, comment, created_at) FROM stdin;
\.


--
-- Data for Name: magic_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.magic_profiles (id, user_id, axes, axis_count, data_sources, psychological_blueprint, ml_features, feature_vector, cluster_id, anomaly_score, profile_version, confidence_score, calculation_metadata, is_valid, validation_errors, calculated_at, updated_at) FROM stdin;
1	1	{"energy_will": {"static_potential": {"willpower_base": 0.095, "leadership_quality": 0.0599, "initiative_tendency": 0.124}, "calculated_metrics": {"stamina_level": 0.1109, "drive_intensity": 0.0642, "courage_quotient": 0.1604}, "dynamic_modulators": {"entropy": 0.7871, "retrograde_penalty": 0.8}}, "luck_talent": {"special_gifts": {"fortune_sign": "Pisces", "fortune_house": 0, "spica_planets": [null], "has_spica_conjunction": true}, "static_potential": {"luck_base": 0.9379, "creative_flow": 0.8567, "talent_magnitude": 0.8871}, "calculated_metrics": {"opportunity_recognition": 0.8803, "synchronicity_frequency": 0.9521}}, "karma_cycles": {"karmic_task": {"node_sign": "Capricorn", "node_house": 6, "past_life_sign": "Capricorn", "past_life_house": 6, "task_description": "Ваша кармическая задача — достигать целей, не застывая в структурах через служение и здоровье"}, "long_cycles": {"nine_year_phase": "negative", "seven_year_phase": "positive", "eleven_year_phase": "negative", "nine_year_intensity": 0.3388, "seven_year_intensity": 0.333, "eleven_year_intensity": 0.3487}, "transformative_potential": {"crisis_frequency": 0.776, "rebirth_capacity": 0.322}}, "destiny_mission": {"fate_markers": {"has_yod": ["Mars", "Neptune", "Pluto"], "yod_apex": "Mars", "has_spica": [{"orb": 0.13567650108456064, "planet": "Sun"}, {"orb": 0.04647502073200371, "planet": "Uranus"}], "yod_planets": ["Mars", "Neptune", "Pluto"], "spica_planets": [{"orb": 0.13567650108456064, "planet": "Sun"}, {"orb": 0.04647502073200371, "planet": "Uranus"}], "destiny_number": 1}, "life_purpose": {"has_stellium": true, "stellium_sign": "Libra", "stellium_planets": 3}, "mission_indicators": {"mission_clarity": 1.0, "destiny_intensity": 0.9998}}, "health_physical": {"static_potential": {"recovery_speed": 0.6415, "constitution_strength": 0.3543}, "calculated_metrics": {"vitality_index": 0.2315, "immune_strength": 0.4954}, "vulnerability_areas": {"chronic_risk": 0.253, "stress_susceptibility": 0.6}}, "intellect_logic": {"thinking_styles": {"practical_focus": 0.4927, "analytical_depth": 0.8521, "creative_divergence": 0.6389}, "static_potential": {"iq_base": 0.9021, "learning_speed": 0.6366, "abstract_thinking": 0.8533}, "calculated_metrics": {"curiosity_level": 0.7615, "skepticism_tendency": 0.9517}}, "work_discipline": {"work_styles": {"deadline_respect": 0.0108, "overtime_willingness": 0.0275, "structured_preference": 0.0083}, "static_potential": {"work_ethic": 0.1065, "discipline_base": 0.0957, "persistence_capacity": 0.0053}, "calculated_metrics": {"follow_through_ability": 0.0108, "procrastination_tendency": 0.9953}}, "social_relations": {"static_potential": {"social_charm": 0.5989, "friendship_depth": 0.7504, "partnership_orientation": 0.6457}, "calculated_metrics": {"empathy_capacity": 0.3101, "extroversion_level": 0.6457}, "relationship_patterns": {"conflict_approach": "avoidant", "commitment_readiness": 0.3127, "trust_building_speed": 0.6192}}, "emotions_intuition": {"static_potential": {"emotional_depth": 0.5, "empathy_capacity": 0.6021, "intuitive_strength": 0.81}, "calculated_metrics": {"mood_variability": 0.6582, "emotional_stability": 0.2425, "intuition_reliability": 0.9541}, "dynamic_modulators": {"emotional_entropy": 0.6582, "intuition_luck_correlation": -0.167}}}	9	{natal_chart,psyho_matrix,biorhythms_static,user_profile}	{"cognitive_style": {"creative": 0.6389, "practical": 0.4927, "analytical": 0.8521}, "social_dynamics": {"diplomacy": 0.5989, "leadership": 0.0599, "extroversion": 0.6457}, "core_personality": {"integrity_index": 0.0529, "openness_balance": 0.7857, "authenticity_level": 0.1868, "dependability_score": 0.0587}, "emotional_architecture": {"empathy": 0.3101, "stability": 0.2425, "resilience": 0.1899}, "life_purpose_indicators": {"luck_factor": 0.9379, "destiny_intensity": 0.9998, "transformative_potential": 0.322}}	{"big_five": {"openness": 0.8946000000000001, "neuroticism": 0.7575000000000001, "extraversion": 0.6457, "agreeableness": 0.52855, "conscientiousness": 0.05865}, "metadata": {"version": "2.0", "calculated_at": "2026-09-05T15:18:30.292595", "feature_count": 19}, "raw_features": {"empathy": 0.3101, "iq_base": 0.9021, "stamina": 0.1109, "vitality": 0.2315, "luck_base": 0.9379, "work_ethic": 0.1065, "chronic_risk": 0.253, "extroversion": 0.6457, "follow_through": 0.0108, "learning_speed": 0.6366, "predictability": 0.9869, "drive_intensity": 0.0642, "system_stability": 0.7394, "talent_magnitude": 0.8871, "destiny_intensity": 0.9998, "emotional_stability": 0.2425, "intuition_luck_corr": -0.167, "intuition_reliability": 0.9541, "transformative_potential": 0.322}, "special_indicators": {"has_yod": ["Mars", "Neptune", "Pluto"], "has_spica": [{"orb": 0.13567650108456064, "planet": "Sun"}, {"orb": 0.04647502073200371, "planet": "Uranus"}], "destiny_intensity": 0.9998}}	{0.253,0.9998,0.0642,0.2425,0.3101,0.6457,0.0108,-0.167,0.9541,0.9021,0.6366,0.9379,0.9869,0.1109,0.7394,0.8871,0.322,0.2315,0.1065,0.8946,0.05865,0.6457,0.52855,0.7575,1,1,0.9998}	\N	0	1.0	0.9	{"axis_count": 9, "data_sources": ["natal_chart", "psyho_matrix", "biorhythms_static", "user_profile"], "calculated_at": "2026-09-05T15:18:30.292906", "feature_count": 27, "confidence_score": 0.9, "calculation_time_ms": 2500}	t	{}	2026-09-05 15:18:30.293017+00	2026-09-05 15:18:30.293017+00
\.


--
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ml_model_metrics (id, model_name, model_version, inference_time_ms, memory_usage_mb, success_rate, input_size_bytes, output_size_bytes, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: natal_charts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.natal_charts (id, user_id, calculation_date, calculation_timestamp, calculation_time_ms, city_name, birth_region, geocoder_query, geocoder_full_name, birth_lat, birth_lng, birth_timezone, birth_country_code, system_language, geocoder_cache_key, geocoder_source, birth_datetime_local, birth_datetime_utc, julian_day, planets, houses, aspects, panchanga, dasha, arabic_parts, fixed_stars, planetary_hour, ayanamsa, sidereal_time, void_of_course_moon, moon_phase_degrees, moon_data, solar_data, lunar_returns, solar_returns, critical_degrees, midpoints, aspect_qualities, patterns, star_interpretations, arabic_connections, calculation_metadata, weekday, weekday_ruler, ml_features, house_system, calculation_status, error_message, created_at, updated_at) FROM stdin;
1	1	2026-09-05	2026-09-05 15:18:27.100652+00	110	Kaliningrad	\N	Kaliningrad	Kaliningrad	54.710400	20.507000	Europe/Kaliningrad	RU	ru	\N	nominatim	1973-10-16 20:42:00+00	1973-10-16 20:42:00+00	2441972.362500	{"Sun": {"sign": "Libra", "house": 4, "dignity": {"face": "Face of Jupiter", "fall": "Fall", "term": "Term of Venus", "exaltation": "Near Exalted"}, "distance": 0.9965792476803964, "latitude": -0.00007521851804410784, "strength": 0.3, "longitude": 203.33866683460897, "retrograde": false, "speed_long": 0.992100863503516, "dignity_score": -2, "sign_longitude": 23.338666834608972}, "Mars": {"sign": "Taurus", "house": 10, "dignity": {"face": "Face of Mercury", "term": "Term of Venus"}, "distance": 0.43603859672259127, "latitude": -2.3348450544053123, "strength": 0.45, "longitude": 34.340826113335616, "retrograde": true, "speed_long": -0.3219708381481763, "dignity_score": 0, "sign_longitude": 4.340826113335616}, "Moon": {"sign": "Gemini", "house": 12, "dignity": {"face": "Face of Sun", "term": "Term of Saturn"}, "distance": 0.0024606323511153936, "latitude": 0.44207633984398453, "strength": 0.5, "longitude": 85.97642553848561, "retrograde": false, "speed_long": 14.268132472029531, "dignity_score": 0, "sign_longitude": 25.976425538485614}, "Pluto": {"sign": "Libra", "house": 4, "dignity": {}, "distance": 31.91515019684575, "latitude": 16.067055269396683, "strength": 0.6, "longitude": 185.0152911648372, "retrograde": false, "speed_long": 0.036828410051398364, "dignity_score": 0.0, "sign_longitude": 5.015291164837208}, "Venus": {"sign": "Sagittarius", "house": 5, "dignity": {"face": "Face of Mercury", "term": "Term (8-14°)"}, "distance": 0.8760671465497445, "latitude": -2.622090565214923, "strength": 0.7, "longitude": 248.47454627975193, "retrograde": false, "speed_long": 1.1176471653572648, "dignity_score": 2, "sign_longitude": 8.474546279751934}, "Chiron": {"sign": "Aries", "house": 10, "dignity": {}, "distance": 17.688389090857328, "latitude": 1.3260773140281115, "strength": 0.45, "longitude": 18.398852407188997, "retrograde": true, "speed_long": -0.045420547695974325, "dignity_score": 0.0, "sign_longitude": 18.398852407188997}, "Lilith": {"sign": "Cancer", "house": 12, "dignity": {}, "distance": 0.0025695552897999903, "latitude": 0.0, "strength": 0.45, "longitude": 91.95634268474606, "retrograde": true, "speed_long": -0.052923920913620144, "dignity_score": 0.0, "sign_longitude": 1.9563426847460619}, "Saturn": {"sign": "Cancer", "house": 12, "dignity": {"face": "Face of Venus", "term": "Term of Mars", "detriment": "Detriment"}, "distance": 8.648699591048095, "latitude": -1.0854788079139381, "strength": 0.1, "longitude": 94.75342038917854, "retrograde": false, "speed_long": 0.0007106968674232341, "dignity_score": -5, "sign_longitude": 4.753420389178544}, "Uranus": {"sign": "Libra", "house": 4, "dignity": {}, "distance": 19.41181792391422, "latitude": 0.5656178292256444, "strength": 0.6, "longitude": 203.42786831496153, "retrograde": false, "speed_long": 0.06272907917999332, "dignity_score": 0.0, "sign_longitude": 23.42786831496153}, "Jupiter": {"sign": "Aquarius", "house": 7, "dignity": {"face": "Face of Venus", "term": "Term of Mercury"}, "distance": 4.80795081518874, "latitude": -0.7665191571807025, "strength": 0.6, "longitude": 302.83595542456527, "retrograde": false, "speed_long": 0.05901242356271594, "dignity_score": 0, "sign_longitude": 2.8359554245652703}, "Mercury": {"sign": "Scorpio", "house": 5, "dignity": {"face": "Face of Sun", "term": "Term (11-19°)", "exaltation": "Near Exalted"}, "distance": 1.0454593434749264, "latitude": -2.7709769675861513, "strength": 0.9, "longitude": 227.75666653917096, "retrograde": false, "speed_long": 1.0740288155004831, "dignity_score": 4, "sign_longitude": 17.756666539170965}, "Neptune": {"sign": "Sagittarius", "house": 5, "dignity": {}, "distance": 31.03966715127187, "latitude": 1.5633742068381877, "strength": 0.6, "longitude": 245.63539445366942, "retrograde": false, "speed_long": 0.029665279758314435, "dignity_score": 0.0, "sign_longitude": 5.63539445366942}, "Mean_Node": {"sign": "Capricorn", "house": 6, "dignity": {}, "distance": 0.0025695552897999903, "latitude": 0.0, "strength": 0.45, "longitude": 271.95634268474606, "retrograde": true, "speed_long": -0.052923920913620144, "dignity_score": 0.0, "sign_longitude": 1.9563426847460619}, "True_Node": {"sign": "Capricorn", "house": 6, "dignity": {}, "distance": 0.0026379619043864558, "latitude": 0.0, "strength": 0.45, "longitude": 270.9600127017655, "retrograde": true, "speed_long": -0.007552010887213562, "dignity_score": 0.0, "sign_longitude": 0.9600127017654927}}	{"1": {"cusp": 116.69385983764644, "sign": "Cancer", "strength": 0.3, "position_in_sign": 26.693859837646443}, "2": {"cusp": 131.28357030496, "sign": "Leo", "strength": 0.3, "position_in_sign": 11.283570304959994}, "3": {"cusp": 149.7285846176712, "sign": "Leo", "strength": 0.3, "position_in_sign": 29.728584617671203}, "4": {"cusp": 175.88846936120854, "sign": "Virgo", "strength": 0.5, "position_in_sign": 25.888469361208536}, "5": {"cusp": 214.944113328728, "sign": "Scorpio", "strength": 0.7333, "position_in_sign": 4.944113328728008}, "6": {"cusp": 261.78435980174754, "sign": "Sagittarius", "strength": 0.45, "position_in_sign": 21.78435980174754}, "7": {"cusp": 296.6938598376464, "sign": "Capricorn", "strength": 0.6, "position_in_sign": 26.693859837646414}, "8": {"cusp": 311.28357030496, "sign": "Aquarius", "strength": 0.3, "position_in_sign": 11.283570304959994}, "9": {"cusp": 329.72858461767123, "sign": "Aquarius", "strength": 0.3, "position_in_sign": 29.72858461767123}, "10": {"cusp": 355.8884693612085, "sign": "Pisces", "strength": 0.45, "position_in_sign": 25.88846936120848}, "11": {"cusp": 34.944113328728015, "sign": "Taurus", "strength": 0.3, "position_in_sign": 4.944113328728015}, "12": {"cusp": 81.78435980174753, "sign": "Gemini", "strength": 0.35, "position_in_sign": 21.784359801747527}}	[{"orb": 2.637758703876642, "angle": 117.36224129612336, "aspect": "trine", "planet1": "Sun", "planet2": "Moon", "applying": false, "strength": 0.5604}, {"orb": 0.13587944514296169, "angle": 45.13587944514296, "aspect": "semisquare", "planet1": "Sun", "planet2": "Venus", "applying": false, "strength": 0.9321}, {"orb": 0.08920148035255693, "angle": 0.08920148035255693, "aspect": "conjunction", "planet1": "Sun", "planet2": "Uranus", "applying": true, "strength": 0.9888}, {"orb": 4.939814427419975, "angle": 175.06018557258002, "aspect": "opposition", "planet1": "Sun", "planet2": "Chiron", "applying": true, "strength": 0.3825}, {"orb": 8.77699485069293, "angle": 8.77699485069293, "aspect": "conjunction", "planet1": "Moon", "planet2": "Saturn", "applying": true, "strength": 0}, {"orb": 2.548557223524085, "angle": 117.45144277647591, "aspect": "trine", "planet1": "Moon", "planet2": "Uranus", "applying": true, "strength": 0.5752}, {"orb": 4.9835871632798785, "angle": 175.01641283672012, "aspect": "opposition", "planet1": "Moon", "planet2": "True_Node", "applying": true, "strength": 0.3771}, {"orb": 5.979917146260448, "angle": 174.02008285373955, "aspect": "opposition", "planet1": "Moon", "planet2": "Mean_Node", "applying": true, "strength": 0.2525}, {"orb": 5.979917146260448, "angle": 5.979917146260448, "aspect": "conjunction", "planet1": "Moon", "planet2": "Lilith", "applying": true, "strength": 0.2525}, {"orb": 1.9967538500075648, "angle": 133.00324614999244, "aspect": "sesquiquadrate", "planet1": "Mercury", "planet2": "Saturn", "applying": true, "strength": 0.0016}, {"orb": 1.7966538374054721, "angle": 43.20334616259453, "aspect": "semisquare", "planet1": "Mercury", "planet2": "True_Node", "applying": true, "strength": 0.1017}, {"orb": 0.800323854424903, "angle": 44.1996761455751, "aspect": "semisquare", "planet1": "Mercury", "planet2": "Mean_Node", "applying": true, "strength": 0.5998}, {"orb": 0.6421858680180321, "angle": 150.64218586801803, "aspect": "quincunx", "planet1": "Mercury", "planet2": "Chiron", "applying": true, "strength": 0.7859}, {"orb": 0.800323854424903, "angle": 135.8003238544249, "aspect": "sesquiquadrate", "planet1": "Mercury", "planet2": "Lilith", "applying": true, "strength": 0.5998}, {"orb": 0.04667796479040476, "angle": 45.046677964790405, "aspect": "semisquare", "planet1": "Venus", "planet2": "Uranus", "applying": true, "strength": 0.9767}, {"orb": 2.8391518260825137, "angle": 2.8391518260825137, "aspect": "conjunction", "planet1": "Venus", "planet2": "Neptune", "applying": true, "strength": 0.6451}, {"orb": 3.4592551149147255, "angle": 63.459255114914725, "aspect": "sextile", "planet1": "Venus", "planet2": "Pluto", "applying": true, "strength": 0.1352}, {"orb": 1.5048706887703247, "angle": 91.50487068877032, "aspect": "square", "planet1": "Mars", "planet2": "Jupiter", "applying": false, "strength": 0.7492}, {"orb": 0.4125942758429275, "angle": 60.41259427584293, "aspect": "sextile", "planet1": "Mars", "planet2": "Saturn", "applying": false, "strength": 0.8969}, {"orb": 1.2945683403337966, "angle": 148.7054316596662, "aspect": "quincunx", "planet1": "Mars", "planet2": "Neptune", "applying": false, "strength": 0.5685}, {"orb": 0.6744650515015849, "angle": 150.67446505150158, "aspect": "quincunx", "planet1": "Mars", "planet2": "Pluto", "applying": false, "strength": 0.7752}, {"orb": 3.3808134115701307, "angle": 123.38081341157013, "aspect": "trine", "planet1": "Mars", "planet2": "True_Node", "applying": false, "strength": 0.4365}, {"orb": 2.3844834285895615, "angle": 122.38448342858956, "aspect": "trine", "planet1": "Mars", "planet2": "Mean_Node", "applying": false, "strength": 0.6026}, {"orb": 2.3844834285895544, "angle": 57.615516571410446, "aspect": "sextile", "planet1": "Mars", "planet2": "Lilith", "applying": false, "strength": 0.4039}, {"orb": 1.9174649646132593, "angle": 151.91746496461326, "aspect": "quincunx", "planet1": "Jupiter", "planet2": "Saturn", "applying": true, "strength": 0.3608}, {"orb": 2.7994390291041498, "angle": 57.20056097089585, "aspect": "sextile", "planet1": "Jupiter", "planet2": "Neptune", "applying": true, "strength": 0.3001}, {"orb": 2.179335740271938, "angle": 117.82066425972806, "aspect": "trine", "planet1": "Jupiter", "planet2": "Pluto", "applying": true, "strength": 0.6368}, {"orb": 1.8759427227997776, "angle": 31.875942722799778, "aspect": "semisextile", "planet1": "Jupiter", "planet2": "True_Node", "applying": true, "strength": 0.062}, {"orb": 0.8796127398192084, "angle": 30.87961273981921, "aspect": "semisextile", "planet1": "Jupiter", "planet2": "Mean_Node", "applying": true, "strength": 0.5602}, {"orb": 0.8796127398192084, "angle": 149.1203872601808, "aspect": "quincunx", "planet1": "Jupiter", "planet2": "Lilith", "applying": true, "strength": 0.7068}, {"orb": 0.881974064490862, "angle": 150.88197406449086, "aspect": "quincunx", "planet1": "Saturn", "planet2": "Neptune", "applying": false, "strength": 0.706}, {"orb": 0.26187077565866446, "angle": 90.26187077565866, "aspect": "square", "planet1": "Saturn", "planet2": "Pluto", "applying": false, "strength": 0.9564}, {"orb": 3.793407687413037, "angle": 176.20659231258696, "aspect": "opposition", "planet1": "Saturn", "planet2": "True_Node", "applying": true, "strength": 0.5258}, {"orb": 2.7970777044324677, "angle": 177.20292229556753, "aspect": "opposition", "planet1": "Saturn", "planet2": "Mean_Node", "applying": true, "strength": 0.6504}, {"orb": 2.797077704432482, "angle": 2.797077704432482, "aspect": "conjunction", "planet1": "Saturn", "planet2": "Lilith", "applying": true, "strength": 0.6504}, {"orb": 5.029015907772532, "angle": 174.97098409222747, "aspect": "opposition", "planet1": "Uranus", "planet2": "Chiron", "applying": true, "strength": 0.3714}, {"orb": 0.6201032888322118, "angle": 60.62010328883221, "aspect": "sextile", "planet1": "Neptune", "planet2": "Pluto", "applying": false, "strength": 0.845}, {"orb": 4.055278463071716, "angle": 85.94472153692828, "aspect": "square", "planet1": "Pluto", "planet2": "True_Node", "applying": true, "strength": 0.3241}, {"orb": 3.0589484800911464, "angle": 86.94105151990885, "aspect": "square", "planet1": "Pluto", "planet2": "Mean_Node", "applying": true, "strength": 0.4902}, {"orb": 3.0589484800911464, "angle": 93.05894848009115, "aspect": "square", "planet1": "Pluto", "planet2": "Lilith", "applying": true, "strength": 0.4902}, {"orb": 0.9963299829805692, "angle": 0.9963299829805692, "aspect": "conjunction", "planet1": "True_Node", "planet2": "Mean_Node", "applying": true, "strength": 0.8755}, {"orb": 0.9963299829805692, "angle": 179.00367001701943, "aspect": "opposition", "planet1": "True_Node", "planet2": "Lilith", "applying": true, "strength": 0.8755}, {"orb": 0.0, "angle": 180.0, "aspect": "opposition", "planet1": "Mean_Node", "planet2": "Lilith", "applying": false, "strength": 1}]	{"yoga": 19, "tithi": 21, "karana": 8, "nakshatra": 5, "yoga_name": "Parigha", "tithi_name": "Shashthi", "karana_name": "Vishti", "nakshatra_name": "Mrigashira", "nakshatra_pada": 3}	{"years": 2.6588412290263976, "planet": "Mars", "end_date": "1976-06-14T00:06:07.969123+00:00", "start_date": "1973-10-16T20:42:00+00:00", "sub_periods": [{"years": 0.15509907169320652, "planet": "Ketu", "end_date": "1973-12-12T12:17:54.464866+00:00", "start_date": "1973-10-16T20:42:00+00:00", "sub_periods": [{"years": 0.02584984528220109, "planet": "Venus", "end_date": "1973-10-26T07:17:59.077478+00:00", "start_date": "1973-10-16T20:42:00+00:00", "sub_periods": []}, {"years": 0.012924922641100544, "planet": "Moon", "end_date": "1973-10-31T00:35:58.616217+00:00", "start_date": "1973-10-26T07:17:59.077478+00:00", "sub_periods": []}, {"years": 0.02326486075398098, "planet": "Rahu", "end_date": "1973-11-08T12:32:21.785947+00:00", "start_date": "1973-10-31T00:35:58.616217+00:00", "sub_periods": []}, {"years": 0.02067987622576087, "planet": "Jupiter", "end_date": "1973-11-16T01:49:09.047929+00:00", "start_date": "1973-11-08T12:32:21.785947+00:00", "sub_periods": []}, {"years": 0.024557353018091033, "planet": "Saturn", "end_date": "1973-11-25T01:05:20.171533+00:00", "start_date": "1973-11-16T01:49:09.047929+00:00", "sub_periods": []}, {"years": 0.021972368489870924, "planet": "Mercury", "end_date": "1973-12-03T01:41:55.387389+00:00", "start_date": "1973-11-25T01:05:20.171533+00:00", "sub_periods": []}]}, {"years": 0.4431402048377329, "planet": "Venus", "end_date": "1974-05-23T08:51:55.793053+00:00", "start_date": "1973-12-12T12:17:54.464866+00:00", "sub_periods": [{"years": 0.025849845282201085, "planet": "Ketu", "end_date": "1973-12-21T22:53:53.542344+00:00", "start_date": "1973-12-12T12:17:54.464866+00:00", "sub_periods": []}, {"years": 0.07385670080628882, "planet": "Venus", "end_date": "1974-01-17T22:19:33.763709+00:00", "start_date": "1973-12-21T22:53:53.542344+00:00", "sub_periods": []}, {"years": 0.022157010241886647, "planet": "Sun", "end_date": "1974-01-26T00:33:15.830118+00:00", "start_date": "1974-01-17T22:19:33.763709+00:00", "sub_periods": []}, {"years": 0.03692835040314441, "planet": "Moon", "end_date": "1974-02-08T12:16:05.940800+00:00", "start_date": "1974-01-26T00:33:15.830118+00:00", "sub_periods": []}, {"years": 0.025849845282201085, "planet": "Mars", "end_date": "1974-02-17T22:52:05.018278+00:00", "start_date": "1974-02-08T12:16:05.940800+00:00", "sub_periods": []}, {"years": 0.06647103072565994, "planet": "Rahu", "end_date": "1974-03-14T05:33:11.217506+00:00", "start_date": "1974-02-17T22:52:05.018278+00:00", "sub_periods": []}, {"years": 0.05908536064503105, "planet": "Jupiter", "end_date": "1974-04-04T19:29:43.394598+00:00", "start_date": "1974-03-14T05:33:11.217506+00:00", "sub_periods": []}, {"years": 0.07016386576597439, "planet": "Saturn", "end_date": "1974-04-30T10:33:06.604894+00:00", "start_date": "1974-04-04T19:29:43.394598+00:00", "sub_periods": []}, {"years": 0.0627781956853455, "planet": "Mercury", "end_date": "1974-05-23T08:51:55.793054+00:00", "start_date": "1974-04-30T10:33:06.604894+00:00", "sub_periods": []}]}, {"years": 0.13294206145131987, "planet": "Sun", "end_date": "1974-07-10T22:14:08.191509+00:00", "start_date": "1974-05-23T08:51:55.793053+00:00", "sub_periods": [{"years": 0.022157010241886647, "planet": "Venus", "end_date": "1974-05-31T11:05:37.859462+00:00", "start_date": "1974-05-23T08:51:55.793053+00:00", "sub_periods": []}, {"years": 0.011078505120943324, "planet": "Moon", "end_date": "1974-06-04T12:12:28.892667+00:00", "start_date": "1974-05-31T11:05:37.859462+00:00", "sub_periods": []}, {"years": 0.019941309217697982, "planet": "Rahu", "end_date": "1974-06-11T19:00:48.752435+00:00", "start_date": "1974-06-04T12:12:28.892667+00:00", "sub_periods": []}, {"years": 0.017725608193509317, "planet": "Jupiter", "end_date": "1974-06-18T06:23:46.405562+00:00", "start_date": "1974-06-11T19:00:48.752435+00:00", "sub_periods": []}, {"years": 0.021049159729792315, "planet": "Saturn", "end_date": "1974-06-25T22:54:47.368651+00:00", "start_date": "1974-06-18T06:23:46.405562+00:00", "sub_periods": []}, {"years": 0.01883345870560365, "planet": "Mercury", "end_date": "1974-07-02T20:00:26.125099+00:00", "start_date": "1974-06-25T22:54:47.368651+00:00", "sub_periods": []}]}, {"years": 0.22157010241886646, "planet": "Moon", "end_date": "1974-09-29T20:31:08.855603+00:00", "start_date": "1974-07-10T22:14:08.191509+00:00", "sub_periods": [{"years": 0.012924922641100543, "planet": "Ketu", "end_date": "1974-07-15T15:32:07.730248+00:00", "start_date": "1974-07-10T22:14:08.191509+00:00", "sub_periods": []}, {"years": 0.03692835040314441, "planet": "Venus", "end_date": "1974-07-29T03:14:57.840930+00:00", "start_date": "1974-07-15T15:32:07.730248+00:00", "sub_periods": []}, {"years": 0.011078505120943324, "planet": "Sun", "end_date": "1974-08-02T04:21:48.874135+00:00", "start_date": "1974-07-29T03:14:57.840930+00:00", "sub_periods": []}, {"years": 0.018464175201572206, "planet": "Moon", "end_date": "1974-08-08T22:13:13.929476+00:00", "start_date": "1974-08-02T04:21:48.874135+00:00", "sub_periods": []}, {"years": 0.012924922641100543, "planet": "Mars", "end_date": "1974-08-13T15:31:13.468215+00:00", "start_date": "1974-08-08T22:13:13.929476+00:00", "sub_periods": []}, {"years": 0.03323551536282997, "planet": "Rahu", "end_date": "1974-08-25T18:51:46.567829+00:00", "start_date": "1974-08-13T15:31:13.468215+00:00", "sub_periods": []}, {"years": 0.029542680322515526, "planet": "Jupiter", "end_date": "1974-09-05T13:50:02.656375+00:00", "start_date": "1974-08-25T18:51:46.567829+00:00", "sub_periods": []}, {"years": 0.035081932882987193, "planet": "Saturn", "end_date": "1974-09-18T09:21:44.261523+00:00", "start_date": "1974-09-05T13:50:02.656375+00:00", "sub_periods": []}, {"years": 0.03138909784267275, "planet": "Mercury", "end_date": "1974-09-29T20:31:08.855603+00:00", "start_date": "1974-09-18T09:21:44.261523+00:00", "sub_periods": []}]}, {"years": 0.15509907169320652, "planet": "Mars", "end_date": "1974-11-25T12:07:03.320469+00:00", "start_date": "1974-09-29T20:31:08.855603+00:00", "sub_periods": [{"years": 0.02584984528220109, "planet": "Venus", "end_date": "1974-10-09T07:07:07.933081+00:00", "start_date": "1974-09-29T20:31:08.855603+00:00", "sub_periods": []}, {"years": 0.012924922641100544, "planet": "Moon", "end_date": "1974-10-14T00:25:07.471820+00:00", "start_date": "1974-10-09T07:07:07.933081+00:00", "sub_periods": []}, {"years": 0.02326486075398098, "planet": "Rahu", "end_date": "1974-10-22T12:21:30.641550+00:00", "start_date": "1974-10-14T00:25:07.471820+00:00", "sub_periods": []}, {"years": 0.02067987622576087, "planet": "Jupiter", "end_date": "1974-10-30T01:38:17.903532+00:00", "start_date": "1974-10-22T12:21:30.641550+00:00", "sub_periods": []}, {"years": 0.024557353018091033, "planet": "Saturn", "end_date": "1974-11-08T00:54:29.027136+00:00", "start_date": "1974-10-30T01:38:17.903532+00:00", "sub_periods": []}, {"years": 0.021972368489870924, "planet": "Mercury", "end_date": "1974-11-16T01:31:04.242992+00:00", "start_date": "1974-11-08T00:54:29.027136+00:00", "sub_periods": []}]}, {"years": 0.3988261843539596, "planet": "Rahu", "end_date": "1975-04-20T04:13:40.515838+00:00", "start_date": "1974-11-25T12:07:03.320469+00:00", "sub_periods": [{"years": 0.023264860753980977, "planet": "Ketu", "end_date": "1974-12-04T00:03:26.490199+00:00", "start_date": "1974-11-25T12:07:03.320469+00:00", "sub_periods": []}, {"years": 0.06647103072565994, "planet": "Venus", "end_date": "1974-12-28T06:44:32.689427+00:00", "start_date": "1974-12-04T00:03:26.490199+00:00", "sub_periods": []}, {"years": 0.019941309217697982, "planet": "Sun", "end_date": "1975-01-04T13:32:52.549195+00:00", "start_date": "1974-12-28T06:44:32.689427+00:00", "sub_periods": []}, {"years": 0.03323551536282997, "planet": "Moon", "end_date": "1975-01-16T16:53:25.648809+00:00", "start_date": "1975-01-04T13:32:52.549195+00:00", "sub_periods": []}, {"years": 0.023264860753980977, "planet": "Mars", "end_date": "1975-01-25T04:49:48.818539+00:00", "start_date": "1975-01-16T16:53:25.648809+00:00", "sub_periods": []}, {"years": 0.059823927653093946, "planet": "Rahu", "end_date": "1975-02-16T01:14:48.397844+00:00", "start_date": "1975-01-25T04:49:48.818539+00:00", "sub_periods": []}, {"years": 0.05317682458052795, "planet": "Jupiter", "end_date": "1975-03-07T11:23:41.357226+00:00", "start_date": "1975-02-16T01:14:48.397844+00:00", "sub_periods": []}, {"years": 0.06314747918937694, "planet": "Saturn", "end_date": "1975-03-30T12:56:44.246493+00:00", "start_date": "1975-03-07T11:23:41.357226+00:00", "sub_periods": []}, {"years": 0.05650037611681094, "planet": "Mercury", "end_date": "1975-04-20T04:13:40.515837+00:00", "start_date": "1975-03-30T12:56:44.246493+00:00", "sub_periods": []}]}, {"years": 0.35451216387018636, "planet": "Jupiter", "end_date": "1975-08-27T15:52:53.578388+00:00", "start_date": "1975-04-20T04:13:40.515838+00:00", "sub_periods": [{"years": 0.02067987622576087, "planet": "Ketu", "end_date": "1975-04-27T17:30:27.777820+00:00", "start_date": "1975-04-20T04:13:40.515838+00:00", "sub_periods": []}, {"years": 0.05908536064503107, "planet": "Venus", "end_date": "1975-05-19T07:26:59.954912+00:00", "start_date": "1975-04-27T17:30:27.777820+00:00", "sub_periods": []}, {"years": 0.017725608193509317, "planet": "Sun", "end_date": "1975-05-25T18:49:57.608039+00:00", "start_date": "1975-05-19T07:26:59.954912+00:00", "sub_periods": []}, {"years": 0.029542680322515533, "planet": "Moon", "end_date": "1975-06-05T13:48:13.696585+00:00", "start_date": "1975-05-25T18:49:57.608039+00:00", "sub_periods": []}, {"years": 0.02067987622576087, "planet": "Mars", "end_date": "1975-06-13T03:05:00.958567+00:00", "start_date": "1975-06-05T13:48:13.696585+00:00", "sub_periods": []}, {"years": 0.05317682458052796, "planet": "Rahu", "end_date": "1975-07-02T13:13:53.917949+00:00", "start_date": "1975-06-13T03:05:00.958567+00:00", "sub_periods": []}, {"years": 0.047268288516024846, "planet": "Jupiter", "end_date": "1975-07-19T19:35:07.659622+00:00", "start_date": "1975-07-02T13:13:53.917949+00:00", "sub_periods": []}, {"years": 0.05613109261277951, "planet": "Saturn", "end_date": "1975-08-09T07:37:50.227859+00:00", "start_date": "1975-07-19T19:35:07.659622+00:00", "sub_periods": []}, {"years": 0.050222556548276405, "planet": "Mercury", "end_date": "1975-08-27T15:52:53.578387+00:00", "start_date": "1975-08-09T07:37:50.227859+00:00", "sub_periods": []}]}, {"years": 0.4209831945958463, "planet": "Saturn", "end_date": "1976-01-28T10:13:12.840166+00:00", "start_date": "1975-08-27T15:52:53.578388+00:00", "sub_periods": [{"years": 0.024557353018091036, "planet": "Ketu", "end_date": "1975-09-05T15:09:04.701992+00:00", "start_date": "1975-08-27T15:52:53.578388+00:00", "sub_periods": []}, {"years": 0.07016386576597439, "planet": "Venus", "end_date": "1975-10-01T06:12:27.912288+00:00", "start_date": "1975-09-05T15:09:04.701992+00:00", "sub_periods": []}, {"years": 0.021049159729792318, "planet": "Sun", "end_date": "1975-10-08T22:43:28.875377+00:00", "start_date": "1975-10-01T06:12:27.912288+00:00", "sub_periods": []}, {"years": 0.035081932882987193, "planet": "Moon", "end_date": "1975-10-21T18:15:10.480525+00:00", "start_date": "1975-10-08T22:43:28.875377+00:00", "sub_periods": []}, {"years": 0.024557353018091036, "planet": "Mars", "end_date": "1975-10-30T17:31:21.604129+00:00", "start_date": "1975-10-21T18:15:10.480525+00:00", "sub_periods": []}, {"years": 0.06314747918937695, "planet": "Rahu", "end_date": "1975-11-22T19:04:24.493396+00:00", "start_date": "1975-10-30T17:31:21.604129+00:00", "sub_periods": []}, {"years": 0.05613109261277951, "planet": "Jupiter", "end_date": "1975-12-13T07:07:07.061633+00:00", "start_date": "1975-11-22T19:04:24.493396+00:00", "sub_periods": []}, {"years": 0.06665567247767566, "planet": "Saturn", "end_date": "1976-01-06T15:25:20.111414+00:00", "start_date": "1975-12-13T07:07:07.061633+00:00", "sub_periods": []}, {"years": 0.05963928590107823, "planet": "Mercury", "end_date": "1976-01-28T10:13:12.840166+00:00", "start_date": "1976-01-06T15:25:20.111414+00:00", "sub_periods": []}]}, {"years": 0.376669174112073, "planet": "Mercury", "end_date": "1976-06-14T00:06:07.969125+00:00", "start_date": "1976-01-28T10:13:12.840166+00:00", "sub_periods": [{"years": 0.021972368489870928, "planet": "Ketu", "end_date": "1976-02-05T10:49:48.056022+00:00", "start_date": "1976-01-28T10:13:12.840166+00:00", "sub_periods": []}, {"years": 0.0627781956853455, "planet": "Venus", "end_date": "1976-02-28T09:08:37.244182+00:00", "start_date": "1976-02-05T10:49:48.056022+00:00", "sub_periods": []}, {"years": 0.018833458705603653, "planet": "Sun", "end_date": "1976-03-06T06:14:16.000630+00:00", "start_date": "1976-02-28T09:08:37.244182+00:00", "sub_periods": []}, {"years": 0.03138909784267275, "planet": "Moon", "end_date": "1976-03-17T17:23:40.594710+00:00", "start_date": "1976-03-06T06:14:16.000630+00:00", "sub_periods": []}, {"years": 0.021972368489870928, "planet": "Mars", "end_date": "1976-03-25T18:00:15.810566+00:00", "start_date": "1976-03-17T17:23:40.594710+00:00", "sub_periods": []}, {"years": 0.05650037611681095, "planet": "Rahu", "end_date": "1976-04-15T09:17:12.079910+00:00", "start_date": "1976-03-25T18:00:15.810566+00:00", "sub_periods": []}, {"years": 0.050222556548276405, "planet": "Jupiter", "end_date": "1976-05-03T17:32:15.430438+00:00", "start_date": "1976-04-15T09:17:12.079910+00:00", "sub_periods": []}, {"years": 0.059639285901078226, "planet": "Saturn", "end_date": "1976-05-25T12:20:08.159190+00:00", "start_date": "1976-05-03T17:32:15.430438+00:00", "sub_periods": []}, {"years": 0.053361466332543676, "planet": "Mercury", "end_date": "1976-06-14T00:06:07.969126+00:00", "start_date": "1976-05-25T12:20:08.159190+00:00", "sub_periods": []}]}]}	{"Art": {"sign": "Leo", "longitude": 137.4117395782274, "interpretation": "Искусство, творчество, эстетика, гармония"}, "Gain": {"sign": "Aries", "longitude": 25.188989148876146, "interpretation": "Прибыль, приобретения, выгода"}, "Home": {"sign": "Cancer", "longitude": 107.91686498695351, "interpretation": "Дом, семья, корни, недвижимость"}, "Loss": {"sign": "Aquarius", "longitude": 322.97273394707304, "interpretation": "Потери, утраты, расставания"}, "Love": {"sign": "Virgo", "longitude": 161.8297392827894, "interpretation": "Любовные отношения, романтика"}, "Risk": {"sign": "Libra", "longitude": 208.1987305264168, "interpretation": "Риск, авантюра, опасность"}, "Soul": {"sign": "Scorpio", "longitude": 234.0561011337698, "interpretation": "Душа, внутренняя сущность, истинное Я"}, "Death": {"sign": "Leo", "longitude": 125.47085468833939, "interpretation": "Трансформация, потери"}, "Faith": {"sign": "Scorpio", "longitude": 216.19114842760277, "interpretation": "Религия, вера, убеждения"}, "Karma": {"sign": "Leo", "longitude": 125.47085468833939, "interpretation": "Карма, долги, уроки прошлого"}, "Magic": {"sign": "Capricorn", "longitude": 276.35282875283025, "interpretation": "Магия, мистика, оккультные способности"}, "Power": {"sign": "Cancer", "longitude": 98.37048416787465, "interpretation": "Власть, влияние, трансформация"}, "Truth": {"sign": "Gemini", "longitude": 74.397132218586, "interpretation": "Истина, правда, реальность"}, "Career": {"sign": "Sagittarius", "longitude": 268.61132480225973, "interpretation": "Карьера, призвание, социальный статус, достижения"}, "Change": {"sign": "Scorpio", "longitude": 234.14530261412233, "interpretation": "Перемены, изменения, трансформация"}, "Enmity": {"sign": "Taurus", "longitude": 56.28126556180352, "interpretation": "Вражда, конфликты, соперничество, борьба"}, "Father": {"sign": "Scorpio", "longitude": 212.11566168530192, "interpretation": "Отношения с отцом"}, "Genius": {"sign": "Leo", "longitude": 141.02265806185585, "interpretation": "Гениальность, озарения, инсайты"}, "Mother": {"sign": "Scorpio", "longitude": 239.69755142905905, "interpretation": "Отношения с матерью"}, "Reason": {"sign": "Sagittarius", "longitude": 258.47410083833176, "interpretation": "Разум, логика, рациональное мышление"}, "Spirit": {"sign": "Scorpio", "longitude": 234.0561011337698, "interpretation": "Духовность, внутренний мир, философия"}, "Travel": {"sign": "Pisces", "longitude": 333.5533897237261, "interpretation": "Путешествия, перемещения, экспансия, дальние поездки"}, "Wisdom": {"sign": "Libra", "longitude": 191.77314872304078, "interpretation": "Мудрость, знание, философия"}, "Courage": {"sign": "Capricorn", "longitude": 283.2780194118111, "interpretation": "Смелость, решительность, сила духа"}, "Destiny": {"sign": "Aries", "longitude": 8.108613392216029, "interpretation": "Судьба, предназначение, рок, фатум"}, "Fortune": {"sign": "Pisces", "longitude": 359.3316185415231, "interpretation": "Материальное благополучие, успех, удача"}, "Freedom": {"sign": "Scorpio", "longitude": 225.3683077634294, "interpretation": "Свобода, независимость, освобождение"}, "Healing": {"sign": "Taurus", "longitude": 49.116286706349825, "interpretation": "Исцеление, целительство, восстановление"}, "Passion": {"sign": "Sagittarius", "longitude": 262.5601396712301, "interpretation": "Страсть, творческая энергия"}, "Science": {"sign": "Sagittarius", "longitude": 249.69710598763885, "interpretation": "Наука, исследования, методология, открытия"}, "Secrets": {"sign": "Gemini", "longitude": 73.95248446331266, "interpretation": "Тайны, секреты, скрытая информация"}, "Service": {"sign": "Pisces", "longitude": 334.91361883696106, "interpretation": "Служение, помощь, альтруизм"}, "Victory": {"sign": "Aquarius", "longitude": 324.7763948730332, "interpretation": "Победа, достижения, триумф"}, "Children": {"sign": "Virgo", "longitude": 171.0552689824598, "interpretation": "Дети, творчество"}, "Commerce": {"sign": "Leo", "longitude": 141.1118595422084, "interpretation": "Бизнес, торговля, коммуникации"}, "Illusion": {"sign": "Leo", "longitude": 134.5725877521449, "interpretation": "Иллюзии, заблуждения, обман"}, "Learning": {"sign": "Taurus", "longitude": 41.61457095225211, "interpretation": "Обучение, образование, познание"}, "Marriage": {"sign": "Capricorn", "longitude": 270.41498572821985, "interpretation": "Брак, партнерство"}, "Sickness": {"sign": "Taurus", "longitude": 56.28126556180352, "interpretation": "Здоровье, болезни"}, "Teaching": {"sign": "Aquarius", "longitude": 324.7763948730332, "interpretation": "Учительство, наставничество, передача знаний"}, "Abundance": {"sign": "Virgo", "longitude": 171.0552689824598, "interpretation": "Изобилие, процветание, богатство"}, "Intuition": {"sign": "Pisces", "longitude": 334.91361883696106, "interpretation": "Интуиция, предчувствия, подсознание"}, "Necessity": {"sign": "Aries", "longitude": 8.108613392216029, "interpretation": "Необходимость, обязательства, кармические долги"}, "Stability": {"sign": "Leo", "longitude": 125.47085468833939, "interpretation": "Стабильность, устойчивость, надежность"}, "Creativity": {"sign": "Pisces", "longitude": 330.8275800040628, "interpretation": "Творчество, креативность, самовыражение"}, "Discipline": {"sign": "Virgo", "longitude": 177.10645411348938, "interpretation": "Дисциплина, порядок, структура"}, "Friendship": {"sign": "Aquarius", "longitude": 314.1957390963801, "interpretation": "Дружба, социальные связи, единомышленники"}, "Leadership": {"sign": "Scorpio", "longitude": 225.27910628307689, "interpretation": "Лидерство, управление, руководство"}, "Inspiration": {"sign": "Cancer", "longitude": 113.85470801156393, "interpretation": "Вдохновение, идеалы, мечты"}, "Imprisonment": {"sign": "Virgo", "longitude": 177.10645411348938, "interpretation": "Ограничения, тюрьма, изоляция, заточение"}, "Communication": {"sign": "Cancer", "longitude": 95.97598009706545, "interpretation": "Коммуникация, общение, связь"}}	[{"name": "Regulus", "latitude": "R", "longitude": 149.46591856821695, "magnitude": 1.35, "conjunctions": [], "constellation": "Leo"}, {"name": "Spica", "latitude": "S", "longitude": 203.47434333569353, "magnitude": 0.98, "conjunctions": [{"orb": 0.13567650108456064, "planet": "Sun"}, {"orb": 0.04647502073200371, "planet": "Uranus"}], "constellation": "Virgo"}, {"name": "Antares", "latitude": "A", "longitude": 249.39676855341128, "magnitude": 0.96, "conjunctions": [{"orb": 0.9222222736593437, "planet": "Venus"}], "constellation": "Scorpio"}, {"name": "Sirius", "latitude": "S", "longitude": 103.72643347276431, "magnitude": -1.46, "conjunctions": [], "constellation": "Canis Major"}, {"name": "Vega", "latitude": "V", "longitude": 284.95131259748865, "magnitude": 0.03, "conjunctions": [], "constellation": "Lyra"}, {"name": "Aldebaran", "latitude": "A", "longitude": 69.43127993798281, "magnitude": 0.87, "conjunctions": [], "constellation": "Taurus"}, {"name": "Rigel", "latitude": "R", "longitude": 76.4717619209457, "magnitude": 0.18, "conjunctions": [], "constellation": "Orion"}, {"name": "Betelgeuse", "latitude": "B", "longitude": 88.39543481681882, "magnitude": 0.45, "conjunctions": [], "constellation": "Orion"}, {"name": "Procyon", "latitude": "P", "longitude": 115.4283511661239, "magnitude": 0.34, "conjunctions": [], "constellation": "Canis Minor"}, {"name": "Achernar", "latitude": "A", "longitude": 344.9521499509923, "magnitude": 0.46, "conjunctions": [], "constellation": "Eridanus"}, {"name": "Hadar", "latitude": "H", "longitude": 233.4255771560851, "magnitude": 0.61, "conjunctions": [], "constellation": "Centaurus"}, {"name": "Altair", "latitude": "A", "longitude": 301.41164723457365, "magnitude": 0.77, "conjunctions": [], "constellation": "Aquila"}, {"name": "Acrux", "latitude": "A", "longitude": 221.50254743721797, "magnitude": 0.77, "conjunctions": [], "constellation": "Crux"}, {"name": "Fomalhaut", "latitude": "F", "longitude": 333.49943443363196, "magnitude": 1.17, "conjunctions": [], "constellation": "Piscis Austrinus"}]	{"is_day": false, "planet": "Venus", "sunset": "1973-10-16T18:00:00+00:00", "sunrise": "1973-10-16T06:00:00+00:00", "day_hours": 12.0, "hour_number": 3, "night_hours": 12.0}	24.374218	5035.7973	t	242.64	{"sign": "Gemini", "house": 12, "tithi": 0, "is_void": true, "age_days": 19.9, "nakshatra": "", "next_phase": "Last Quarter", "phase_name": "Waning Gibbous", "distance_km": 368105, "phase_angle": 242.63775870387664, "illumination": 0.75, "is_blue_moon": false, "is_super_moon": false, "nakshatra_pada": 0, "is_eclipse_season": true, "days_to_next_phase": 2.24}	{"sign": "Libra", "house": 4, "season": "autumn", "sunset": null, "dignity": {"face": "Face of Jupiter", "fall": "Fall", "term": "Term of Venus", "exaltation": "Near Exalted"}, "sunrise": null, "day_length": 12, "is_equinox": false, "declination": -0.0001, "distance_km": 149086133, "is_solstice": false, "right_ascension": 13.5559}	[]	[]	[{"sign": "Gemini", "degree": 25.976425538485614, "planet": "Moon", "critical_degree": 26}, {"sign": "Capricorn", "degree": 0.9600127017654927, "planet": "True_Node", "critical_degree": 0}]	{"Sun_Mars": 118.8397464739723, "Sun_Moon": 144.65754618654728, "Moon_Mars": 60.15862582591062, "Sun_Pluto": 194.17697899972308, "Sun_Venus": 225.90660655718045, "Mars_Pluto": 109.67805863908642, "Moon_Pluto": 135.4958583516614, "Moon_Venus": 167.2254859091188, "Sun_Chiron": 290.86875962089897, "Sun_Lilith": 147.64750475967753, "Sun_Saturn": 149.04604361189377, "Sun_Uranus": 203.38326757478524, "Venus_Mars": 321.40768619654375, "Mars_Chiron": 26.369839260262307, "Mars_Lilith": 63.14858439904084, "Mars_Saturn": 64.54712325125708, "Mars_Uranus": 118.88434721414858, "Moon_Chiron": 52.187638972837306, "Moon_Lilith": 88.96638411161584, "Moon_Saturn": 90.36492296383207, "Moon_Uranus": 144.70214692672357, "Sun_Jupiter": 253.08731112958714, "Sun_Mercury": 215.54766668688995, "Sun_Neptune": 224.4870306441392, "Venus_Pluto": 216.74491872229459, "Mars_Jupiter": 348.58839076895043, "Mars_Neptune": 319.9881102835025, "Mercury_Mars": 311.0487463262533, "Moon_Jupiter": 14.406190481525414, "Moon_Mercury": 156.8665460388283, "Moon_Neptune": 165.8059099960775, "Pluto_Chiron": 101.7070717860131, "Pluto_Lilith": 138.48581692479164, "Saturn_Pluto": 139.88435577700787, "Uranus_Pluto": 194.22157973989937, "Venus_Chiron": 313.4366993434705, "Venus_Lilith": 170.21544448224898, "Venus_Saturn": 171.61398333446525, "Venus_Uranus": 225.95120729735675, "Chiron_Lilith": 55.17759754596753, "Jupiter_Pluto": 243.92562329470124, "Mercury_Pluto": 206.3859788520041, "Mercury_Venus": 238.11560640946146, "Neptune_Pluto": 215.3253428092533, "Saturn_Chiron": 56.57613639818377, "Saturn_Lilith": 93.3548815369623, "Saturn_Uranus": 149.09064435207003, "Sun_Mean_Node": 237.64750475967753, "Sun_True_Node": 237.14933976818725, "Uranus_Chiron": 290.91336036107526, "Uranus_Lilith": 147.6921054998538, "Venus_Jupiter": 275.6552508521586, "Venus_Neptune": 247.05497036671068, "Jupiter_Chiron": 340.61740391587716, "Jupiter_Lilith": 17.396149054655666, "Jupiter_Saturn": 18.7946879068719, "Jupiter_Uranus": 253.1319118697634, "Mars_Mean_Node": 333.14858439904083, "Mars_True_Node": 332.65041940755054, "Mercury_Chiron": 303.07775947318, "Mercury_Lilith": 159.8565046119585, "Mercury_Saturn": 161.25504346417475, "Mercury_Uranus": 215.59226742706625, "Moon_Mean_Node": 358.96638411161587, "Moon_True_Node": 358.4682191201256, "Neptune_Chiron": 312.0171234304292, "Neptune_Lilith": 168.79586856920776, "Saturn_Neptune": 170.194407421424, "Uranus_Neptune": 224.53163138431546, "Jupiter_Neptune": 274.23567493911736, "Mercury_Jupiter": 265.29631098186815, "Mercury_Neptune": 236.69603049642018, "Pluto_Mean_Node": 228.48581692479164, "Pluto_True_Node": 227.98765193330135, "Venus_Mean_Node": 260.215444482249, "Venus_True_Node": 259.7172794907587, "Mean_Node_Chiron": 325.1775975459675, "Mean_Node_Lilith": 181.95634268474606, "Saturn_Mean_Node": 183.3548815369623, "Saturn_True_Node": 182.856716545472, "True_Node_Chiron": 324.6794325544772, "True_Node_Lilith": 181.45817769325578, "Uranus_Mean_Node": 237.6921054998538, "Uranus_True_Node": 237.1939405083635, "Jupiter_Mean_Node": 287.39614905465567, "Jupiter_True_Node": 286.8979840631654, "Mercury_Mean_Node": 249.8565046119585, "Mercury_True_Node": 249.35833962046823, "Neptune_Mean_Node": 258.79586856920776, "Neptune_True_Node": 258.29770357771747, "True_Node_Mean_Node": 271.4581776932558}	[{"orb": 2.637758703876642, "type": "trine", "nature": "гармония/талант", "applying": false, "strength": 0.560373549353893, "psychological": "легкость, поток. "}, {"orb": 0.13587944514296169, "type": "semisquare", "nature": "напряжение", "applying": false, "strength": 0.9320602774285192, "psychological": "мотивация. "}, {"orb": 0.08920148035255693, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.9888498149559304, "psychological": "интеграция качеств. гениальность"}, {"orb": 4.939814427419975, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.3825231965725031, "psychological": "осознание через других. "}, {"orb": 8.77699485069293, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0, "psychological": "интеграция качеств. эмоциональный контроль"}, {"orb": 2.548557223524085, "type": "trine", "nature": "гармония/талант", "applying": true, "strength": 0.5752404627459857, "psychological": "легкость, поток. "}, {"orb": 4.9835871632798785, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.3770516045900152, "psychological": "осознание через других. "}, {"orb": 5.979917146260448, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.25251035671744404, "psychological": "осознание через других. "}, {"orb": 5.979917146260448, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.25251035671744404, "psychological": "интеграция качеств. "}, {"orb": 1.9967538500075648, "type": "sesquiquadrate", "nature": "кризис", "applying": true, "strength": 0.0016230749962176105, "psychological": "очищение. "}, {"orb": 1.7966538374054721, "type": "semisquare", "nature": "напряжение", "applying": true, "strength": 0.10167308129726393, "psychological": "мотивация. "}, {"orb": 0.800323854424903, "type": "semisquare", "nature": "напряжение", "applying": true, "strength": 0.5998380727875485, "psychological": "мотивация. "}, {"orb": 0.6421858680180321, "type": "quincunx", "nature": "настройка/адаптация", "applying": true, "strength": 0.7859380439939893, "psychological": "гибкость, обучение. "}, {"orb": 0.800323854424903, "type": "sesquiquadrate", "nature": "кризис", "applying": true, "strength": 0.5998380727875485, "psychological": "очищение. "}, {"orb": 0.04667796479040476, "type": "semisquare", "nature": "напряжение", "applying": true, "strength": 0.9766610176047976, "psychological": "мотивация. "}, {"orb": 2.8391518260825137, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.6451060217396858, "psychological": "интеграция качеств. идеальная любовь"}, {"orb": 3.4592551149147255, "type": "sextile", "nature": "возможность", "applying": true, "strength": 0.13518622127131863, "psychological": "шанс, потенциал. "}, {"orb": 1.5048706887703247, "type": "square", "nature": "кризис/рост", "applying": false, "strength": 0.7491882185382792, "psychological": "мотивация, действие. "}, {"orb": 0.4125942758429275, "type": "sextile", "nature": "возможность", "applying": false, "strength": 0.8968514310392681, "psychological": "шанс, потенциал. "}, {"orb": 1.2945683403337966, "type": "quincunx", "nature": "настройка/адаптация", "applying": false, "strength": 0.5684772198887345, "psychological": "гибкость, обучение. "}, {"orb": 0.6744650515015849, "type": "quincunx", "nature": "настройка/адаптация", "applying": false, "strength": 0.7751783161661384, "psychological": "гибкость, обучение. "}, {"orb": 3.3808134115701307, "type": "trine", "nature": "гармония/талант", "applying": false, "strength": 0.4365310980716449, "psychological": "легкость, поток. "}, {"orb": 2.3844834285895615, "type": "trine", "nature": "гармония/талант", "applying": false, "strength": 0.602586095235073, "psychological": "легкость, поток. "}, {"orb": 2.3844834285895544, "type": "sextile", "nature": "возможность", "applying": false, "strength": 0.4038791428526114, "psychological": "шанс, потенциал. "}, {"orb": 1.9174649646132593, "type": "quincunx", "nature": "настройка/адаптация", "applying": true, "strength": 0.36084501179558026, "psychological": "гибкость, обучение. "}, {"orb": 2.7994390291041498, "type": "sextile", "nature": "возможность", "applying": true, "strength": 0.30014024272396256, "psychological": "шанс, потенциал. "}, {"orb": 2.179335740271938, "type": "trine", "nature": "гармония/талант", "applying": true, "strength": 0.6367773766213436, "psychological": "легкость, поток. "}, {"orb": 1.8759427227997776, "type": "semisextile", "nature": "развитие", "applying": true, "strength": 0.06202863860011121, "psychological": "потенциал роста. "}, {"orb": 0.8796127398192084, "type": "semisextile", "nature": "развитие", "applying": true, "strength": 0.5601936300903958, "psychological": "потенциал роста. "}, {"orb": 0.8796127398192084, "type": "quincunx", "nature": "настройка/адаптация", "applying": true, "strength": 0.7067957533935971, "psychological": "гибкость, обучение. "}, {"orb": 0.881974064490862, "type": "quincunx", "nature": "настройка/адаптация", "applying": false, "strength": 0.7060086451697127, "psychological": "гибкость, обучение. "}, {"orb": 0.26187077565866446, "type": "square", "nature": "кризис/рост", "applying": false, "strength": 0.956354870723556, "psychological": "мотивация, действие. "}, {"orb": 3.793407687413037, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.5258240390733704, "psychological": "осознание через других. "}, {"orb": 2.7970777044324677, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.6503652869459415, "psychological": "осознание через других. "}, {"orb": 2.797077704432482, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.6503652869459398, "psychological": "интеграция качеств. "}, {"orb": 5.029015907772532, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.3713730115284335, "psychological": "осознание через других. "}, {"orb": 0.6201032888322118, "type": "sextile", "nature": "возможность", "applying": false, "strength": 0.8449741777919471, "psychological": "шанс, потенциал. "}, {"orb": 4.055278463071716, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.32412025615471407, "psychological": "мотивация, действие. "}, {"orb": 3.0589484800911464, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.49017525331814227, "psychological": "мотивация, действие. "}, {"orb": 3.0589484800911464, "type": "square", "nature": "кризис/рост", "applying": true, "strength": 0.49017525331814227, "psychological": "мотивация, действие. "}, {"orb": 0.9963299829805692, "type": "conjunction", "nature": "синтез", "applying": true, "strength": 0.8754587521274289, "psychological": "интеграция качеств. "}, {"orb": 0.9963299829805692, "type": "opposition", "nature": "напряжение/проекция", "applying": true, "strength": 0.8754587521274289, "psychological": "осознание через других. "}, {"orb": 0.0, "type": "opposition", "nature": "напряжение/проекция", "applying": false, "strength": 1, "psychological": "осознание через других. "}]	{"yod": {"apex": "Mars", "base": ["Neptune", "Pluto"], "planets": ["Mars", "Neptune", "Pluto"], "description": "Йод (Палец Бога) с вершиной на Mars"}, "bowl": null, "kite": {"opposition": {"to": "Chiron", "planet": "Sun"}, "description": "Воздушный змей: Air трин + оппозиция", "grand_trine": ["Sun", "Moon", "Jupiter"]}, "bucket": {"sign": "Libra", "bucket": ["Sun", "Uranus", "Pluto"], "handle": "Chiron", "description": "Корзина: стеллмум в Libra с ручкой на Chiron"}, "bundle": null, "castle": null, "seesaw": {"left_group": ["Moon", "Mars", "Saturn", "Chiron", "Lilith"], "description": "Качели: 5 vs 9 планет", "oppositions": 8, "right_group": ["Sun", "Mercury", "Venus", "Jupiter", "Uranus", "Neptune", "Pluto", "True_Node", "Mean_Node"]}, "splash": null, "stellium": {"by_sign": {"Libra": 3}, "by_house": {"4": 3, "5": 3, "12": 3}}, "t_square": {"apex": "Pluto", "base": ["Saturn", "True_Node"], "planets": ["Saturn", "True_Node", "Pluto"], "description": "Тау-квадрат с вершиной на Pluto"}, "locomotive": {"planets": ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "True_Node", "Mean_Node", "Chiron", "Lilith"], "gap_size": 90.26187077565866, "gap_start": 94.75342038917854, "description": "Локомотив: пустой сектор 90.3°"}, "grand_cross": null, "grand_trine": [{"element": "Air", "planets": ["Sun", "Moon", "Jupiter"], "description": "Большой трин в Air знаках"}], "mystic_rectangle": {"confidence": "low", "description": "Мистический прямоугольник (возможен)"}}	[{"orb": 0.13567650108456064, "star": "Spica", "planet": "Sun", "meaning": "яркий талант", "negative": "лень от избытка даров", "positive": "гениальность, помощь"}, {"orb": 0.04647502073200371, "star": "Spica", "planet": "Uranus", "meaning": "дар, удача, талант", "negative": "лень от избытка даров", "positive": "гениальность, помощь"}, {"orb": 0.9222222736593437, "star": "Antares", "planet": "Venus", "meaning": "воин, защитник", "negative": "агрессия, разрушение", "positive": "мужество, защита"}]	{"Art": {"sign": "Leo", "house": 2, "aspects": [{"orb": 0.34492696094355324, "aspect": "square", "planet": "Mercury"}, {"orb": 0.9871128289615854, "aspect": "trine", "planet": "Chiron"}], "longitude": 137.4117395782274, "conjunctions": [], "interpretation": "Art в 2 доме"}, "Gain": {"sign": "Aries", "house": 10, "aspects": [{"orb": 1.8503223142671743, "aspect": "opposition", "planet": "Sun"}, {"orb": 0.7874363896094678, "aspect": "sextile", "planet": "Moon"}, {"orb": 1.7611208339146174, "aspect": "opposition", "planet": "Uranus"}], "longitude": 25.188989148876146, "conjunctions": [], "interpretation": "Gain в 10 доме"}, "Home": {"sign": "Cancer", "house": 12, "aspects": [{"orb": 0.16019844778254821, "aspect": "trine", "planet": "Mercury"}, {"orb": 0.4819874202354839, "aspect": "square", "planet": "Chiron"}], "longitude": 107.91686498695351, "conjunctions": [], "interpretation": "Home в 12 доме"}, "Loss": {"sign": "Aquarius", "house": 8, "aspects": [{"orb": 0.36593288753593356, "aspect": "trine", "planet": "Sun"}, {"orb": 3.0036915914125757, "aspect": "trine", "planet": "Moon"}, {"orb": 0.4551343678884905, "aspect": "trine", "planet": "Uranus"}, {"orb": 4.573881539884042, "aspect": "sextile", "planet": "Chiron"}], "longitude": 322.97273394707304, "conjunctions": [], "interpretation": "Loss в 8 доме"}, "Love": {"sign": "Virgo", "house": 3, "aspects": [{"orb": 3.3551930030374706, "aspect": "square", "planet": "Venus"}], "longitude": 161.8297392827894, "conjunctions": [], "interpretation": "Любовь в 3 доме: отношения через сферу дома"}, "Risk": {"sign": "Libra", "house": 4, "aspects": [{"orb": 4.860063691807824, "aspect": "conjunction", "planet": "Sun"}, {"orb": 2.2223049879311816, "aspect": "trine", "planet": "Moon"}, {"orb": 4.6372248981484745, "aspect": "square", "planet": "Jupiter"}, {"orb": 4.770862211455267, "aspect": "conjunction", "planet": "Uranus"}, {"orb": 2.761282175348697, "aspect": "sextile", "planet": "True_Node"}, {"orb": 3.757612158329266, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 3.757612158329266, "aspect": "trine", "planet": "Lilith"}], "longitude": 208.1987305264168, "conjunctions": [], "interpretation": "Risk в 4 доме"}, "Soul": {"sign": "Scorpio", "house": 5, "aspects": [], "longitude": 234.0561011337698, "conjunctions": [], "interpretation": "Soul в 5 доме"}, "Death": {"sign": "Leo", "house": 1, "aspects": [{"orb": 3.0036915914125473, "aspect": "trine", "planet": "Venus"}, {"orb": 1.130028575003763, "aspect": "square", "planet": "Mars"}, {"orb": 2.634899263774116, "aspect": "opposition", "planet": "Jupiter"}, {"orb": 0.16453976533003356, "aspect": "trine", "planet": "Neptune"}, {"orb": 0.4555635235021782, "aspect": "sextile", "planet": "Pluto"}], "longitude": 125.47085468833939, "conjunctions": [], "interpretation": "Трансформация в 1 доме: потери"}, "Faith": {"sign": "Scorpio", "house": 5, "aspects": [{"orb": 1.8503223142671459, "aspect": "opposition", "planet": "Mars"}, {"orb": 3.355193003037499, "aspect": "square", "planet": "Jupiter"}, {"orb": 1.4377280384242255, "aspect": "trine", "planet": "Saturn"}, {"orb": 4.234805742856707, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 4.234805742856707, "aspect": "trine", "planet": "Lilith"}], "longitude": 216.19114842760277, "conjunctions": [], "interpretation": "Вера в 5 доме: философские убеждения"}, "Karma": {"sign": "Leo", "house": 1, "aspects": [{"orb": 3.0036915914125473, "aspect": "trine", "planet": "Venus"}, {"orb": 1.130028575003763, "aspect": "square", "planet": "Mars"}, {"orb": 2.634899263774116, "aspect": "opposition", "planet": "Jupiter"}, {"orb": 0.16453976533003356, "aspect": "trine", "planet": "Neptune"}, {"orb": 0.4555635235021782, "aspect": "sextile", "planet": "Pluto"}], "longitude": 125.47085468833939, "conjunctions": [], "interpretation": "Karma в 1 доме"}, "Magic": {"sign": "Capricorn", "house": 6, "aspects": [{"orb": 2.012002639494625, "aspect": "trine", "planet": "Mars"}, {"orb": 1.599408363651719, "aspect": "opposition", "planet": "Saturn"}, {"orb": 1.3375375879930402, "aspect": "square", "planet": "Pluto"}, {"orb": 4.396486068084187, "aspect": "conjunction", "planet": "Mean_Node"}, {"orb": 4.396486068084187, "aspect": "opposition", "planet": "Lilith"}], "longitude": 276.35282875283025, "conjunctions": [], "interpretation": "Magic в 6 доме"}, "Power": {"sign": "Cancer", "house": 12, "aspects": [{"orb": 4.029658054539027, "aspect": "sextile", "planet": "Mars"}, {"orb": 3.6170637786961066, "aspect": "conjunction", "planet": "Saturn"}, {"orb": 3.355193003037442, "aspect": "square", "planet": "Pluto"}], "longitude": 98.37048416787465, "conjunctions": [], "interpretation": "Power в 12 доме"}, "Truth": {"sign": "Gemini", "house": 11, "aspects": [{"orb": 4.001720188603002, "aspect": "sextile", "planet": "Chiron"}], "longitude": 74.397132218586, "conjunctions": [], "interpretation": "Truth в 11 доме"}, "Career": {"sign": "Sagittarius", "house": 6, "aspects": [{"orb": 2.634899263774116, "aspect": "opposition", "planet": "Moon"}, {"orb": 2.3486878995057623, "aspect": "conjunction", "planet": "True_Node"}, {"orb": 3.3450178824863315, "aspect": "conjunction", "planet": "Mean_Node"}, {"orb": 3.3450178824863315, "aspect": "opposition", "planet": "Lilith"}], "longitude": 268.61132480225973, "conjunctions": [{"orb": 2.3486878995057623, "house": 6, "planet": "True_Node"}], "interpretation": "Career в 6 доме. Соединение с True_Node усиливает влияние"}, "Change": {"sign": "Scorpio", "house": 5, "aspects": [], "longitude": 234.14530261412233, "conjunctions": [], "interpretation": "Change в 5 доме"}, "Enmity": {"sign": "Taurus", "house": 11, "aspects": [], "longitude": 56.28126556180352, "conjunctions": [], "interpretation": "Enmity в 11 доме"}, "Father": {"sign": "Scorpio", "house": 4, "aspects": [{"orb": 2.2251644280337075, "aspect": "opposition", "planet": "Mars"}, {"orb": 0.7202937392633544, "aspect": "square", "planet": "Jupiter"}, {"orb": 2.637758703876628, "aspect": "trine", "planet": "Saturn"}, {"orb": 1.1556489835364232, "aspect": "sextile", "planet": "True_Node"}, {"orb": 0.15931900055585402, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 0.15931900055585402, "aspect": "trine", "planet": "Lilith"}], "longitude": 212.11566168530192, "conjunctions": [], "interpretation": "Отец в 4 доме: отношения с отцом"}, "Genius": {"sign": "Leo", "house": 2, "aspects": [{"orb": 2.316008772753122, "aspect": "sextile", "planet": "Sun"}, {"orb": 4.953767476629764, "aspect": "sextile", "planet": "Moon"}, {"orb": 3.2659915226848852, "aspect": "square", "planet": "Mercury"}, {"orb": 2.405210253105679, "aspect": "sextile", "planet": "Uranus"}, {"orb": 2.623805654666853, "aspect": "trine", "planet": "Chiron"}], "longitude": 141.02265806185585, "conjunctions": [], "interpretation": "Genius в 2 доме"}, "Mother": {"sign": "Scorpio", "house": 5, "aspects": [{"orb": 3.1384039955062235, "aspect": "sextile", "planet": "Jupiter"}], "longitude": 239.69755142905905, "conjunctions": [], "interpretation": "Мать в 5 доме: отношения с матерью"}, "Reason": {"sign": "Sagittarius", "house": 5, "aspects": [{"orb": 4.864565996277207, "aspect": "sextile", "planet": "Sun"}, {"orb": 4.953767476629764, "aspect": "sextile", "planet": "Uranus"}, {"orb": 0.07524843114276791, "aspect": "trine", "planet": "Chiron"}], "longitude": 258.47410083833176, "conjunctions": [], "interpretation": "Reason в 5 доме"}, "Spirit": {"sign": "Scorpio", "house": 5, "aspects": [], "longitude": 234.0561011337698, "conjunctions": [], "interpretation": "Дух в 5 доме: духовный рост через сферу дома"}, "Travel": {"sign": "Pisces", "house": 9, "aspects": [{"orb": 4.921156556025807, "aspect": "square", "planet": "Venus"}, {"orb": 0.7874363896094678, "aspect": "sextile", "planet": "Mars"}, {"orb": 1.2000306654524024, "aspect": "trine", "planet": "Saturn"}, {"orb": 2.082004729943293, "aspect": "square", "planet": "Neptune"}, {"orb": 2.5933770219606345, "aspect": "sextile", "planet": "True_Node"}, {"orb": 1.5970470389800653, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 1.5970470389800653, "aspect": "trine", "planet": "Lilith"}], "longitude": 333.5533897237261, "conjunctions": [], "interpretation": "Travel в 9 доме"}, "Wisdom": {"sign": "Libra", "house": 4, "aspects": [{"orb": 3.298602443288843, "aspect": "sextile", "planet": "Venus"}], "longitude": 191.77314872304078, "conjunctions": [], "interpretation": "Wisdom в 4 доме"}, "Courage": {"sign": "Capricorn", "house": 6, "aspects": [{"orb": 4.478647127359864, "aspect": "sextile", "planet": "Mercury"}], "longitude": 283.2780194118111, "conjunctions": [], "interpretation": "Courage в 6 доме"}, "Destiny": {"sign": "Aries", "house": 10, "aspects": [{"orb": 0.36593288753590514, "aspect": "trine", "planet": "Venus"}, {"orb": 3.355193003037485, "aspect": "square", "planet": "Saturn"}, {"orb": 2.4732189385466086, "aspect": "trine", "planet": "Neptune"}, {"orb": 3.0933222273788203, "aspect": "opposition", "planet": "Pluto"}], "longitude": 8.108613392216029, "conjunctions": [], "interpretation": "Destiny в 10 доме"}, "Fortune": {"sign": "Pisces", "house": 10, "aspects": [{"orb": 3.3551930030374706, "aspect": "square", "planet": "Moon"}, {"orb": 3.5043368830421855, "aspect": "sextile", "planet": "Jupiter"}, {"orb": 1.628394160242408, "aspect": "square", "planet": "True_Node"}, {"orb": 2.624724143222977, "aspect": "square", "planet": "Mean_Node"}, {"orb": 2.624724143222977, "aspect": "square", "planet": "Lilith"}], "longitude": 359.3316185415231, "conjunctions": [], "interpretation": "Фортуна в 10 доме: удача через сферу дома"}, "Freedom": {"sign": "Scorpio", "house": 5, "aspects": [{"orb": 2.388358775741551, "aspect": "conjunction", "planet": "Mercury"}], "longitude": 225.3683077634294, "conjunctions": [{"orb": 2.388358775741551, "house": 5, "planet": "Mercury"}], "interpretation": "Freedom в 5 доме. Соединение с Mercury усиливает влияние"}, "Healing": {"sign": "Taurus", "house": 11, "aspects": [{"orb": 1.3596201671788606, "aspect": "opposition", "planet": "Mercury"}], "longitude": 49.116286706349825, "conjunctions": [], "interpretation": "Healing в 11 доме"}, "Passion": {"sign": "Sagittarius", "house": 6, "aspects": [{"orb": 0.7785271633788682, "aspect": "sextile", "planet": "Sun"}, {"orb": 3.4162858672555103, "aspect": "opposition", "planet": "Moon"}, {"orb": 0.8677286437314251, "aspect": "sextile", "planet": "Uranus"}, {"orb": 4.161287264041107, "aspect": "trine", "planet": "Chiron"}], "longitude": 262.5601396712301, "conjunctions": [], "interpretation": "Страсть в 6 доме: творческая энергия"}, "Science": {"sign": "Sagittarius", "house": 5, "aspects": [{"orb": 1.2225597078869157, "aspect": "conjunction", "planet": "Venus"}, {"orb": 4.061711533969429, "aspect": "conjunction", "planet": "Neptune"}, {"orb": 4.681814822801641, "aspect": "sextile", "planet": "Pluto"}], "longitude": 249.69710598763885, "conjunctions": [{"orb": 1.2225597078869157, "house": 5, "planet": "Venus"}], "interpretation": "Science в 5 доме. Соединение с Venus усиливает влияние"}, "Secrets": {"sign": "Gemini", "house": 11, "aspects": [{"orb": 4.446367943876339, "aspect": "sextile", "planet": "Chiron"}], "longitude": 73.95248446331266, "conjunctions": [], "interpretation": "Secrets в 11 доме"}, "Service": {"sign": "Pisces", "house": 9, "aspects": [{"orb": 3.56092744279087, "aspect": "square", "planet": "Venus"}, {"orb": 0.5727927236254686, "aspect": "sextile", "planet": "Mars"}, {"orb": 0.160198447782534, "aspect": "trine", "planet": "Saturn"}, {"orb": 0.7217756167083564, "aspect": "square", "planet": "Neptune"}, {"orb": 3.953606135195571, "aspect": "sextile", "planet": "True_Node"}, {"orb": 2.9572761522150017, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 2.9572761522150017, "aspect": "trine", "planet": "Lilith"}], "longitude": 334.91361883696106, "conjunctions": [], "interpretation": "Service в 9 доме"}, "Victory": {"sign": "Aquarius", "house": 8, "aspects": [{"orb": 1.4377280384242397, "aspect": "trine", "planet": "Sun"}, {"orb": 1.2000306654524024, "aspect": "trine", "planet": "Moon"}, {"orb": 1.3485265580716828, "aspect": "trine", "planet": "Uranus"}], "longitude": 324.7763948730332, "conjunctions": [], "interpretation": "Победа в 8 доме: достижения"}, "Children": {"sign": "Virgo", "house": 3, "aspects": [{"orb": 4.921156556025807, "aspect": "square", "planet": "Moon"}, {"orb": 3.298602443288843, "aspect": "sextile", "planet": "Mercury"}], "longitude": 171.0552689824598, "conjunctions": [], "interpretation": "Дети в 3 доме: творчество"}, "Commerce": {"sign": "Leo", "house": 2, "aspects": [{"orb": 2.226807292400565, "aspect": "sextile", "planet": "Sun"}, {"orb": 4.864565996277207, "aspect": "sextile", "planet": "Moon"}, {"orb": 3.355193003037442, "aspect": "square", "planet": "Mercury"}, {"orb": 2.316008772753122, "aspect": "sextile", "planet": "Uranus"}, {"orb": 2.71300713501941, "aspect": "trine", "planet": "Chiron"}], "longitude": 141.1118595422084, "conjunctions": [], "interpretation": "Бизнес в 2 доме: успех в делах"}, "Illusion": {"sign": "Leo", "house": 2, "aspects": [{"orb": 3.184078787026067, "aspect": "square", "planet": "Mercury"}, {"orb": 3.826264655044099, "aspect": "trine", "planet": "Chiron"}], "longitude": 134.5725877521449, "conjunctions": [], "interpretation": "Illusion в 2 доме"}, "Learning": {"sign": "Taurus", "house": 11, "aspects": [], "longitude": 41.61457095225211, "conjunctions": [], "interpretation": "Learning в 11 доме"}, "Marriage": {"sign": "Capricorn", "house": 6, "aspects": [{"orb": 4.438560189734233, "aspect": "opposition", "planet": "Moon"}, {"orb": 3.9258403851157766, "aspect": "trine", "planet": "Mars"}, {"orb": 4.338434660958683, "aspect": "opposition", "planet": "Saturn"}, {"orb": 4.6003054366173615, "aspect": "square", "planet": "Pluto"}, {"orb": 0.5450269735456459, "aspect": "conjunction", "planet": "True_Node"}, {"orb": 1.541356956526215, "aspect": "conjunction", "planet": "Mean_Node"}, {"orb": 1.541356956526215, "aspect": "opposition", "planet": "Lilith"}], "longitude": 270.41498572821985, "conjunctions": [{"orb": 0.5450269735456459, "house": 6, "planet": "True_Node"}, {"orb": 1.541356956526215, "house": 6, "planet": "Mean_Node"}], "interpretation": "Брак в 6 доме: партнерство. Соединение с True_Node, Mean_Node усиливает влияние"}, "Sickness": {"sign": "Taurus", "house": 11, "aspects": [], "longitude": 56.28126556180352, "conjunctions": [], "interpretation": "Здоровье в 11 доме: болезни"}, "Teaching": {"sign": "Aquarius", "house": 8, "aspects": [{"orb": 1.4377280384242397, "aspect": "trine", "planet": "Sun"}, {"orb": 1.2000306654524024, "aspect": "trine", "planet": "Moon"}, {"orb": 1.3485265580716828, "aspect": "trine", "planet": "Uranus"}], "longitude": 324.7763948730332, "conjunctions": [], "interpretation": "Teaching в 8 доме"}, "Abundance": {"sign": "Virgo", "house": 3, "aspects": [{"orb": 4.921156556025807, "aspect": "square", "planet": "Moon"}, {"orb": 3.298602443288843, "aspect": "sextile", "planet": "Mercury"}], "longitude": 171.0552689824598, "conjunctions": [], "interpretation": "Abundance в 3 доме"}, "Intuition": {"sign": "Pisces", "house": 9, "aspects": [{"orb": 3.56092744279087, "aspect": "square", "planet": "Venus"}, {"orb": 0.5727927236254686, "aspect": "sextile", "planet": "Mars"}, {"orb": 0.160198447782534, "aspect": "trine", "planet": "Saturn"}, {"orb": 0.7217756167083564, "aspect": "square", "planet": "Neptune"}, {"orb": 3.953606135195571, "aspect": "sextile", "planet": "True_Node"}, {"orb": 2.9572761522150017, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 2.9572761522150017, "aspect": "trine", "planet": "Lilith"}], "longitude": 334.91361883696106, "conjunctions": [], "interpretation": "Intuition в 9 доме"}, "Necessity": {"sign": "Aries", "house": 10, "aspects": [{"orb": 0.36593288753590514, "aspect": "trine", "planet": "Venus"}, {"orb": 3.355193003037485, "aspect": "square", "planet": "Saturn"}, {"orb": 2.4732189385466086, "aspect": "trine", "planet": "Neptune"}, {"orb": 3.0933222273788203, "aspect": "opposition", "planet": "Pluto"}], "longitude": 8.108613392216029, "conjunctions": [], "interpretation": "Necessity в 10 доме"}, "Stability": {"sign": "Leo", "house": 1, "aspects": [{"orb": 3.0036915914125473, "aspect": "trine", "planet": "Venus"}, {"orb": 1.130028575003763, "aspect": "square", "planet": "Mars"}, {"orb": 2.634899263774116, "aspect": "opposition", "planet": "Jupiter"}, {"orb": 0.16453976533003356, "aspect": "trine", "planet": "Neptune"}, {"orb": 0.4555635235021782, "aspect": "sextile", "planet": "Pluto"}], "longitude": 125.47085468833939, "conjunctions": [], "interpretation": "Stability в 1 доме"}, "Creativity": {"sign": "Pisces", "house": 9, "aspects": [{"orb": 4.851154465577167, "aspect": "trine", "planet": "Moon"}, {"orb": 3.5132461092728136, "aspect": "sextile", "planet": "Mars"}, {"orb": 3.925840385115748, "aspect": "trine", "planet": "Saturn"}, {"orb": 4.807814449606639, "aspect": "square", "planet": "Neptune"}, {"orb": 0.13243269770271127, "aspect": "sextile", "planet": "True_Node"}, {"orb": 1.1287626806832805, "aspect": "sextile", "planet": "Mean_Node"}, {"orb": 1.1287626806832805, "aspect": "trine", "planet": "Lilith"}], "longitude": 330.8275800040628, "conjunctions": [], "interpretation": "Creativity в 9 доме"}, "Discipline": {"sign": "Virgo", "house": 4, "aspects": [{"orb": 1.130028575003763, "aspect": "square", "planet": "Moon"}, {"orb": 3.8535585882761154, "aspect": "square", "planet": "True_Node"}, {"orb": 4.849888571256685, "aspect": "square", "planet": "Mean_Node"}, {"orb": 4.849888571256685, "aspect": "square", "planet": "Lilith"}], "longitude": 177.10645411348938, "conjunctions": [], "interpretation": "Discipline в 4 доме"}, "Friendship": {"sign": "Aquarius", "house": 8, "aspects": [{"orb": 3.5609274427908417, "aspect": "square", "planet": "Mercury"}, {"orb": 4.203113310808874, "aspect": "sextile", "planet": "Chiron"}], "longitude": 314.1957390963801, "conjunctions": [], "interpretation": "Friendship в 8 доме"}, "Leadership": {"sign": "Scorpio", "house": 5, "aspects": [{"orb": 2.4775602560940797, "aspect": "conjunction", "planet": "Mercury"}], "longitude": 225.27910628307689, "conjunctions": [{"orb": 2.4775602560940797, "house": 5, "planet": "Mercury"}], "interpretation": "Leadership в 5 доме. Соединение с Mercury усиливает влияние"}, "Inspiration": {"sign": "Cancer", "house": 12, "aspects": [{"orb": 0.5160411769549569, "aspect": "square", "planet": "Sun"}, {"orb": 0.42683969660239995, "aspect": "square", "planet": "Uranus"}], "longitude": 113.85470801156393, "conjunctions": [], "interpretation": "Inspiration в 12 доме"}, "Imprisonment": {"sign": "Virgo", "house": 4, "aspects": [{"orb": 1.130028575003763, "aspect": "square", "planet": "Moon"}, {"orb": 3.8535585882761154, "aspect": "square", "planet": "True_Node"}, {"orb": 4.849888571256685, "aspect": "square", "planet": "Mean_Node"}, {"orb": 4.849888571256685, "aspect": "square", "planet": "Lilith"}], "longitude": 177.10645411348938, "conjunctions": [], "interpretation": "Imprisonment в 4 доме"}, "Communication": {"sign": "Cancer", "house": 12, "aspects": [{"orb": 1.635153983729829, "aspect": "sextile", "planet": "Mars"}, {"orb": 1.2225597078869015, "aspect": "conjunction", "planet": "Saturn"}, {"orb": 0.960688932228237, "aspect": "square", "planet": "Pluto"}, {"orb": 4.019637412319383, "aspect": "opposition", "planet": "Mean_Node"}, {"orb": 4.019637412319383, "aspect": "conjunction", "planet": "Lilith"}], "longitude": 95.97598009706545, "conjunctions": [{"orb": 1.2225597078869015, "house": 12, "planet": "Saturn"}], "interpretation": "Communication в 12 доме. Соединение с Saturn усиливает влияние"}}	{"include_all": true, "profile_city": "Kaliningrad", "include_heavy": true, "patterns_count": 14, "profile_region": null, "calculation_time_ms": 110, "aspect_qualities_count": 43, "arabic_connections_count": 51, "star_interpretations_count": 3}	Tuesday	Mars	{"has_yod": true, "moon_phase": 242.6378, "has_t_square": true, "total_planets": 14, "avg_aspect_orb": 2.3109, "aspect_patterns": {"other": 14, "trine": 5, "square": 5, "sextile": 5, "opposition": 8, "conjunction": 6}, "element_balance": {"air": 5, "fire": 3, "earth": 3, "water": 3}, "has_grand_trine": true, "moon_phase_name": "last_quarter", "planet_strengths": {"Sun": 0.3, "Mars": 0.44999999999999996, "Moon": 0.5, "Pluto": 0.6, "Venus": 0.7, "Chiron": 0.44999999999999996, "Lilith": 0.44999999999999996, "Saturn": 0.1, "Uranus": 0.6, "Jupiter": 0.6, "Mercury": 0.9, "Neptune": 0.6, "Mean_Node": 0.44999999999999996, "True_Node": 0.44999999999999996}, "retrograde_count": 5, "avg_dignity_score": -0.07, "fixed_stars_count": 14, "sign_distribution": {"Leo": 0, "Aries": 1, "Libra": 3, "Virgo": 0, "Cancer": 2, "Gemini": 1, "Pisces": 0, "Taurus": 1, "Scorpio": 1, "Aquarius": 1, "Capricorn": 2, "Sagittarius": 2}, "house_distribution": {"1": 0, "2": 0, "3": 0, "4": 3, "5": 3, "6": 2, "7": 1, "8": 0, "9": 0, "10": 2, "11": 0, "12": 3}, "retrograde_planets": ["Mars", "True_Node", "Mean_Node", "Chiron", "Lilith"], "avg_planet_strength": 0.5107, "active_patterns_count": 8, "aspect_qualities_count": 43, "critical_degrees_count": 2, "has_void_of_course_moon": true}	P	success	\N	2026-09-05 15:18:27.100652+00	2026-09-05 15:18:27.100652+00
\.


--
-- Data for Name: optimal_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optimal_activities (id, user_id, calculation_date, activity_indices, activity_types, activity_scores, confidence_scores, recommendations, time_slots, priority_order, energy_level, energy_trend, focus_areas, ml_features, feature_vector, model_version, is_generated, is_approved, user_feedback, generated_at, updated_at) FROM stdin;
1	1	2026-09-05	{1,2,4,6}	{}	{0.374022,0.5,0.5,0.396995,0.5,0.5,0.5}	{}	{}	{}	{}	0.4673	\N	{}	{"empathy": 0.3101, "has_yod": 1.0, "iq_base": 0.9021, "stamina": 0.1109, "vitality": 0.2315, "has_spica": 1.0, "luck_base": 0.9379, "work_ethic": 0.1065, "chronic_risk": 0.253, "extroversion": 0.6457, "big5_openness": 0.8946, "follow_through": 0.0108, "learning_speed": 0.6366, "predictability": 0.9869, "drive_intensity": 0.0642, "big5_neuroticism": 0.7575, "system_stability": 0.7394, "talent_magnitude": 0.8871, "big5_extraversion": 0.6457, "blueprint_empathy": 0.3101, "destiny_intensity": 0.9998, "big5_agreeableness": 0.52855, "blueprint_creative": 0.6389, "blueprint_diplomacy": 0.5989, "blueprint_practical": 0.4927, "blueprint_stability": 0.2425, "emotional_stability": 0.2425, "intuition_luck_corr": -0.167, "blueprint_analytical": 0.8521, "blueprint_leadership": 0.0599, "blueprint_resilience": 0.1899, "intuition_reliability": 0.9541, "big5_conscientiousness": 0.05865, "blueprint_extroversion": 0.6457, "transformative_potential": 0.322, "blueprint_integrity_index": 0.0529, "blueprint_openness_balance": 0.7857, "blueprint_authenticity_level": 0.1868, "blueprint_dependability_score": 0.0587}	{0.52855,0.05865,0.6457,0.7575,0.8946,0.8521,0.1868,0.6389,0.0587,0.5989,0.3101,0.6457,0.0529,0.0599,0.7857,0.4927,0.1899,0.2425,0.253,0.9998,0.0642,0.2425,0.3101,0.6457,0.0108,1,1,-0.167,0.9541,0.9021,0.6366,0.9379,0.9869,0.1109,0.7394,0.8871,0.322,0.2315,0.1065,0.374022,0.5,0.5,0.396995,0.5,0.5,0.5,0,1,1,0,1,0,1,39,0.467288,0.5,0.374022}	ml_1.0	t	f	\N	2026-09-05 15:18:30.425123+00	2026-09-05 15:18:30.425123+00
\.


--
-- Data for Name: profile_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profile_snapshots (id, user_id, snapshot_date, axes, ml_features, created_at) FROM stdin;
\.


--
-- Data for Name: psychological_tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychological_tests (id, user_id, test_type, test_version, test_name, questions, answers, raw_responses, scores, profile_type, interpretation, insights, completion_percentage, time_spent_seconds, device_info, status, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: psyho_matrices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psyho_matrices (user_id, first_number, second_number, third_number, fourth_number, matrix_digits, matrix_3x3, characteristics, talent_codes, strength_codes, energy_level, life_purpose, compatibility_hints, additional, karmic_analysis, forecasting, calculation_version, created_at, updated_at, calculated_at) FROM stdin;
1	28	10	26	8	{"1": 4, "2": 2, "3": 1, "4": 0, "5": 0, "6": 2, "7": 1, "8": 2, "9": 1}	[[4, 2, 1], [0, 0, 2], [1, 2, 1]]	{"duty": "Strong sense of duty, commitment", "luck": "Luck in small things, favorable opportunities", "labor": "Master of craft, perfectionism", "logic": "Intuitive thinking, creativity", "energy": "High energy, activity", "health": "Attention to health, prevention", "memory": "Good memory, learning ability", "indices": {"duty_index": 20, "luck_index": 18, "labor_index": 20, "logic_index": 0, "energy_index": 20, "health_index": 0, "memory_index": 10, "purpose_index": 60, "interest_index": 12, "development_index": 48.15}, "interest": "Diverse interests", "character": "Transformational character, powerful will", "duty_count": 2, "duty_score": 70, "luck_count": 1, "luck_score": 40, "positional": {"center": 0, "corners": 7, "row_strength": [7, 2, 4], "anti_diagonal": 2, "balance_score": 70, "main_diagonal": 5, "column_strength": [5, 4, 4]}, "labor_count": 2, "labor_score": 70, "logic_count": 0, "logic_score": 10, "energy_count": 2, "energy_score": 70, "health_count": 0, "health_score": 10, "memory_count": 1, "memory_score": 40, "interest_count": 1, "interest_score": 40, "character_count": 4, "character_score": 100, "matrix_analysis": {"density": 77.78, "is_dense": true, "is_sparse": false, "empty_cells": [4, 5], "filled_cells": [1, 2, 3, 6, 7, 8, 9], "total_digits": 13, "unique_digits": 7, "dominant_count": 4, "dominant_digit": "1"}}	{MASTER_TALENT_CHARACTER,TALENT_CHARACTER,TALENT_DUTY,TALENT_ENERGY,TALENT_ENERGY_CREATIVE,TALENT_HOLISTIC_THINKING,TALENT_LABOR,TALENT_LEADERSHIP_MANAGEMENT,TALENT_ROW_1_STRENGTH,TALENT_ROW_3_STRENGTH,TALENT_SYSTEMIC_VISION}	{MASTER_STRENGTH_CHARACTER,STRENGTH_CHARACTER,STRENGTH_DUTY,STRENGTH_ENERGY,STRENGTH_ENERGY_CREATIVE,STRENGTH_LABOR,STRENGTH_LEADERSHIP_MANAGEMENT}	medium	Material achievement - managing finances, resources, power	{"partner_types": [], "ideal_partners": ["Managers", "Financiers"], "recommendations": ["Learn compromise and flexibility in relationships", "Develop stability and patience"], "compatible_numbers": [1, 2, 3], "relationship_score": 85, "challenging_numbers": [1, 4], "energy_compatibility": "high", "communication_compatibility": "medium"}	{"challenges": [{"challenge_area": "health", "challenge_number": 4, "challenge_description": "Build stability and discipline"}, {"challenge_area": "logic", "challenge_number": 5, "challenge_description": "Embrace change and freedom"}], "life_peaks": [{"period": "0-27 years", "description": "Early peak: Power and achievement", "peak_number": 8}, {"period": "28-55 years", "description": "Middle peak: Completion and transformation", "peak_number": 9}, {"period": "56-83 years", "description": "Late peak: Power and achievement", "peak_number": 8}, {"period": "84+ years", "description": "Final peak: Creativity and expression", "peak_number": 3}], "soul_number": 7, "destiny_number": 1, "maturity_number": 9, "personality_number": 26, "karmic_number_present": false, "master_number_present": false}	{"soul_age": "Young soul (8-13)", "past_lives": {"archetype": "Diplomat, partner, mediator", "experience_level": "Old soul, wisdom keeper", "past_life_number": 2}, "karmic_debt": [], "karmic_tasks": [{"task": "Strengthen interest", "type": "strengthening", "digit": 3, "priority": "medium"}, {"task": "Develop health", "type": "development", "digit": 4, "priority": "high"}, {"task": "Develop logic", "type": "development", "digit": 5, "priority": "high"}, {"task": "Strengthen luck", "type": "strengthening", "digit": 7, "priority": "medium"}, {"task": "Strengthen memory", "type": "strengthening", "digit": 9, "priority": "medium"}], "karmic_maturity": 65}	{"growth_areas": [{"area": "interest", "digit": 3, "potential": "Strengthening", "suggestion": "Practice and reinforce interest"}, {"area": "health", "digit": 4, "potential": "To be developed", "suggestion": "Focus on developing health"}, {"area": "logic", "digit": 5, "potential": "To be developed", "suggestion": "Focus on developing logic"}, {"area": "luck", "digit": 7, "potential": "Strengthening", "suggestion": "Practice and reinforce luck"}, {"area": "memory", "digit": 9, "potential": "Strengthening", "suggestion": "Practice and reinforce memory"}], "current_cycle": {"focus": "Material achievement - managing finances, resources, power", "duration": "9 years", "cycle_name": "Cycle of Power and Achievement", "cycle_number": 8}, "personal_years": [{"year": 2024, "description": "Completion, release, transformation", "personal_year": 9}, {"year": 2025, "description": "New beginnings, opportunities, independence", "personal_year": 1}, {"year": 2026, "description": "Growth and learning", "personal_year": 11}, {"year": 2027, "description": "Creativity, socializing, expression", "personal_year": 3}, {"year": 2028, "description": "Work, building foundations, discipline", "personal_year": 4}], "recommendations": ["Develop missing qualities: health, logic", "Strengthen developing qualities: interest, luck, memory", "Balance overused qualities: character"], "favorable_periods": [{"area": "Career and leadership", "advice": "Take initiative, start new projects", "favorable": true}, {"area": "Relationships and partnerships", "advice": "Build connections, collaborate", "favorable": true}]}	3.1	2026-09-05 15:18:26.329505+00	2026-09-05 15:18:26.329505+00	2026-09-05 15:18:26.329505+00
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommendations (id, user_id, calculation_date, title, content, summary, category, priority, relevance_score, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_audit_log (id, action_type, action_name, resource_type, resource_id, user_id, user_ip, user_agent, session_id, request_data, response_data, error_details, stack_trace, status_code, success, error_code, duration_ms, memory_usage_kb, service_name, endpoint, http_method, created_at) FROM stdin;
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_metrics (id, metric_name, metric_type, metric_value, metric_labels, service_name, hostname, collected_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_profiles (user_id, full_name, username, language_code, timezone, birth_country_code, system_language, birth_timezone, birth_date, birth_time, birth_region, birth_city, birth_country, birth_lat, birth_lng, profession, job_position, geocoder_query, geocoder_full_name, geocoder_source, current_city, current_lat, current_lng, notification_enabled, daily_recommendations_enabled, created_at, updated_at) FROM stdin;
1	\N	\N	ru	Europe/Moscow	RU	ru	Europe/Kaliningrad	1973-10-16	23:42:00	\N	Kaliningrad	Russia	54.710400	20.507000	worker	\N	Kaliningrad	Kaliningrad	nominatim	\N	\N	\N	t	t	2026-09-05 15:17:48.222929+00	2026-09-05 15:18:25.925663+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, telegram_id, max_id, udemy_id, google_id, apple_id, yandex_id, phone_hash, email_hash, password_hash, yandex_refresh_token, yandex_access_token, yandex_token_expires_at, yandex_email, yandex_login, primary_auth_method, status, is_verified, is_premium, privacy_level, created_at, updated_at, last_activity_at, premium_until) FROM stdin;
1	\N	\N	\N	\N	\N	2400511387	\N	cc272e1ca3534652ce2ebd9e6df2a793c3bcda31b169e941885f5570c5ec3ca4	\N	\N	y0__wgBEJvL0_gIGNn1RCChqtulGDDv94GPCH6l9JrIqsIxEmbpD6knRJqKRlxf	2026-09-05 16:17:48.064301+00	dailytuner@yandex.ru	dailytuner	yandex	active	t	f	standard	2026-09-05 15:17:48.222929+00	2026-09-05 15:17:48.222929+00	2026-09-05 15:17:48.222929+00	\N
\.


--
-- Name: astro_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.astro_events_id_seq', 1, false);


--
-- Name: biorhythms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.biorhythms_id_seq', 1, true);


--
-- Name: calculation_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calculation_cache_id_seq', 1, false);


--
-- Name: daily_forecast_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.daily_forecast_cache_id_seq', 2, true);


--
-- Name: forecast_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.forecast_feedback_id_seq', 1, false);


--
-- Name: magic_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.magic_profiles_id_seq', 1, true);


--
-- Name: ml_model_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ml_model_metrics_id_seq', 1, false);


--
-- Name: natal_charts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.natal_charts_id_seq', 1, true);


--
-- Name: optimal_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optimal_activities_id_seq', 1, true);


--
-- Name: profile_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.profile_snapshots_id_seq', 1, false);


--
-- Name: psychological_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.psychological_tests_id_seq', 1, false);


--
-- Name: recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recommendations_id_seq', 1, false);


--
-- Name: system_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_audit_log_id_seq', 1, false);


--
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: astro_events astro_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.astro_events
    ADD CONSTRAINT astro_events_pkey PRIMARY KEY (id);


--
-- Name: biorhythms biorhythms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms
    ADD CONSTRAINT biorhythms_pkey PRIMARY KEY (id);


--
-- Name: biorhythms biorhythms_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms
    ADD CONSTRAINT biorhythms_user_id_key UNIQUE (user_id);


--
-- Name: calculation_cache calculation_cache_cache_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache
    ADD CONSTRAINT calculation_cache_cache_key_key UNIQUE (cache_key);


--
-- Name: calculation_cache calculation_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache
    ADD CONSTRAINT calculation_cache_pkey PRIMARY KEY (id);


--
-- Name: daily_forecast_cache daily_forecast_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache
    ADD CONSTRAINT daily_forecast_cache_pkey PRIMARY KEY (id);


--
-- Name: daily_forecast_cache daily_forecast_cache_user_id_forecast_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache
    ADD CONSTRAINT daily_forecast_cache_user_id_forecast_date_key UNIQUE (user_id, forecast_date);


--
-- Name: forecast_feedback forecast_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forecast_feedback
    ADD CONSTRAINT forecast_feedback_pkey PRIMARY KEY (id);


--
-- Name: magic_profiles magic_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles
    ADD CONSTRAINT magic_profiles_pkey PRIMARY KEY (id);


--
-- Name: magic_profiles magic_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles
    ADD CONSTRAINT magic_profiles_user_id_key UNIQUE (user_id);


--
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- Name: natal_charts natal_charts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.natal_charts
    ADD CONSTRAINT natal_charts_pkey PRIMARY KEY (id);


--
-- Name: optimal_activities optimal_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities
    ADD CONSTRAINT optimal_activities_pkey PRIMARY KEY (id);


--
-- Name: optimal_activities optimal_activities_user_id_calculation_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities
    ADD CONSTRAINT optimal_activities_user_id_calculation_date_key UNIQUE (user_id, calculation_date);


--
-- Name: profile_snapshots profile_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_snapshots
    ADD CONSTRAINT profile_snapshots_pkey PRIMARY KEY (id);


--
-- Name: psychological_tests psychological_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests
    ADD CONSTRAINT psychological_tests_pkey PRIMARY KEY (id);


--
-- Name: psychological_tests psychological_tests_user_id_test_type_test_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests
    ADD CONSTRAINT psychological_tests_user_id_test_type_test_version_key UNIQUE (user_id, test_type, test_version);


--
-- Name: psyho_matrices psyho_matrices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psyho_matrices
    ADD CONSTRAINT psyho_matrices_pkey PRIMARY KEY (user_id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_user_id_calculation_date_category_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_calculation_date_category_key UNIQUE (user_id, calculation_date, category);


--
-- Name: system_audit_log system_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_audit_log
    ADD CONSTRAINT system_audit_log_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: users users_apple_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_apple_id_key UNIQUE (apple_id);


--
-- Name: users users_google_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_google_id_key UNIQUE (google_id);


--
-- Name: users users_max_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_max_id_key UNIQUE (max_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: users users_udemy_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_udemy_id_key UNIQUE (udemy_id);


--
-- Name: users users_yandex_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_yandex_id_key UNIQUE (yandex_id);


--
-- Name: idx_activities_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activities_user_date ON public.optimal_activities USING btree (user_id, calculation_date DESC);


--
-- Name: idx_astro_events_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_astro_events_date ON public.astro_events USING btree (event_date);


--
-- Name: idx_astro_events_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_astro_events_type ON public.astro_events USING btree (event_type);


--
-- Name: idx_audit_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_date ON public.system_audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_user ON public.system_audit_log USING btree (user_id);


--
-- Name: idx_biorhythms_profile_data_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_profile_data_gin ON public.biorhythms USING gin (profile_data);


--
-- Name: idx_biorhythms_profile_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_profile_date ON public.biorhythms USING btree (profile_calculated_at);


--
-- Name: idx_biorhythms_stability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_stability ON public.biorhythms USING btree (system_stability);


--
-- Name: idx_biorhythms_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_biorhythms_user ON public.biorhythms USING btree (user_id);


--
-- Name: idx_cache_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cache_expires ON public.calculation_cache USING btree (expires_at) WHERE (is_valid = true);


--
-- Name: idx_cache_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cache_key ON public.calculation_cache USING btree (cache_key);


--
-- Name: idx_daily_cache_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_cache_date ON public.daily_forecast_cache USING btree (user_id, forecast_date);


--
-- Name: idx_daily_forecast_cache_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_forecast_cache_user_date ON public.daily_forecast_cache USING btree (user_id, forecast_date);


--
-- Name: idx_feedback_accuracy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feedback_accuracy ON public.forecast_feedback USING btree (delta) WHERE (delta IS NOT NULL);


--
-- Name: idx_feedback_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feedback_user_date ON public.forecast_feedback USING btree (user_id, forecast_date);


--
-- Name: idx_magic_axes_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_axes_gin ON public.magic_profiles USING gin (axes);


--
-- Name: idx_magic_blueprint_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_blueprint_gin ON public.magic_profiles USING gin (psychological_blueprint);


--
-- Name: idx_magic_cluster_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_cluster_id ON public.magic_profiles USING btree (cluster_id);


--
-- Name: idx_magic_confidence; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_confidence ON public.magic_profiles USING btree (confidence_score);


--
-- Name: idx_magic_errors_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_errors_gin ON public.magic_profiles USING gin (validation_errors);


--
-- Name: idx_magic_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_metadata_gin ON public.magic_profiles USING gin (calculation_metadata);


--
-- Name: idx_magic_ml_features_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_ml_features_gin ON public.magic_profiles USING gin (ml_features);


--
-- Name: idx_magic_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_magic_user_id ON public.magic_profiles USING btree (user_id);


--
-- Name: idx_magic_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_magic_version ON public.magic_profiles USING btree (profile_version);


--
-- Name: idx_metrics_name_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_metrics_name_date ON public.system_metrics USING btree (metric_name, collected_at DESC);


--
-- Name: idx_ml_metrics_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ml_metrics_model ON public.ml_model_metrics USING btree (model_name, "timestamp" DESC);


--
-- Name: idx_natal_arabic_connections_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_arabic_connections_gin ON public.natal_charts USING gin (arabic_connections);


--
-- Name: idx_natal_arabic_parts_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_arabic_parts_gin ON public.natal_charts USING gin (arabic_parts);


--
-- Name: idx_natal_aspect_qualities_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_aspect_qualities_gin ON public.natal_charts USING gin (aspect_qualities);


--
-- Name: idx_natal_critical_degrees_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_critical_degrees_gin ON public.natal_charts USING gin (critical_degrees);


--
-- Name: idx_natal_dasha_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_dasha_current ON public.natal_charts USING btree (((dasha ->> 'planet'::text)));


--
-- Name: idx_natal_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_date ON public.natal_charts USING btree (calculation_date);


--
-- Name: idx_natal_julian_day; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_julian_day ON public.natal_charts USING btree (julian_day);


--
-- Name: idx_natal_midpoints_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_midpoints_gin ON public.natal_charts USING gin (midpoints);


--
-- Name: idx_natal_ml_features_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_ml_features_gin ON public.natal_charts USING gin (ml_features);


--
-- Name: idx_natal_moon_data_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_moon_data_gin ON public.natal_charts USING gin (moon_data);


--
-- Name: idx_natal_nakshatra; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_nakshatra ON public.natal_charts USING btree (((panchanga ->> 'nakshatra_name'::text)));


--
-- Name: idx_natal_panchanga_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_panchanga_gin ON public.natal_charts USING gin (panchanga);


--
-- Name: idx_natal_patterns_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_patterns_gin ON public.natal_charts USING gin (patterns);


--
-- Name: idx_natal_planets_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_planets_gin ON public.natal_charts USING gin (planets);


--
-- Name: idx_natal_solar_data_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_solar_data_gin ON public.natal_charts USING gin (solar_data);


--
-- Name: idx_natal_star_interpretations_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_star_interpretations_gin ON public.natal_charts USING gin (star_interpretations);


--
-- Name: idx_natal_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_user_date ON public.natal_charts USING btree (user_id, calculation_date DESC);


--
-- Name: idx_natal_weekday; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_natal_weekday ON public.natal_charts USING btree (weekday);


--
-- Name: idx_profiles_birth_city_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_birth_city_trgm ON public.user_profiles USING gin (birth_city public.gin_trgm_ops);


--
-- Name: idx_profiles_birth_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_birth_date ON public.user_profiles USING btree (birth_date);


--
-- Name: idx_profiles_birth_region_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_birth_region_trgm ON public.user_profiles USING gin (birth_region public.gin_trgm_ops);


--
-- Name: idx_psyho_matrices_3x3_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_3x3_gin ON public.psyho_matrices USING gin (matrix_3x3);


--
-- Name: idx_psyho_matrices_additional_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_additional_gin ON public.psyho_matrices USING gin (additional);


--
-- Name: idx_psyho_matrices_characteristics_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_characteristics_gin ON public.psyho_matrices USING gin (characteristics);


--
-- Name: idx_psyho_matrices_digits_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_digits_gin ON public.psyho_matrices USING gin (matrix_digits);


--
-- Name: idx_psyho_matrices_energy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_energy ON public.psyho_matrices USING btree (energy_level);


--
-- Name: idx_psyho_matrices_forecasting_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_forecasting_gin ON public.psyho_matrices USING gin (forecasting);


--
-- Name: idx_psyho_matrices_karmic_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_karmic_gin ON public.psyho_matrices USING gin (karmic_analysis);


--
-- Name: idx_psyho_matrices_user_energy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_user_energy ON public.psyho_matrices USING btree (user_id, energy_level);


--
-- Name: idx_psyho_matrices_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_user_id ON public.psyho_matrices USING btree (user_id);


--
-- Name: idx_psyho_matrices_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_psyho_matrices_version ON public.psyho_matrices USING btree (calculation_version);


--
-- Name: idx_recommendations_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recommendations_user_date ON public.recommendations USING btree (user_id, calculation_date DESC);


--
-- Name: idx_tests_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tests_type ON public.psychological_tests USING btree (test_type);


--
-- Name: idx_tests_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tests_user ON public.psychological_tests USING btree (user_id);


--
-- Name: idx_users_apple; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_apple ON public.users USING btree (apple_id) WHERE (apple_id IS NOT NULL);


--
-- Name: idx_users_auth_method; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_auth_method ON public.users USING btree (primary_auth_method) WHERE (primary_auth_method IS NOT NULL);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at DESC);


--
-- Name: idx_users_email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_email_unique ON public.users USING btree (email_hash) WHERE (email_hash IS NOT NULL);


--
-- Name: idx_users_google; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_google ON public.users USING btree (google_id) WHERE (google_id IS NOT NULL);


--
-- Name: idx_users_last_activity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_last_activity ON public.users USING btree (last_activity_at DESC);


--
-- Name: idx_users_max; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_max ON public.users USING btree (max_id) WHERE (max_id IS NOT NULL);


--
-- Name: idx_users_phone_email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_phone_email_unique ON public.users USING btree (phone_hash, email_hash) WHERE ((phone_hash IS NOT NULL) AND (email_hash IS NOT NULL));


--
-- Name: idx_users_phone_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_phone_unique ON public.users USING btree (phone_hash) WHERE (phone_hash IS NOT NULL);


--
-- Name: idx_users_premium; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_premium ON public.users USING btree (premium_until) WHERE (is_premium = true);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_status ON public.users USING btree (status) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_users_telegram; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_telegram ON public.users USING btree (telegram_id) WHERE (telegram_id IS NOT NULL);


--
-- Name: idx_users_udemy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_udemy ON public.users USING btree (udemy_id) WHERE (udemy_id IS NOT NULL);


--
-- Name: idx_users_yandex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_yandex ON public.users USING btree (yandex_id) WHERE (yandex_id IS NOT NULL);


--
-- Name: magic_profiles trigger_update_magic_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_magic_updated_at BEFORE UPDATE ON public.magic_profiles FOR EACH ROW EXECUTE FUNCTION public.update_magic_updated_at();


--
-- Name: recommendations update_activity_on_recommendation; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_activity_on_recommendation AFTER INSERT OR UPDATE ON public.recommendations FOR EACH ROW EXECUTE FUNCTION public.update_user_activity();


--
-- Name: psychological_tests update_activity_on_test; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_activity_on_test AFTER INSERT OR UPDATE ON public.psychological_tests FOR EACH ROW EXECUTE FUNCTION public.update_user_activity();


--
-- Name: astro_events update_astro_events_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_astro_events_updated_at BEFORE UPDATE ON public.astro_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: magic_profiles update_magic_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_magic_profiles_updated_at BEFORE UPDATE ON public.magic_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: natal_charts update_natal_charts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_natal_charts_updated_at BEFORE UPDATE ON public.natal_charts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: psyho_matrices update_psyho_matrices_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_psyho_matrices_updated_at BEFORE UPDATE ON public.psyho_matrices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: recommendations update_recommendations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_recommendations_updated_at BEFORE UPDATE ON public.recommendations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_profiles update_user_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: biorhythms biorhythms_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biorhythms
    ADD CONSTRAINT biorhythms_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calculation_cache calculation_cache_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculation_cache
    ADD CONSTRAINT calculation_cache_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: daily_forecast_cache daily_forecast_cache_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_forecast_cache
    ADD CONSTRAINT daily_forecast_cache_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forecast_feedback forecast_feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forecast_feedback
    ADD CONSTRAINT forecast_feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: magic_profiles magic_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.magic_profiles
    ADD CONSTRAINT magic_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ml_model_metrics ml_model_metrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: natal_charts natal_charts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.natal_charts
    ADD CONSTRAINT natal_charts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: optimal_activities optimal_activities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimal_activities
    ADD CONSTRAINT optimal_activities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profile_snapshots profile_snapshots_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile_snapshots
    ADD CONSTRAINT profile_snapshots_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: psychological_tests psychological_tests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychological_tests
    ADD CONSTRAINT psychological_tests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: psyho_matrices psyho_matrices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psyho_matrices
    ADD CONSTRAINT psyho_matrices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recommendations recommendations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_audit_log system_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_audit_log
    ADD CONSTRAINT system_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_in(cstring) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_out(public.gtrgm); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_out(public.gtrgm) TO personal_assistant_app;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea) TO personal_assistant_app;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO personal_assistant_app;


--
-- Name: FUNCTION cleanup_old_data(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_old_data() TO personal_assistant_app;


--
-- Name: FUNCTION cleanup_old_forecasts(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cleanup_old_forecasts() TO personal_assistant_app;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dearmor(text) TO personal_assistant_app;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO personal_assistant_app;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO personal_assistant_app;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO personal_assistant_app;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO personal_assistant_app;


--
-- Name: FUNCTION gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gin_extract_value_trgm(text, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_value_trgm(text, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_compress(internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_consistent(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_consistent(internal, text, smallint, oid, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_decompress(internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_distance(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_distance(internal, text, smallint, oid, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_options(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_options(internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_penalty(internal, internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_picksplit(internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_same(public.gtrgm, public.gtrgm, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_same(public.gtrgm, public.gtrgm, internal) TO personal_assistant_app;


--
-- Name: FUNCTION gtrgm_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_union(internal, internal) TO personal_assistant_app;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO personal_assistant_app;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO personal_assistant_app;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO personal_assistant_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO personal_assistant_app;


--
-- Name: FUNCTION set_limit(real); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_limit(real) TO personal_assistant_app;


--
-- Name: FUNCTION show_limit(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_limit() TO personal_assistant_app;


--
-- Name: FUNCTION show_trgm(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_trgm(text) TO personal_assistant_app;


--
-- Name: FUNCTION similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION similarity_dist(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_dist(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION strict_word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION update_magic_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_magic_updated_at() TO personal_assistant_app;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO personal_assistant_app;


--
-- Name: FUNCTION update_user_activity(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_user_activity() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO personal_assistant_app;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_nil() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO personal_assistant_app;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_commutator_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_op(text, text) TO personal_assistant_app;


--
-- Name: FUNCTION word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_op(text, text) TO personal_assistant_app;


--
-- Name: TABLE astro_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.astro_events TO personal_assistant_app;


--
-- Name: SEQUENCE astro_events_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.astro_events_id_seq TO personal_assistant_app;


--
-- Name: TABLE biorhythms; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.biorhythms TO personal_assistant_app;


--
-- Name: SEQUENCE biorhythms_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.biorhythms_id_seq TO personal_assistant_app;


--
-- Name: TABLE calculation_cache; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.calculation_cache TO personal_assistant_app;


--
-- Name: SEQUENCE calculation_cache_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.calculation_cache_id_seq TO personal_assistant_app;


--
-- Name: TABLE daily_forecast_cache; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.daily_forecast_cache TO personal_assistant_app;


--
-- Name: SEQUENCE daily_forecast_cache_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.daily_forecast_cache_id_seq TO personal_assistant_app;


--
-- Name: TABLE recommendations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.recommendations TO personal_assistant_app;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO personal_assistant_app;


--
-- Name: TABLE daily_user_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.daily_user_summary TO personal_assistant_app;


--
-- Name: TABLE forecast_feedback; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.forecast_feedback TO personal_assistant_app;


--
-- Name: SEQUENCE forecast_feedback_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.forecast_feedback_id_seq TO personal_assistant_app;


--
-- Name: TABLE magic_profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.magic_profiles TO personal_assistant_app;


--
-- Name: SEQUENCE magic_profiles_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.magic_profiles_id_seq TO personal_assistant_app;


--
-- Name: TABLE ml_model_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ml_model_metrics TO personal_assistant_app;


--
-- Name: SEQUENCE ml_model_metrics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.ml_model_metrics_id_seq TO personal_assistant_app;


--
-- Name: TABLE ml_models_performance; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ml_models_performance TO personal_assistant_app;


--
-- Name: TABLE natal_charts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.natal_charts TO personal_assistant_app;


--
-- Name: SEQUENCE natal_charts_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.natal_charts_id_seq TO personal_assistant_app;


--
-- Name: TABLE optimal_activities; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.optimal_activities TO personal_assistant_app;


--
-- Name: SEQUENCE optimal_activities_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.optimal_activities_id_seq TO personal_assistant_app;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pg_stat_statements TO personal_assistant_app;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pg_stat_statements_info TO personal_assistant_app;


--
-- Name: TABLE profile_snapshots; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.profile_snapshots TO personal_assistant_app;


--
-- Name: SEQUENCE profile_snapshots_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.profile_snapshots_id_seq TO personal_assistant_app;


--
-- Name: TABLE psychological_tests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.psychological_tests TO personal_assistant_app;


--
-- Name: SEQUENCE psychological_tests_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.psychological_tests_id_seq TO personal_assistant_app;


--
-- Name: TABLE psyho_matrices; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.psyho_matrices TO personal_assistant_app;


--
-- Name: SEQUENCE recommendations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.recommendations_id_seq TO personal_assistant_app;


--
-- Name: TABLE system_audit_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.system_audit_log TO personal_assistant_app;


--
-- Name: SEQUENCE system_audit_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.system_audit_log_id_seq TO personal_assistant_app;


--
-- Name: TABLE system_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.system_metrics TO personal_assistant_app;


--
-- Name: SEQUENCE system_metrics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.system_metrics_id_seq TO personal_assistant_app;


--
-- Name: TABLE user_profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_profiles TO personal_assistant_app;


--
-- Name: TABLE user_complete_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_complete_info TO personal_assistant_app;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.users_id_seq TO personal_assistant_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT USAGE ON SEQUENCES  TO personal_assistant_app;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO personal_assistant_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO personal_assistant_app;


--
-- PostgreSQL database dump complete
--

\unrestrict nXheNhjhQYLOlIPCr1ZPJdPAH1W3rzCGq2vXITtCHtSem84a3qFuwHZtmTac8B2

